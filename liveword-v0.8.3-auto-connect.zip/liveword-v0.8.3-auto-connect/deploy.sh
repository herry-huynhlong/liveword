#!/usr/bin/env bash
set -euo pipefail
DEST=/var/www/liveword/public
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/www/liveword/backups/public-$STAMP"

echo "==> Deploy LIVEWORLD v0.8.3-auto-connect"
if [[ -d "$DEST" ]] && [[ -n "$(find "$DEST" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)" ]]; then
  echo "==> Backup current public -> $BACKUP"
  sudo mkdir -p "$(dirname "$BACKUP")"
  sudo cp -a "$DEST" "$BACKUP"
fi

sudo mkdir -p "$DEST"
sudo rsync -a --delete "$SCRIPT_DIR/public/" "$DEST/"
sudo chown -R www-data:www-data /var/www/liveword
sudo find /var/www/liveword -type d -exec chmod 755 {} \;
sudo find /var/www/liveword -type f -exec chmod 644 {} \;

echo "==> Local checks"
grep -q 'v0.8.3-auto-connect' "$DEST/index.html"
grep -q 'app.js?v=8.3-auto-connect' "$DEST/index.html"
grep -q 'styles.css?v=8.3-auto-connect' "$DEST/index.html"
! grep -q 'cdn.jsdelivr.net/npm/cesium' "$DEST/index.html"
test -s "$DEST/assets/earth-blue-marble-web-3600x1800.jpg"
test -f "$DEST/workers/orbit-worker.js"

echo "==> Install/refresh server-side LIVEWORLD services"
if [[ "${LIVEWORLD_SKIP_SERVER_INSTALL:-0}" != "1" ]]; then
  if [[ -x "$SCRIPT_DIR/nginx/install-space-api.sh" || -f "$SCRIPT_DIR/nginx/install-space-api.sh" ]]; then
    if sudo bash "$SCRIPT_DIR/nginx/install-space-api.sh"; then
      echo "OK: JPL Horizons + NASA image proxy installed"
    else
      echo "WARNING: Space API proxy install failed. SPACE view opens, but JPL/NASA assets may not load."
    fi
  fi
  if [[ -x "$SCRIPT_DIR/server/install-live-data.sh" || -f "$SCRIPT_DIR/server/install-live-data.sh" ]]; then
    if sudo bash "$SCRIPT_DIR/server/install-live-data.sh"; then
      echo "OK: CelesTrak orbit snapshot service installed"
    else
      echo "WARNING: Orbit snapshot service install failed. Earth orbit layer may fall back to CelesTrak proxy."
    fi
  fi
  if [[ -x "$SCRIPT_DIR/server/install-external-feeds.sh" || -f "$SCRIPT_DIR/server/install-external-feeds.sh" ]]; then
    if sudo bash "$SCRIPT_DIR/server/install-external-feeds.sh"; then
      echo "OK: aircraft + Launch Library feed service installed"
    else
      echo "WARNING: external feed service install failed. /live-data/launch.json may stay unavailable."
    fi
  fi
else
  echo "Skipped server install because LIVEWORLD_SKIP_SERVER_INSTALL=1"
fi

echo "OK: LIVEWORLD v0.8.3-auto-connect copied to $DEST"
echo "Backup: $BACKUP"
echo "Verify:"
echo "  curl -s https://liveword.longh.org/ | grep -E 'v0.8.3-auto-connect|app.js\\?v=8.3-auto-connect'"
echo "  curl -s https://liveword.longh.org/live-data/space-active.meta.json | python3 -m json.tool"
echo "  curl -s https://liveword.longh.org/live-data/launch.json | python3 -m json.tool | head -80"
echo "  curl -I https://liveword.longh.org/api/nasa/wise/allsky.jpg"
