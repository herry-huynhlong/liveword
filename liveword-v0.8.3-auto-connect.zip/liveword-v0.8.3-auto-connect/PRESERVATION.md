# Preservation note — v0.8.0-live

This build is an incremental extension of the preserved `v0.7.3-rich` Earth tracker. It does **not** replace the working Canvas/SGP4 orbital core and does not re-enable the unfinished SPACE prototype.

Changes are intentionally isolated to the external live-data path:

- adds server-side aircraft normalization (ADSB.lol by default; OpenSky optional when authorized),
- adds a server-side AISStream ship bridge,
- adds Launch Library 2 pad/schedule snapshots,
- makes aircraft/ship icons directional,
- makes the external object panel type-aware,
- retains last valid snapshots through transient upstream failures.

The old orbital snapshot, IndexedDB warm cache, SGP4 Web Worker, surface map, object profiles and CelesTrak SATCAT metadata paths remain intact.

Do not treat Launch Library pad coordinates as live rocket telemetry. Do not expose AIS credentials to the browser. Do not enable the preserved Solar System prototype without separately restoring its missing assets and integration.
