#!/usr/bin/env bash
set -euo pipefail

DATA_DIR=/var/lib/liveworld/data
LIB_DIR=/usr/local/lib/liveworld
ENV_DIR=/etc/liveworld
ENV_FILE=$ENV_DIR/live-data.env
VENV=/opt/liveworld/venv
SYNC_SERVICE=/etc/systemd/system/liveworld-feed-sync.service
SHIP_SERVICE=/etc/systemd/system/liveworld-ship-feed.service
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_AIRCRAFT_AREAS_JSON='[{"lat":10.78,"lon":106.70,"radius_nm":250},{"lat":21.03,"lon":105.85,"radius_nm":250},{"lat":16.05,"lon":108.20,"radius_nm":250},{"lat":1.35,"lon":103.82,"radius_nm":250}]'

if [[ $EUID -ne 0 ]]; then
  echo "Run with sudo: sudo bash server/install-external-feeds.sh"
  exit 1
fi

command -v python3 >/dev/null || { echo "python3 is required"; exit 1; }

mkdir -p "$DATA_DIR" "$LIB_DIR" "$ENV_DIR" /opt/liveworld
install -m 0755 "$SCRIPT_DIR/liveworld-feed-sync.py" "$LIB_DIR/liveworld-feed-sync.py"
install -m 0755 "$SCRIPT_DIR/liveworld-aisstream.py" "$LIB_DIR/liveworld-aisstream.py"
chown -R www-data:www-data /var/lib/liveworld
chmod 755 /var/lib/liveworld "$DATA_DIR"

if [[ ! -f "$ENV_FILE" ]]; then
  cat > "$ENV_FILE" <<'ENV'
# LIVEWORLD external feeds. Keep this file root-readable only.
# Aircraft default: ADSB.lol open API (ODbL 1.0). Add one or more centers, max 250 nm each.
AIRCRAFT_PROVIDER=adsblol
AIRCRAFT_AREAS_JSON=[{"lat":10.78,"lon":106.70,"radius_nm":250},{"lat":21.03,"lon":105.85,"radius_nm":250},{"lat":16.05,"lon":108.20,"radius_nm":250},{"lat":1.35,"lon":103.82,"radius_nm":250}]
AIRCRAFT_REFRESH_SECONDS=15
AIRCRAFT_STALE_AFTER_SECONDS=90

# Optional OpenSky provider. Operational REST API use requires permission/license under current OpenSky terms.
# Set AIRCRAFT_PROVIDER=opensky only when your deployment is authorized.
OPENSKY_CLIENT_ID=
OPENSKY_CLIENT_SECRET=
OPENSKY_STALE_AFTER_SECONDS=1200
AIRCRAFT_REFRESH_AUTH_SECONDS=90
AIRCRAFT_REFRESH_ANON_SECONDS=900

# Launch Library 2 does not need a key.
LAUNCH_REFRESH_SECONDS=900
LAUNCH_STALE_AFTER_SECONDS=3600

# AISStream requires a free server-side API key and at least one bounding box.
# Example only (do not blindly use a huge global box in production):
# AISSTREAM_API_KEY=replace_me
# AISSTREAM_BBOXES_JSON=[[[8.0,102.0],[24.0,115.0]]]
AISSTREAM_API_KEY=
AISSTREAM_BBOXES_JSON=
SHIP_TTL_SECONDS=1800
SHIP_MAX_OBJECTS=15000
SHIP_FLUSH_SECONDS=3
SHIP_HEARTBEAT_SECONDS=30
SHIP_STALE_AFTER_SECONDS=300
ENV
fi
chmod 600 "$ENV_FILE"

if grep -q '^AIRCRAFT_AREAS_JSON=$' "$ENV_FILE"; then
  python3 - "$ENV_FILE" "$DEFAULT_AIRCRAFT_AREAS_JSON" <<'PY'
from pathlib import Path
import sys
path = Path(sys.argv[1])
areas = sys.argv[2]
text = path.read_text()
text = text.replace('AIRCRAFT_AREAS_JSON=\n', f'AIRCRAFT_AREAS_JSON={areas}\n')
path.write_text(text)
PY
fi

# Ship feed uses the maintained Python websockets package. Keep it isolated.
if ! python3 -m venv "$VENV" 2>/dev/null; then
  echo "python3 venv support is missing; installing python3-venv..."
  apt-get update
  DEBIAN_FRONTEND=noninteractive apt-get install -y python3-venv
  python3 -m venv "$VENV"
fi
"$VENV/bin/python" -m pip install --quiet --upgrade pip
"$VENV/bin/python" -m pip install --quiet 'websockets>=13,<17'

cat > "$SYNC_SERVICE" <<'UNIT'
[Unit]
Description=LIVEWORLD aircraft + Launch Library feed synchronizer
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
EnvironmentFile=/etc/liveworld/live-data.env
ExecStart=/usr/bin/python3 /usr/local/lib/liveworld/liveworld-feed-sync.py daemon
Restart=always
RestartSec=10
User=www-data
Group=www-data
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/liveworld/data

[Install]
WantedBy=multi-user.target
UNIT

cat > "$SHIP_SERVICE" <<'UNIT'
[Unit]
Description=LIVEWORLD AISStream ship feed bridge
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
EnvironmentFile=/etc/liveworld/live-data.env
ExecStart=/opt/liveworld/venv/bin/python /usr/local/lib/liveworld/liveworld-aisstream.py
Restart=on-failure
RestartSec=10
User=www-data
Group=www-data
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/liveworld/data

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable --now liveworld-feed-sync.service

AIS_KEY="$(awk -F= '/^AISSTREAM_API_KEY=/{sub(/^AISSTREAM_API_KEY=/,""); print; exit}' "$ENV_FILE")"
AIS_BOX="$(awk -F= '/^AISSTREAM_BBOXES_JSON=/{sub(/^AISSTREAM_BBOXES_JSON=/,""); print; exit}' "$ENV_FILE")"
if [[ -n "$AIS_KEY" && -n "$AIS_BOX" ]]; then
  systemctl enable --now liveworld-ship-feed.service
  SHIP_MSG="enabled"
else
  systemctl disable --now liveworld-ship-feed.service >/dev/null 2>&1 || true
  SHIP_MSG="installed but disabled (add AISSTREAM_API_KEY + AISSTREAM_BBOXES_JSON, then enable it)"
fi

cat <<EOF

LIVEWORLD external feeds installed.

Aircraft: ADSB.lol (default) / OpenSky (optional) -> $DATA_DIR/aircraft.json
Launch:   Launch Library 2 -> $DATA_DIR/launch.json
Ships:    AISStream -> $DATA_DIR/ships.json ($SHIP_MSG)

Secrets/config: $ENV_FILE

Useful commands:
  systemctl status liveworld-feed-sync --no-pager
  journalctl -u liveworld-feed-sync -n 80 --no-pager
  systemctl status liveworld-ship-feed --no-pager
  journalctl -u liveworld-ship-feed -n 80 --no-pager
  ls -lh $DATA_DIR/{aircraft,launch,ships}.json 2>/dev/null || true

After adding AISStream credentials:
  sudo systemctl enable --now liveworld-ship-feed

After editing aircraft provider / areas / credentials:
  sudo systemctl restart liveworld-feed-sync
EOF
