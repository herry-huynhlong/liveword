#!/usr/bin/env python3
"""AISStream -> LIVEWORLD ship snapshot bridge.

Requires:
  AISSTREAM_API_KEY
  AISSTREAM_BBOXES_JSON='[[[lat1,lon1],[lat2,lon2]], ...]'

The key stays server-side. The browser only receives normalized ships.json.
"""
from __future__ import annotations

import asyncio
import json
import os
import signal
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import websockets

DATA_DIR = Path(os.getenv("LIVEWORLD_DATA_DIR", "/var/lib/liveworld/data"))
OUT = DATA_DIR / "ships.json"
URL = "wss://stream.aisstream.io/v0/stream"
API_KEY = os.getenv("AISSTREAM_API_KEY", "").strip()
BBOX_RAW = os.getenv("AISSTREAM_BBOXES_JSON", "").strip()
TTL = max(60, int(os.getenv("SHIP_TTL_SECONDS", "1800")))
MAX_OBJECTS = max(500, int(os.getenv("SHIP_MAX_OBJECTS", "15000")))
FLUSH_SECONDS = max(1, int(os.getenv("SHIP_FLUSH_SECONDS", "3")))
HEARTBEAT_SECONDS = max(10, int(os.getenv("SHIP_HEARTBEAT_SECONDS", "30")))
STALE_AFTER = max(30, int(os.getenv("SHIP_STALE_AFTER_SECONDS", "300")))

STOP = asyncio.Event()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def num(value: Any) -> float | None:
    try:
        n = float(value)
    except (TypeError, ValueError):
        return None
    return n if n == n and abs(n) != float("inf") else None


def text(value: Any) -> str:
    return str(value or "").strip()


def atomic_json(payload: Any) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=".ships.", suffix=".tmp", dir=str(DATA_DIR))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, separators=(",", ":"))
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp_name, 0o644)
        os.replace(tmp_name, OUT)
    finally:
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass


def validate_bboxes(raw: str) -> list[Any]:
    if not raw:
        raise SystemExit("AISSTREAM_BBOXES_JSON is required. Keep AIS bounding boxes focused on the area your app needs.")
    boxes = json.loads(raw)
    if not isinstance(boxes, list) or not boxes:
        raise SystemExit("AISSTREAM_BBOXES_JSON must be a non-empty JSON array")
    for box in boxes:
        if not isinstance(box, list) or len(box) != 2 or any(not isinstance(point, list) or len(point) != 2 for point in box):
            raise SystemExit("Each AIS bounding box must be [[lat,lon],[lat,lon]]")
    return boxes


def body_for(event: dict[str, Any]) -> dict[str, Any]:
    message_type = text(event.get("MessageType"))
    message = event.get("Message") or {}
    body = message.get(message_type)
    return body if isinstance(body, dict) else {}


def normalized_ship(event: dict[str, Any], static: dict[str, dict[str, Any]]) -> tuple[str, dict[str, Any]] | None:
    meta = event.get("MetaData") or {}
    body = body_for(event)
    mmsi = text(meta.get("MMSI") or body.get("UserID"))
    if not mmsi:
        return None
    lat = num(meta.get("Latitude"))
    lon = num(meta.get("Longitude"))
    if lat is None:
        lat = num(body.get("Latitude"))
    if lon is None:
        lon = num(body.get("Longitude"))
    if lat is None or lon is None or not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
        return None
    extra = static.get(mmsi, {})
    name = text(meta.get("ShipName")) or text(extra.get("name")) or f"MMSI {mmsi}"
    sog = num(body.get("Sog"))
    cog = num(body.get("Cog"))
    heading = num(body.get("TrueHeading"))
    if heading is None or heading >= 360:
        heading = cog
    return mmsi, {
        "id": mmsi,
        "mmsi": mmsi,
        "name": name,
        "vesselName": name,
        "lat": lat,
        "lon": lon,
        "speed_knots": sog,
        "course": cog,
        "heading": heading,
        "navigationStatus": body.get("NavigationalStatus"),
        "imo": text(extra.get("imo")),
        "callSign": text(extra.get("callSign")),
        "destination": text(extra.get("destination")),
        "shipType": text(extra.get("shipType")),
        "timestamp": now_iso(),
        "source": "AISStream · AIS",
        "_seen": time.time(),
    }


def update_static(event: dict[str, Any], static: dict[str, dict[str, Any]]) -> None:
    meta = event.get("MetaData") or {}
    body = body_for(event)
    mmsi = text(meta.get("MMSI") or body.get("UserID"))
    if not mmsi:
        return
    current = static.setdefault(mmsi, {})
    current.update(
        {
            "name": text(meta.get("ShipName")) or text(body.get("Name")) or current.get("name", ""),
            "imo": text(body.get("ImoNumber") or body.get("IMONumber")) or current.get("imo", ""),
            "callSign": text(body.get("CallSign")) or current.get("callSign", ""),
            "destination": text(body.get("Destination")) or current.get("destination", ""),
            "shipType": text(body.get("Type") or body.get("ShipType")) or current.get("shipType", ""),
        }
    )


def snapshot(ships: dict[str, dict[str, Any]]) -> dict[str, Any]:
    cutoff = time.time() - TTL
    stale = [key for key, ship in ships.items() if float(ship.get("_seen", 0)) < cutoff]
    for key in stale:
        ships.pop(key, None)
    rows = sorted(ships.values(), key=lambda x: float(x.get("_seen", 0)), reverse=True)[:MAX_OBJECTS]
    clean = []
    for row in rows:
        item = dict(row)
        item.pop("_seen", None)
        clean.append(item)
    return {
        "schema": "liveworld-feed-v1",
        "source": "AISStream",
        "generatedAt": now_iso(),
        "count": len(clean),
        "staleAfterSeconds": STALE_AFTER,
        "retentionSeconds": TTL,
        "data": clean,
    }


async def run_stream(boxes: list[Any]) -> None:
    ships: dict[str, dict[str, Any]] = {}
    static: dict[str, dict[str, Any]] = {}
    if not OUT.exists():
        atomic_json(snapshot(ships))
    last_flush = time.time()
    dirty_since_flush = False
    backoff = 1
    while not STOP.is_set():
        try:
            async with websockets.connect(URL, compression="deflate", max_size=4 * 1024 * 1024, ping_interval=20, ping_timeout=20) as ws:
                subscription = {
                    "APIKey": API_KEY,
                    "BoundingBoxes": boxes,
                    "FilterMessageTypes": [
                        "PositionReport",
                        "StandardClassBPositionReport",
                        "ExtendedClassBPositionReport",
                        "ShipStaticData",
                        "StaticDataReport",
                    ],
                }
                await ws.send(json.dumps(subscription, separators=(",", ":")))
                print(f"[{now_iso()}] AISStream connected; {len(boxes)} bounding box(es)", flush=True)
                backoff = 1
                while not STOP.is_set():
                    try:
                        raw = await asyncio.wait_for(ws.recv(), timeout=FLUSH_SECONDS)
                    except asyncio.TimeoutError:
                        raw = None
                    if raw is not None:
                        if isinstance(raw, bytes):
                            raw = raw.decode("utf-8", "replace")
                        event = json.loads(raw)
                        msg_type = text(event.get("MessageType"))
                        if msg_type in ("ShipStaticData", "StaticDataReport"):
                            update_static(event, static)
                        elif msg_type in ("PositionReport", "StandardClassBPositionReport", "ExtendedClassBPositionReport"):
                            normalized = normalized_ship(event, static)
                            if normalized:
                                mmsi, row = normalized
                                ships[mmsi] = row
                                dirty_since_flush = True
                    elapsed = time.time() - last_flush
                    if (dirty_since_flush and elapsed >= FLUSH_SECONDS) or elapsed >= HEARTBEAT_SECONDS:
                        atomic_json(snapshot(ships))
                        last_flush = time.time()
                        dirty_since_flush = False
        except Exception as exc:
            print(f"[{now_iso()}] AISStream error: {exc}", flush=True)
        if STOP.is_set():
            break
        await asyncio.sleep(backoff)
        backoff = min(60, backoff * 2)


async def main() -> None:
    if not API_KEY:
        raise SystemExit("AISSTREAM_API_KEY is required; create a key at aisstream.io and keep it in the server environment file")
    boxes = validate_bboxes(BBOX_RAW)
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        try:
            loop.add_signal_handler(sig, STOP.set)
        except NotImplementedError:
            pass
    await run_stream(boxes)


if __name__ == "__main__":
    asyncio.run(main())
