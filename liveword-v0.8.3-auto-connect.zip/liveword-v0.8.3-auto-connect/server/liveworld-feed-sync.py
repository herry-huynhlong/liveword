#!/usr/bin/env python3
"""LIVEWORLD external feed normalizer.

Writes browser-safe snapshots into /var/lib/liveworld/data:
  aircraft.json  <- ADSB.lol by default; optional OpenSky adapter
  launch.json    <- The Space Devs Launch Library 2 upcoming launches

No secrets are exposed to the browser. Aircraft coverage is configured
server-side; OpenSky is available only as an optional authorized provider.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import json
import os
import signal
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DATA_DIR = Path(os.getenv("LIVEWORLD_DATA_DIR", "/var/lib/liveworld/data"))
USER_AGENT = os.getenv("LIVEWORLD_USER_AGENT", "LIVEWORLD/0.8 (+https://liveword.longh.org)")
OPENSKY_STATES_URL = "https://opensky-network.org/api/states/all?extended=1"
ADSBLOL_BASE_URL = os.getenv("ADSBLOL_BASE_URL", "https://api.adsb.lol").rstrip("/")
OPENSKY_TOKEN_URL = "https://auth.opensky-network.org/auth/realms/opensky-network/protocol/openid-connect/token"
LAUNCH_URL = os.getenv(
    "LAUNCH_LIBRARY_URL",
    "https://ll.thespacedevs.com/2.3.0/launches/upcoming/?limit=100&mode=normal&ordering=net&hide_recent_previous=true&format=json",
)
DEFAULT_AIRCRAFT_AREAS_JSON = (
    '[{"lat":10.78,"lon":106.70,"radius_nm":250},'
    '{"lat":21.03,"lon":105.85,"radius_nm":250},'
    '{"lat":16.05,"lon":108.20,"radius_nm":250},'
    '{"lat":1.35,"lon":103.82,"radius_nm":250}]'
)

STOP = threading.Event()


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def iso_from_epoch(value: Any) -> str:
    try:
        value = int(value)
    except (TypeError, ValueError):
        return now_iso()
    return datetime.fromtimestamp(value, tz=timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def clean_text(value: Any) -> str:
    return str(value or "").strip()


def finite_number(value: Any) -> float | None:
    try:
        n = float(value)
    except (TypeError, ValueError):
        return None
    if n != n or n in (float("inf"), float("-inf")):
        return None
    return n


def atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, separators=(",", ":"))
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp_name, 0o644)
        os.replace(tmp_name, path)
    finally:
        try:
            os.unlink(tmp_name)
        except FileNotFoundError:
            pass


def request_json(url: str, *, headers: dict[str, str] | None = None, data: bytes | None = None, timeout: int = 45) -> tuple[Any, Any]:
    merged = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    if headers:
        merged.update(headers)
    req = urllib.request.Request(url, headers=merged, data=data)
    with urllib.request.urlopen(req, timeout=timeout) as response:
        return json.load(response), response.headers


class OpenSkyTokenManager:
    def __init__(self) -> None:
        self.client_id = clean_text(os.getenv("OPENSKY_CLIENT_ID"))
        self.client_secret = clean_text(os.getenv("OPENSKY_CLIENT_SECRET"))
        self.token = ""
        self.expires_at = 0.0

    @property
    def configured(self) -> bool:
        return bool(self.client_id and self.client_secret)

    def auth_header(self) -> dict[str, str]:
        if not self.configured:
            return {}
        if self.token and time.time() < self.expires_at - 30:
            return {"Authorization": f"Bearer {self.token}"}
        encoded = urllib.parse.urlencode(
            {
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            }
        ).encode()
        payload, _ = request_json(
            OPENSKY_TOKEN_URL,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data=encoded,
            timeout=25,
        )
        self.token = clean_text(payload.get("access_token"))
        if not self.token:
            raise RuntimeError("OpenSky OAuth token response did not contain access_token")
        self.expires_at = time.time() + int(payload.get("expires_in", 1800))
        return {"Authorization": f"Bearer {self.token}"}




ADSBLOL_CATEGORY = {
    "A0": "No category",
    "A1": "Light aircraft",
    "A2": "Small aircraft",
    "A3": "Large aircraft",
    "A4": "High-vortex large",
    "A5": "Heavy aircraft",
    "A6": "High-performance",
    "A7": "Rotorcraft",
    "B0": "No category",
    "B1": "Glider",
    "B2": "Lighter-than-air",
    "B3": "Parachutist",
    "B4": "Ultralight",
    "B6": "UAV",
    "B7": "Space / trans-atmospheric",
    "C0": "No category",
    "C1": "Emergency surface vehicle",
    "C2": "Service surface vehicle",
    "C3": "Point obstacle",
    "C4": "Cluster obstacle",
    "C5": "Line obstacle",
}


def configured_aircraft_areas() -> list[dict[str, float]]:
    raw = clean_text(os.getenv("AIRCRAFT_AREAS_JSON"))
    if not raw:
        raw = DEFAULT_AIRCRAFT_AREAS_JSON
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"AIRCRAFT_AREAS_JSON is invalid JSON: {exc}") from exc
    if not isinstance(value, list):
        raise RuntimeError("AIRCRAFT_AREAS_JSON must be a JSON array")
    areas: list[dict[str, float]] = []
    for item in value[:20]:
        if isinstance(item, dict):
            lat = finite_number(item.get("lat"))
            lon = finite_number(item.get("lon"))
            radius = finite_number(item.get("radius_nm", item.get("radius", 250)))
        elif isinstance(item, list) and len(item) >= 2:
            lat = finite_number(item[0])
            lon = finite_number(item[1])
            radius = finite_number(item[2] if len(item) > 2 else 250)
        else:
            continue
        if lat is None or lon is None or radius is None:
            continue
        if not (-90 <= lat <= 90 and -180 <= lon <= 180):
            continue
        areas.append({"lat": lat, "lon": lon, "radius_nm": min(250.0, max(1.0, radius))})
    return areas


def readsb_altitude_m(row: dict[str, Any]) -> float | None:
    for key in ("alt_geom", "alt_baro"):
        value = row.get(key)
        if isinstance(value, str) and value.lower() == "ground":
            return 0.0
        feet = finite_number(value)
        if feet is not None:
            return feet * 0.3048
    return None


def readsb_vertical_rate_mps(row: dict[str, Any]) -> float | None:
    value = finite_number(row.get("geom_rate"))
    if value is None:
        value = finite_number(row.get("baro_rate"))
    return value * 0.00508 if value is not None else None


def normalize_adsblol_aircraft(payload: dict[str, Any]) -> list[dict[str, Any]]:
    response_ms = finite_number(payload.get("now"))
    response_epoch = response_ms / 1000.0 if response_ms and response_ms > 10_000_000_000 else (response_ms or time.time())
    rows: list[dict[str, Any]] = []
    for row in payload.get("ac") or []:
        if not isinstance(row, dict):
            continue
        lat = finite_number(row.get("lat"))
        lon = finite_number(row.get("lon"))
        if lat is None or lon is None or not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
            continue
        icao24 = clean_text(row.get("hex")).lower()
        if not icao24:
            continue
        callsign = clean_text(row.get("flight"))
        registration = clean_text(row.get("r"))
        speed_knots = finite_number(row.get("gs"))
        heading = finite_number(row.get("true_heading"))
        if heading is None:
            heading = finite_number(row.get("track"))
        seen_pos = finite_number(row.get("seen_pos"))
        if seen_pos is None:
            seen_pos = finite_number(row.get("seen")) or 0.0
        timestamp = iso_from_epoch(max(0, response_epoch - max(0, seen_pos)))
        category_code = clean_text(row.get("category")).upper()
        source_type = clean_text(row.get("type")) or "ADS-B"
        on_ground = str(row.get("alt_baro", "")).lower() == "ground"
        rows.append(
            {
                "id": icao24,
                "icao24": icao24,
                "name": callsign or registration or icao24.upper(),
                "callsign": callsign,
                "registration": registration,
                "aircraftType": clean_text(row.get("t")),
                "aircraftDescription": clean_text(row.get("desc")),
                "operator": clean_text(row.get("ownOp")),
                "lat": lat,
                "lon": lon,
                "altitude_m": readsb_altitude_m(row),
                "speed_mps": speed_knots * 0.514444 if speed_knots is not None else None,
                "speed_knots": speed_knots,
                "heading": heading,
                "vertical_rate_mps": readsb_vertical_rate_mps(row),
                "onGround": on_ground,
                "squawk": clean_text(row.get("squawk")),
                "positionSource": source_type.upper(),
                "aircraftCategory": ADSBLOL_CATEGORY.get(category_code, category_code or "Unknown"),
                "categoryCode": category_code,
                "timestamp": timestamp,
                "seenPositionSeconds": seen_pos,
                "status": "ON GROUND" if on_ground else "AIRBORNE",
                "source": f"ADSB.lol · {source_type}",
            }
        )
    return rows


def fetch_adsblol_area(area: dict[str, float]) -> list[dict[str, Any]]:
    lat, lon, radius = area["lat"], area["lon"], area["radius_nm"]
    url = f"{ADSBLOL_BASE_URL}/v2/point/{lat:.6f}/{lon:.6f}/{radius:g}"
    payload, _ = request_json(url, timeout=35)
    if not isinstance(payload, dict):
        raise RuntimeError("ADSB.lol response was not an object")
    return normalize_adsblol_aircraft(payload)


def sync_aircraft_adsblol() -> int:
    areas = configured_aircraft_areas()
    if not areas:
        snapshot = {
            "schema": "liveworld-feed-v1",
            "source": "ADSB.lol",
            "generatedAt": now_iso(),
            "count": 0,
            "staleAfterSeconds": 300,
            "configurationRequired": False,
            "message": "Using built-in Southeast Asia aircraft coverage defaults.",
            "license": "ODbL 1.0",
            "data": [],
        }
        atomic_json(DATA_DIR / "aircraft.json", snapshot)
        print(f"[{now_iso()}] aircraft: ADSB.lol using built-in coverage defaults", flush=True)
        return 0

    merged: dict[str, dict[str, Any]] = {}
    errors: list[str] = []
    workers = min(4, len(areas))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(fetch_adsblol_area, area): area for area in areas}
        for future in concurrent.futures.as_completed(futures):
            area = futures[future]
            try:
                for row in future.result():
                    key = row["icao24"]
                    old = merged.get(key)
                    new_seen = finite_number(row.get("seenPositionSeconds"))
                    old_seen = finite_number(old.get("seenPositionSeconds")) if old else None
                    if old is None or (new_seen is not None and (old_seen is None or new_seen < old_seen)):
                        merged[key] = row
            except Exception as exc:
                errors.append(f"{area['lat']},{area['lon']}: {exc}")
    if not merged and errors:
        raise RuntimeError("ADSB.lol area requests failed: " + "; ".join(errors[:3]))
    rows = list(merged.values())
    rows.sort(key=lambda row: (
        finite_number(row.get("seenPositionSeconds")) if finite_number(row.get("seenPositionSeconds")) is not None else 1e9,
        row.get("icao24", ""),
    ))
    snapshot = {
        "schema": "liveworld-feed-v1",
        "source": "ADSB.lol",
        "generatedAt": now_iso(),
        "count": len(rows),
        "staleAfterSeconds": int(os.getenv("AIRCRAFT_STALE_AFTER_SECONDS", "90")),
        "coverageAreas": areas,
        "partial": bool(errors),
        "errors": errors[:5],
        "license": "ODbL 1.0",
        "attribution": "ADSB.lol contributors",
        "data": rows,
    }
    atomic_json(DATA_DIR / "aircraft.json", snapshot)
    print(f"[{now_iso()}] aircraft: {len(rows)} ADSB.lol positions across {len(areas)} area(s){' · partial' if errors else ''}", flush=True)
    return len(rows)


AIRCRAFT_CATEGORY = {
    0: "Unknown",
    1: "No category",
    2: "Light aircraft",
    3: "Small aircraft",
    4: "Large aircraft",
    5: "High-vortex large",
    6: "Heavy aircraft",
    7: "High-performance",
    8: "Rotorcraft",
    9: "Glider",
    10: "Lighter-than-air",
    11: "Parachutist",
    12: "Ultralight",
    14: "UAV",
    15: "Space / trans-atmospheric",
    16: "Emergency surface vehicle",
    17: "Service surface vehicle",
}
POSITION_SOURCE = {0: "ADS-B", 1: "ASTERIX", 2: "MLAT", 3: "FLARM"}


def normalize_aircraft(payload: dict[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    response_time = payload.get("time")
    for vector in payload.get("states") or []:
        if not isinstance(vector, list) or len(vector) < 17:
            continue
        lon = finite_number(vector[5])
        lat = finite_number(vector[6])
        if lat is None or lon is None or not (-90 <= lat <= 90) or not (-180 <= lon <= 180):
            continue
        icao24 = clean_text(vector[0]).lower()
        if not icao24:
            continue
        callsign = clean_text(vector[1])
        last_position = vector[3] or vector[4] or response_time
        baro_altitude = finite_number(vector[7])
        geo_altitude = finite_number(vector[13]) if len(vector) > 13 else None
        category_code = int(vector[17]) if len(vector) > 17 and finite_number(vector[17]) is not None else 0
        source_code = int(vector[16]) if finite_number(vector[16]) is not None else -1
        heading = finite_number(vector[10])
        velocity = finite_number(vector[9])
        vertical_rate = finite_number(vector[11])
        on_ground = bool(vector[8])
        source_name = POSITION_SOURCE.get(source_code, "OpenSky state vector")
        rows.append(
            {
                "id": icao24,
                "icao24": icao24,
                "name": callsign or icao24.upper(),
                "callsign": callsign,
                "lat": lat,
                "lon": lon,
                "altitude_m": geo_altitude if geo_altitude is not None else baro_altitude,
                "baro_altitude_m": baro_altitude,
                "geo_altitude_m": geo_altitude,
                "speed_mps": velocity,
                "heading": heading,
                "vertical_rate_mps": vertical_rate,
                "onGround": on_ground,
                "originCountry": clean_text(vector[2]),
                "squawk": clean_text(vector[14]) if len(vector) > 14 else "",
                "positionSource": source_name,
                "aircraftCategory": AIRCRAFT_CATEGORY.get(category_code, f"Category {category_code}"),
                "categoryCode": category_code,
                "timestamp": iso_from_epoch(last_position),
                "status": "ON GROUND" if on_ground else "AIRBORNE",
                "source": f"OpenSky Network · {source_name}",
            }
        )
    return rows


def sync_aircraft_opensky(tokens: OpenSkyTokenManager) -> int:
    headers = tokens.auth_header()
    payload, response_headers = request_json(OPENSKY_STATES_URL, headers=headers, timeout=60)
    if not isinstance(payload, dict):
        raise RuntimeError("OpenSky response was not an object")
    rows = normalize_aircraft(payload)
    if not rows:
        raise RuntimeError("OpenSky returned no aircraft with valid positions")
    snapshot = {
        "schema": "liveworld-feed-v1",
        "source": "OpenSky Network",
        "generatedAt": now_iso(),
        "sourceTime": iso_from_epoch(payload.get("time")),
        "authenticated": tokens.configured,
        "count": len(rows),
        "staleAfterSeconds": int(os.getenv("OPENSKY_STALE_AFTER_SECONDS", "1200" if not tokens.configured else "300")),
        "rateLimitRemaining": clean_text(response_headers.get("X-Rate-Limit-Remaining")),
        "data": rows,
    }
    atomic_json(DATA_DIR / "aircraft.json", snapshot)
    print(f"[{now_iso()}] aircraft: {len(rows)} positions ({'OAuth' if tokens.configured else 'anonymous'})", flush=True)
    return len(rows)



def aircraft_provider() -> str:
    return clean_text(os.getenv("AIRCRAFT_PROVIDER", "adsblol")).lower()


def sync_aircraft(tokens: OpenSkyTokenManager) -> int:
    provider = aircraft_provider()
    if provider in ("adsblol", "adsb.lol"):
        return sync_aircraft_adsblol()
    if provider == "opensky":
        return sync_aircraft_opensky(tokens)
    raise RuntimeError(f"Unknown AIRCRAFT_PROVIDER={provider!r}; use adsblol or opensky")


def nested(obj: Any, *keys: str) -> Any:
    for key in keys:
        if not isinstance(obj, dict):
            return None
        obj = obj.get(key)
    return obj


def normalize_launches(payload: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for launch in payload.get("results") or []:
        if not isinstance(launch, dict):
            continue
        pad = launch.get("pad") or {}
        lat = finite_number(pad.get("latitude"))
        lon = finite_number(pad.get("longitude"))
        if lat is None or lon is None:
            continue
        provider = nested(launch, "launch_service_provider", "name") or ""
        rocket = nested(launch, "rocket", "configuration", "full_name") or nested(launch, "rocket", "configuration", "name") or ""
        mission = launch.get("mission") or {}
        mission_name = clean_text(mission.get("name"))
        description = clean_text(mission.get("description"))
        status_name = clean_text(nested(launch, "status", "name")) or "SCHEDULED"
        pad_name = clean_text(pad.get("name"))
        location_name = clean_text(nested(pad, "location", "name"))
        launch_image = launch.get("image") if isinstance(launch.get("image"), dict) else {}
        image_url = clean_text(launch_image.get("thumbnail_url") or launch_image.get("image_url"))
        image_credit = clean_text(launch_image.get("credit"))
        net = clean_text(launch.get("net") or launch.get("window_start"))
        name = clean_text(launch.get("name")) or mission_name or clean_text(launch.get("id"))
        out.append(
            {
                "id": clean_text(launch.get("id")),
                "name": name,
                "mission": mission_name,
                "lat": lat,
                "lon": lon,
                "altitudeKm": 0,
                "timestamp": clean_text(launch.get("last_updated")) or now_iso(),
                "launchDate": net,
                "net": net,
                "windowStart": clean_text(launch.get("window_start")),
                "windowEnd": clean_text(launch.get("window_end")),
                "operator": clean_text(provider),
                "rocket": clean_text(rocket),
                "pad": pad_name,
                "location": location_name,
                "status": status_name,
                "probability": launch.get("probability"),
                "imageUrl": image_url,
                "imageCredit": image_credit,
                "imageSourceUrl": clean_text(launch.get("url")),
                "description": description,
                "source": "The Space Devs · Launch Library 2",
            }
        )
    return out


def sync_launch() -> int:
    payload, _ = request_json(LAUNCH_URL, timeout=60)
    if not isinstance(payload, dict):
        raise RuntimeError("Launch Library response was not an object")
    rows = normalize_launches(payload)
    if not rows:
        raise RuntimeError("Launch Library returned no launches with pad coordinates")
    snapshot = {
        "schema": "liveworld-feed-v1",
        "source": "The Space Devs · Launch Library 2",
        "generatedAt": now_iso(),
        "count": len(rows),
        "staleAfterSeconds": int(os.getenv("LAUNCH_STALE_AFTER_SECONDS", "3600")),
        "positionMeaning": "launch-pad coordinates; not in-flight rocket telemetry",
        "data": rows,
    }
    atomic_json(DATA_DIR / "launch.json", snapshot)
    print(f"[{now_iso()}] launch: {len(rows)} upcoming/recent launch pads", flush=True)
    return len(rows)


def sleep_until(seconds: int) -> None:
    STOP.wait(max(1, seconds))


def aircraft_loop() -> None:
    tokens = OpenSkyTokenManager()
    while not STOP.is_set():
        provider = aircraft_provider()
        if provider in ("adsblol", "adsb.lol"):
            interval = max(5, int(os.getenv("AIRCRAFT_REFRESH_SECONDS", "15")))
        elif tokens.configured:
            interval = max(30, int(os.getenv("AIRCRAFT_REFRESH_AUTH_SECONDS", "90")))
        else:
            interval = max(300, int(os.getenv("AIRCRAFT_REFRESH_ANON_SECONDS", "900")))
        try:
            sync_aircraft(tokens)
        except urllib.error.HTTPError as exc:
            retry = int(exc.headers.get("X-Rate-Limit-Retry-After-Seconds", "0") or 0)
            print(f"[{now_iso()}] aircraft HTTP {exc.code}: {exc.reason}", file=sys.stderr, flush=True)
            interval = max(interval, retry or 60)
            if exc.code == 401:
                tokens.token = ""
        except Exception as exc:
            print(f"[{now_iso()}] aircraft error: {exc}", file=sys.stderr, flush=True)
        sleep_until(interval)


def launch_loop() -> None:
    interval = max(300, int(os.getenv("LAUNCH_REFRESH_SECONDS", "900")))
    while not STOP.is_set():
        try:
            sync_launch()
        except Exception as exc:
            print(f"[{now_iso()}] launch error: {exc}", file=sys.stderr, flush=True)
        sleep_until(interval)


def install_signals() -> None:
    def stop(*_: Any) -> None:
        STOP.set()
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["aircraft", "launch", "once", "daemon"], nargs="?", default="daemon")
    args = parser.parse_args()
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    tokens = OpenSkyTokenManager()
    if args.command == "aircraft":
        sync_aircraft(tokens)
        return 0
    if args.command == "launch":
        sync_launch()
        return 0
    if args.command == "once":
        failures = 0
        for fn in (lambda: sync_aircraft(tokens), sync_launch):
            try:
                fn()
            except Exception as exc:
                failures += 1
                print(f"sync failed: {exc}", file=sys.stderr)
        return 1 if failures else 0

    install_signals()
    threads = [
        threading.Thread(target=aircraft_loop, name="aircraft", daemon=True),
        threading.Thread(target=launch_loop, name="launch", daemon=True),
    ]
    for thread in threads:
        thread.start()
    while not STOP.is_set():
        STOP.wait(1)
    for thread in threads:
        thread.join(timeout=5)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
