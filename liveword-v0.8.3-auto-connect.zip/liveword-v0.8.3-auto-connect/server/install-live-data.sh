#!/usr/bin/env bash
set -euo pipefail

DATA_DIR=/var/lib/liveworld/data
SYNC_BIN=/usr/local/bin/liveworld-sync-celestrak
SERVICE=/etc/systemd/system/liveworld-orbit-sync.service
TIMER=/etc/systemd/system/liveworld-orbit-sync.timer
NGINX_FILE=/etc/nginx/sites-available/liveword
DOMAIN=liveword.longh.org

if [[ $EUID -ne 0 ]]; then
  echo "Run with sudo: sudo bash server/install-live-data.sh"
  exit 1
fi

mkdir -p "$DATA_DIR"
chown -R www-data:www-data /var/lib/liveworld
chmod 755 /var/lib/liveworld "$DATA_DIR"

cat > "$SYNC_BIN" <<'SYNC'
#!/usr/bin/env bash
set -euo pipefail

DATA_DIR=/var/lib/liveworld/data
URL='https://celestrak.org/NORAD/elements/gp.php?GROUP=ACTIVE&FORMAT=JSON'
TMP="$(mktemp "$DATA_DIR/space-active.XXXXXX.json")"
META_TMP="$(mktemp "$DATA_DIR/space-active-meta.XXXXXX.json")"
trap 'rm -f "$TMP" "$META_TMP"' EXIT

curl -fsSL --retry 3 --retry-delay 3 --connect-timeout 15 --max-time 90 \
  -A 'LIVEWORLD/0.7.1 (+https://liveword.longh.org)' \
  -H 'Accept: application/json' \
  "$URL" -o "$TMP"

python3 - "$TMP" "$META_TMP" <<'PY'
import hashlib, json, sys
from datetime import datetime, timezone
src, meta_path = sys.argv[1:3]
raw = open(src, 'rb').read()
try:
    rows = json.loads(raw)
except Exception as e:
    raise SystemExit(f'Invalid CelesTrak JSON: {e}')
if not isinstance(rows, list) or len(rows) < 10000:
    raise SystemExit(f'Refusing invalid ACTIVE catalog count: {len(rows) if isinstance(rows,list) else "not-list"}')
required = ('NORAD_CAT_ID','OBJECT_NAME','EPOCH')
valid = sum(1 for r in rows if isinstance(r, dict) and all(r.get(k) not in (None,'') for k in required))
if valid < 10000:
    raise SystemExit(f'Refusing catalog with only {valid} valid OMM rows')
sha = hashlib.sha256(raw).hexdigest()
epochs = [str(r.get('EPOCH','')) for r in rows if r.get('EPOCH')]
meta = {
    'version': sha[:20],
    'sha256': sha,
    'count': len(rows),
    'validCount': valid,
    'generatedAt': datetime.now(timezone.utc).isoformat().replace('+00:00','Z'),
    'newestEpoch': max(epochs) if epochs else None,
    'source': 'CelesTrak ACTIVE · OMM JSON',
}
with open(meta_path,'w') as f:
    json.dump(meta,f,separators=(',',':'))
print(json.dumps(meta))
PY

NEW_VERSION="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["version"])' "$META_TMP")"
OLD_VERSION=""
if [[ -f "$DATA_DIR/space-active.meta.json" ]]; then
  OLD_VERSION="$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1])).get("version",""))' "$DATA_DIR/space-active.meta.json" 2>/dev/null || true)"
fi

if [[ "$NEW_VERSION" != "$OLD_VERSION" || ! -s "$DATA_DIR/space-active.json" ]]; then
  chmod 644 "$TMP" "$META_TMP"
  chown www-data:www-data "$TMP" "$META_TMP"
  mv -f "$TMP" "$DATA_DIR/space-active.json"
  mv -f "$META_TMP" "$DATA_DIR/space-active.meta.json"
  trap - EXIT
  echo "LIVEWORLD orbit snapshot updated: $NEW_VERSION"
else
  # Data is identical. Refresh metadata timestamp without forcing clients to re-download the catalog.
  chmod 644 "$META_TMP"
  chown www-data:www-data "$META_TMP"
  mv -f "$META_TMP" "$DATA_DIR/space-active.meta.json"
  rm -f "$TMP"
  trap - EXIT
  echo "LIVEWORLD orbit snapshot unchanged: $NEW_VERSION"
fi
SYNC
chmod 755 "$SYNC_BIN"

cat > "$SERVICE" <<'UNIT'
[Unit]
Description=LIVEWORLD CelesTrak ACTIVE snapshot refresh
After=network-online.target
Wants=network-online.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/liveworld-sync-celestrak
User=root
Nice=10
UNIT

cat > "$TIMER" <<'UNIT'
[Unit]
Description=Refresh LIVEWORLD orbital snapshot every 15 minutes

[Timer]
OnBootSec=45s
OnUnitActiveSec=15min
RandomizedDelaySec=45s
Persistent=true
Unit=liveworld-orbit-sync.service

[Install]
WantedBy=timers.target
UNIT

if [[ ! -f "$NGINX_FILE" ]]; then
  echo "ERROR: $NGINX_FILE not found"
  exit 1
fi

if ! grep -q 'location ^~ /live-data/' "$NGINX_FILE"; then
  BACKUP="${NGINX_FILE}.bak-live-data-$(date +%Y%m%d-%H%M%S)"
  cp "$NGINX_FILE" "$BACKUP"
  NGINX_FILE="$NGINX_FILE" python3 - <<'PY'
from pathlib import Path
import os,re
p=Path(os.environ['NGINX_FILE'])
s=p.read_text()
block=r'''
    # LIVEWORLD warm-boot orbital snapshots generated locally every 15 minutes.
    location ^~ /live-data/ {
        alias /var/lib/liveworld/data/;
        default_type application/json;
        add_header Cache-Control "no-cache, must-revalidate" always;
        add_header X-Liveworld-Data "server-snapshot" always;
    }

'''
found=False
for m in re.finditer(r'(?m)^[ \t]*server\s*\{',s):
    ob=s.find('{',m.start()); depth=0; end=None
    for i in range(ob,len(s)):
        if s[i]=='{': depth+=1
        elif s[i]=='}':
            depth-=1
            if depth==0: end=i+1; break
    if not end: continue
    b=s[m.start():end]
    if re.search(r'server_name\s+[^;]*liveword\.longh\.org[^;]*;',b) and re.search(r'listen\s+[^;]*443[^;]*;',b):
        s=s[:end-1]+block+s[end-1:]
        found=True
        break
if not found: raise SystemExit('HTTPS liveword server block not found')
p.write_text(s)
PY
  if ! nginx -t; then
    cp "$BACKUP" "$NGINX_FILE"
    nginx -t || true
    echo "ERROR: Nginx validation failed; restored $BACKUP"
    exit 1
  fi
  systemctl reload nginx
fi

systemctl daemon-reload
systemctl enable --now liveworld-orbit-sync.timer
systemctl start liveworld-orbit-sync.service

printf '\n==> Snapshot status\n'
systemctl --no-pager --full status liveworld-orbit-sync.service | sed -n '1,18p' || true
printf '\n==> Snapshot metadata\n'
cat "$DATA_DIR/space-active.meta.json" | python3 -m json.tool
printf '\n==> HTTP check\n'
curl -fsS "https://${DOMAIN}/live-data/space-active.meta.json" | python3 -m json.tool
printf '\nOK: warm-boot data service installed.\n'
