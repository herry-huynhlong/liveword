#!/usr/bin/env bash
set -euo pipefail
DEST=/var/www/liveword/public
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "==> Deploy LIVEWORLD v0.6.2"
sudo mkdir -p "$DEST"
sudo rsync -a --delete "$SCRIPT_DIR/public/" "$DEST/"
sudo chown -R www-data:www-data /var/www/liveword
sudo find /var/www/liveword -type d -exec chmod 755 {} \;
sudo find /var/www/liveword -type f -exec chmod 644 {} \;

echo "==> Local deploy check"
grep -q 'v0.6.2' "$DEST/index.html"
grep -q 'app.js?v=6.2' "$DEST/index.html"
grep -q 'styles.css?v=6.2' "$DEST/index.html"
test -f "$DEST/solar-system.js"

echo "OK: LIVEWORLD v0.6.2 copied to $DEST"
echo "Verify public site with:"
echo "curl -s https://liveword.longh.org/ | grep -E 'v0.6.2|app.js\\?v=6.2|styles.css\\?v=6.2'"
echo "Then hard refresh: Ctrl+Shift+R"
