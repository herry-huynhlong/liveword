import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js';

const DAY_MS = 86_400_000;
const J2000_MS = Date.UTC(2000, 0, 1, 12, 0, 0);

// v0.6.2 uses a lightweight heliocentric visual model so users can move beyond Earth now.
// Distances and planet sizes are intentionally compressed/exaggerated for navigation.
// Replace the position model with JPL Horizons/SPICE in a later source-fusion milestone.
export const SOLAR_BODIES = [
  { id: 'mercury', name: 'Mercury', type: 'Planet', aAu: 0.3871, periodDays: 87.969, phaseDeg: 252.25, inclinationDeg: 7.00, diameterKm: 4879, rotation: '58.6 d', visualRadius: 0.48, color: 0x9c958d },
  { id: 'venus', name: 'Venus', type: 'Planet', aAu: 0.7233, periodDays: 224.701, phaseDeg: 181.98, inclinationDeg: 3.39, diameterKm: 12104, rotation: '243 d', visualRadius: 0.78, color: 0xd8b56d },
  { id: 'earth', name: 'Earth', type: 'Planet', aAu: 1.0000, periodDays: 365.256, phaseDeg: 100.46, inclinationDeg: 0.00, diameterKm: 12742, rotation: '23 h 56 m', visualRadius: 0.82, color: 0x4a86d8 },
  { id: 'mars', name: 'Mars', type: 'Planet', aAu: 1.5237, periodDays: 686.980, phaseDeg: 355.45, inclinationDeg: 1.85, diameterKm: 6779, rotation: '24 h 37 m', visualRadius: 0.62, color: 0xb55d3c },
  { id: 'jupiter', name: 'Jupiter', type: 'Planet', aAu: 5.2028, periodDays: 4332.59, phaseDeg: 34.40, inclinationDeg: 1.30, diameterKm: 139820, rotation: '9 h 56 m', visualRadius: 1.62, color: 0xd2b48c },
  { id: 'saturn', name: 'Saturn', type: 'Planet', aAu: 9.5388, periodDays: 10759.22, phaseDeg: 50.08, inclinationDeg: 2.49, diameterKm: 116460, rotation: '10 h 42 m', visualRadius: 1.42, color: 0xd8c792, ring: true },
  { id: 'uranus', name: 'Uranus', type: 'Planet', aAu: 19.1914, periodDays: 30688.5, phaseDeg: 314.06, inclinationDeg: 0.77, diameterKm: 50724, rotation: '17 h 14 m', visualRadius: 1.04, color: 0x8ed7dd },
  { id: 'neptune', name: 'Neptune', type: 'Planet', aAu: 30.0611, periodDays: 60182, phaseDeg: 304.35, inclinationDeg: 1.77, diameterKm: 49244, rotation: '16 h 6 m', visualRadius: 1.00, color: 0x4169c9 },
];

const BODY_BY_ID = new Map(SOLAR_BODIES.map((body) => [body.id, body]));

function compressedOrbitRadius(aAu) {
  // A logarithmic visual scale keeps Mercury and Neptune visible in one scene.
  return 8.5 + 12.5 * Math.log1p(aAu * 3.8);
}

function makeLabelTexture(text) {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  const scale = Math.max(1, window.devicePixelRatio || 1);
  canvas.width = 256 * scale;
  canvas.height = 64 * scale;
  ctx.scale(scale, scale);
  ctx.clearRect(0, 0, 256, 64);
  ctx.font = '700 20px system-ui, sans-serif';
  const metrics = ctx.measureText(text);
  const width = Math.min(246, Math.max(74, metrics.width + 30));
  ctx.fillStyle = 'rgba(2, 8, 14, .74)';
  ctx.strokeStyle = 'rgba(117, 213, 255, .35)';
  ctx.lineWidth = 1;
  const x = (256 - width) / 2;
  const y = 12;
  const h = 40;
  const r = 13;
  ctx.beginPath();
  ctx.roundRect(x, y, width, h, r);
  ctx.fill();
  ctx.stroke();
  ctx.fillStyle = '#edf7ff';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, 128, 32);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function makeSunTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');
  const gradient = ctx.createRadialGradient(128, 128, 8, 128, 128, 128);
  gradient.addColorStop(0, '#fffbe0');
  gradient.addColorStop(0.26, '#ffd36b');
  gradient.addColorStop(0.62, '#ff9f2f');
  gradient.addColorStop(1, 'rgba(255,130,20,0)');
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 256, 256);
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function makeJupiterTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');
  const bands = ['#c8aa8a', '#f0dcc1', '#a87d61', '#e8ceb0', '#8f6956', '#d8b99a', '#f0dac5', '#b38a6f'];
  const bandH = canvas.height / bands.length;
  bands.forEach((color, index) => {
    ctx.fillStyle = color;
    ctx.fillRect(0, index * bandH, canvas.width, bandH + 1);
  });
  ctx.fillStyle = 'rgba(155,70,48,.78)';
  ctx.beginPath();
  ctx.ellipse(350, 154, 55, 20, -0.08, 0, Math.PI * 2);
  ctx.fill();
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function makeSaturnTexture() {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 256;
  const ctx = canvas.getContext('2d');
  const colors = ['#d6c18f', '#eadba8', '#c3ad7d', '#f0dfae', '#bba678', '#e4d19b'];
  const h = canvas.height / colors.length;
  colors.forEach((color, index) => {
    ctx.fillStyle = color;
    ctx.fillRect(0, index * h, canvas.width, h + 1);
  });
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function createStars() {
  const count = 2800;
  const positions = new Float32Array(count * 3);
  for (let i = 0; i < count; i++) {
    const u = Math.random();
    const v = Math.random();
    const theta = 2 * Math.PI * u;
    const phi = Math.acos(2 * v - 1);
    const radius = 260 + Math.random() * 120;
    positions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
    positions[i * 3 + 1] = radius * Math.cos(phi);
    positions[i * 3 + 2] = radius * Math.sin(phi) * Math.sin(theta);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  const material = new THREE.PointsMaterial({ color: 0xcceeff, size: 0.36, sizeAttenuation: true, transparent: true, opacity: 0.85 });
  return new THREE.Points(geometry, material);
}

export class SolarSystemEngine {
  constructor(container, options = {}) {
    this.container = container;
    this.onSelectBody = options.onSelectBody || (() => {});
    this.onRequestEarth = options.onRequestEarth || (() => {});
    this.visible = false;
    this.bodyObjects = new Map();
    this.pickable = [];
    this.targetBodyId = 'sun';
    this.target = new THREE.Vector3(0, 0, 0);
    this.distance = 90;
    this.yaw = 0.75;
    this.pitch = 0.60;
    this.pointer = { down: false, moved: false, x: 0, y: 0 };

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x010409);

    this.camera = new THREE.PerspectiveCamera(48, 1, 0.05, 1200);
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
    this.renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.domElement.className = 'solar-canvas';
    this.container.appendChild(this.renderer.domElement);

    this.scene.add(new THREE.AmbientLight(0x7799bb, 0.16));
    this.scene.add(createStars());

    const sunLight = new THREE.PointLight(0xffffff, 3.6, 0, 1.2);
    sunLight.position.set(0, 0, 0);
    this.scene.add(sunLight);

    const sun = new THREE.Mesh(
      new THREE.SphereGeometry(2.4, 48, 32),
      new THREE.MeshBasicMaterial({ color: 0xffd56a })
    );
    sun.userData.body = {
      id: 'sun', name: 'Sun', type: 'Star', aAu: 0, periodDays: null, diameterKm: 1_392_700,
      rotation: '~25–35 d', visualRadius: 2.4, status: 'REFERENCE BODY', description: 'Central star of the Solar System.'
    };
    this.scene.add(sun);
    this.pickable.push(sun);
    this.bodyObjects.set('sun', { mesh: sun, label: this.createLabel('Sun', 3.6), body: sun.userData.body });

    const glowMaterial = new THREE.SpriteMaterial({ map: makeSunTexture(), color: 0xffffff, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    const glow = new THREE.Sprite(glowMaterial);
    glow.scale.set(13, 13, 1);
    sun.add(glow);

    this.earthTexture = new THREE.TextureLoader().load('/assets/earth-blue-marble.jpg', (texture) => {
      texture.colorSpace = THREE.SRGBColorSpace;
      const earthEntry = this.bodyObjects.get('earth');
      if (earthEntry?.mesh?.material) {
        earthEntry.mesh.material.map = texture;
        earthEntry.mesh.material.color.set(0xffffff);
        earthEntry.mesh.material.needsUpdate = true;
      }
    });

    for (const body of SOLAR_BODIES) this.addPlanet(body);
    this.addMoon();

    this.raycaster = new THREE.Raycaster();
    this.mouseNdc = new THREE.Vector2();
    this.installControls();
    this.resize();
    window.addEventListener('resize', () => this.resize());
    this.lastPositionUpdate = 0;
    this.updatePositions(new Date());
    this.updateCamera();
    this.animate();
  }

  createLabel(text, yOffset) {
    const material = new THREE.SpriteMaterial({ map: makeLabelTexture(text), transparent: true, depthTest: false, depthWrite: false });
    const sprite = new THREE.Sprite(material);
    sprite.scale.set(7.5, 1.9, 1);
    sprite.position.set(0, yOffset, 0);
    this.scene.add(sprite);
    return sprite;
  }

  addOrbit(body) {
    const radius = compressedOrbitRadius(body.aAu);
    const points = [];
    const incline = THREE.MathUtils.degToRad(body.inclinationDeg || 0);
    for (let i = 0; i <= 160; i++) {
      const a = (i / 160) * Math.PI * 2;
      points.push(new THREE.Vector3(
        Math.cos(a) * radius,
        Math.sin(a) * radius * Math.sin(incline) * 0.25,
        Math.sin(a) * radius
      ));
    }
    const geometry = new THREE.BufferGeometry().setFromPoints(points);
    const material = new THREE.LineBasicMaterial({ color: 0x315063, transparent: true, opacity: 0.34 });
    this.scene.add(new THREE.LineLoop(geometry, material));
  }

  addPlanet(body) {
    this.addOrbit(body);
    let material;
    if (body.id === 'jupiter') {
      material = new THREE.MeshPhongMaterial({ map: makeJupiterTexture(), shininess: 5 });
    } else if (body.id === 'saturn') {
      material = new THREE.MeshPhongMaterial({ map: makeSaturnTexture(), shininess: 4 });
    } else {
      material = new THREE.MeshPhongMaterial({ color: body.color, shininess: body.id === 'earth' ? 18 : 5 });
    }
    const mesh = new THREE.Mesh(new THREE.SphereGeometry(body.visualRadius, 40, 28), material);
    mesh.userData.body = body;
    this.scene.add(mesh);
    this.pickable.push(mesh);

    if (body.ring) {
      const ringGeometry = new THREE.RingGeometry(body.visualRadius * 1.38, body.visualRadius * 2.25, 96);
      const ringMaterial = new THREE.MeshBasicMaterial({ color: 0xd8c89b, side: THREE.DoubleSide, transparent: true, opacity: 0.72, depthWrite: false });
      const ring = new THREE.Mesh(ringGeometry, ringMaterial);
      ring.rotation.x = Math.PI / 2.25;
      mesh.add(ring);
    }

    const label = this.createLabel(body.name, body.visualRadius + 1.55);
    this.bodyObjects.set(body.id, { mesh, label, body });
  }

  addMoon() {
    const moonBody = {
      id: 'moon', name: 'Moon', type: 'Natural satellite', parent: 'earth', diameterKm: 3474.8,
      rotation: '27.3 d', periodDays: 27.3217, aAu: 0.00257, visualRadius: 0.30,
      description: 'Earth’s natural satellite.'
    };
    const moon = new THREE.Mesh(
      new THREE.SphereGeometry(moonBody.visualRadius, 28, 18),
      new THREE.MeshPhongMaterial({ color: 0xb9bdc2, shininess: 2 })
    );
    moon.userData.body = moonBody;
    this.scene.add(moon);
    this.pickable.push(moon);
    const label = this.createLabel('Moon', 0.95);
    this.bodyObjects.set('moon', { mesh: moon, label, body: moonBody });
  }

  updatePositions(date = new Date()) {
    const days = (date.getTime() - J2000_MS) / DAY_MS;
    for (const body of SOLAR_BODIES) {
      const entry = this.bodyObjects.get(body.id);
      if (!entry) continue;
      const radius = compressedOrbitRadius(body.aAu);
      const angle = THREE.MathUtils.degToRad(body.phaseDeg) + (days / body.periodDays) * Math.PI * 2;
      const incline = THREE.MathUtils.degToRad(body.inclinationDeg || 0);
      const x = Math.cos(angle) * radius;
      const z = Math.sin(angle) * radius;
      const y = Math.sin(angle) * radius * Math.sin(incline) * 0.25;
      entry.mesh.position.set(x, y, z);
      entry.label.position.set(x, y + body.visualRadius + 1.55, z);
      entry.mesh.rotation.y += 0.002;
    }

    const earth = this.bodyObjects.get('earth');
    const moon = this.bodyObjects.get('moon');
    if (earth && moon) {
      const moonAngle = (days / moon.body.periodDays) * Math.PI * 2;
      const moonRadius = 2.75;
      moon.mesh.position.set(
        earth.mesh.position.x + Math.cos(moonAngle) * moonRadius,
        earth.mesh.position.y + Math.sin(moonAngle * 0.41) * 0.25,
        earth.mesh.position.z + Math.sin(moonAngle) * moonRadius
      );
      moon.label.position.set(moon.mesh.position.x, moon.mesh.position.y + 0.95, moon.mesh.position.z);
    }

    if (this.targetBodyId && this.targetBodyId !== 'sun') {
      const targetEntry = this.bodyObjects.get(this.targetBodyId);
      if (targetEntry) this.target.copy(targetEntry.mesh.position);
    } else {
      this.target.set(0, 0, 0);
    }
  }

  installControls() {
    const canvas = this.renderer.domElement;
    canvas.addEventListener('contextmenu', (event) => event.preventDefault());
    canvas.addEventListener('pointerdown', (event) => {
      this.pointer.down = true;
      this.pointer.moved = false;
      this.pointer.x = event.clientX;
      this.pointer.y = event.clientY;
      canvas.setPointerCapture?.(event.pointerId);
    });
    canvas.addEventListener('pointermove', (event) => {
      if (!this.pointer.down) return;
      const dx = event.clientX - this.pointer.x;
      const dy = event.clientY - this.pointer.y;
      if (Math.abs(dx) + Math.abs(dy) > 2) this.pointer.moved = true;
      this.pointer.x = event.clientX;
      this.pointer.y = event.clientY;
      this.yaw -= dx * 0.006;
      this.pitch = Math.max(0.08, Math.min(Math.PI - 0.08, this.pitch + dy * 0.006));
      this.updateCamera();
    });
    canvas.addEventListener('pointerup', (event) => {
      const wasClick = this.pointer.down && !this.pointer.moved;
      this.pointer.down = false;
      if (wasClick) this.pick(event);
    });
    canvas.addEventListener('wheel', (event) => {
      event.preventDefault();
      const factor = Math.exp(event.deltaY * 0.00125);
      this.distance = Math.max(4, Math.min(190, this.distance * factor));
      this.updateCamera();
    }, { passive: false });
    canvas.addEventListener('dblclick', (event) => {
      const body = this.pick(event, false);
      if (body?.id === 'earth') this.onRequestEarth();
    });
  }

  pick(event, notify = true) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouseNdc.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouseNdc.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    this.raycaster.setFromCamera(this.mouseNdc, this.camera);
    const hits = this.raycaster.intersectObjects(this.pickable, false);
    const body = hits[0]?.object?.userData?.body || null;
    if (body && notify) this.onSelectBody(body);
    return body;
  }

  focusBody(id, notify = true) {
    const entry = this.bodyObjects.get(id);
    if (!entry) return false;
    this.targetBodyId = id;
    this.target.copy(entry.mesh.position);
    this.distance = id === 'sun' ? 28 : (id === 'jupiter' || id === 'saturn' ? 9 : 6.4);
    this.pitch = 0.78;
    this.updateCamera();
    if (notify) this.onSelectBody(entry.body);
    return true;
  }

  findBody(query) {
    const q = String(query || '').trim().toLowerCase();
    if (!q) return null;
    const aliases = { terra: 'earth', luna: 'moon', sol: 'sun' };
    const id = aliases[q] || q;
    if (this.bodyObjects.has(id)) return this.bodyObjects.get(id).body;
    for (const entry of this.bodyObjects.values()) {
      if (entry.body.name.toLowerCase().includes(q)) return entry.body;
    }
    return null;
  }

  getBodyPosition(id) {
    return this.bodyObjects.get(id)?.mesh?.position?.clone() || null;
  }

  getBody(id) {
    return this.bodyObjects.get(id)?.body || BODY_BY_ID.get(id) || null;
  }

  updateCamera() {
    const sinPitch = Math.sin(this.pitch);
    const offset = new THREE.Vector3(
      this.distance * sinPitch * Math.cos(this.yaw),
      this.distance * Math.cos(this.pitch),
      this.distance * sinPitch * Math.sin(this.yaw)
    );
    this.camera.position.copy(this.target).add(offset);
    this.camera.lookAt(this.target);
  }

  setVisible(visible) {
    this.visible = Boolean(visible);
    this.container.hidden = !this.visible;
    if (this.visible) {
      this.resize();
      this.updatePositions(new Date());
      this.updateCamera();
    }
  }

  resize() {
    const width = Math.max(1, this.container.clientWidth || window.innerWidth);
    const height = Math.max(1, this.container.clientHeight || window.innerHeight);
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
  }

  animate() {
    requestAnimationFrame(() => this.animate());
    if (!this.visible) return;
    const now = performance.now();
    if (now - this.lastPositionUpdate > 1000) {
      this.updatePositions(new Date());
      this.updateCamera();
      this.lastPositionUpdate = now;
    }
    this.renderer.render(this.scene, this.camera);
  }
}
