# LIVEWORLD v0.6.2 — Object Intelligence

v0.6.2 keeps the v0.5 Cesium + CelesTrak ACTIVE + OMM/SGP4 engine and upgrades the selected-object panel into a mission profile.

## New in v0.6.2

- Lazy-load CelesTrak SATCAT metadata only when an orbital object is selected.
- Calculate object age from `LAUNCH_DATE` through today (or through `DECAY_DATE` when present).
- Show launch date, owner/operator, launch site, orbit center/type, apogee, perigee, inclination and period.
- Separate `LIVE POSITION` from `MISSION HISTORY` so propagated coordinates are not confused with historical metadata.
- Add a local object profile registry at `public/data/object-profiles.json` for curated mission content.
- ISS profile includes an official NASA/Crew-2 photograph, a friendly mission name, Baikonur launch-site label, and continuous-human-presence age since 2 Nov 2000.
- SATCAT requests are cached in-memory in the browser session and at Nginx origin for 24 hours.
- Keeps v0.5 Worker/SGP4, `BillboardCollection`, search, Follow and Show Orbit behavior.

## Data sources

Position state:

```text
/api/celestrak/gp.php?GROUP=ACTIVE&FORMAT=JSON
CelesTrak ACTIVE OMM + satellite.js / SGP4
```

Mission metadata after click:

```text
/api/celestrak/satcat?CATNR=25544
-> https://celestrak.org/satcat/records.php?CATNR=25544
```

ISS hero photo:

```text
NASA image ID ISS066-E-080360
https://images-assets.nasa.gov/image/iss066e080360/iss066e080360~orig.jpg
```

The photo is loaded only when the ISS profile is opened. The profile links back to the NASA image article and displays `Photo: NASA / Crew-2`.

## Nginx

LIVEWORLD's active server cache zone is named **`celestrak_cache`**. Keep the name identical in both the `proxy_cache_path` declaration and every `proxy_cache` directive.

Install/update the cache definition:

```bash
sudo cp nginx/liveworld-cache.conf /etc/nginx/conf.d/liveworld-cache.conf
sudo mkdir -p /var/cache/nginx/liveworld-celestrak
sudo chown -R www-data:www-data /var/cache/nginx/liveworld-celestrak
```

Merge both CelesTrak locations from `nginx/liveword.conf.example` into the current HTTPS server block:

- exact `/api/celestrak/satcat` -> `celestrak.org/satcat/records.php`, cached 24h
- prefix `/api/celestrak/` -> `celestrak.org/NORAD/elements/`, ACTIVE feed cached 2h

Then:

```bash
sudo nginx -t
sudo systemctl reload nginx
```

Verify ISS metadata:

```bash
curl -sS -D - \
  'https://liveword.longh.org/api/celestrak/satcat?CATNR=25544' \
  -o /tmp/liveworld-iss-satcat.json

cat /tmp/liveworld-iss-satcat.json | jq
```

Run it twice. The second request should normally include:

```text
X-Liveworld-Cache: HIT
```

Verify ACTIVE still works:

```bash
curl -sS \
  'https://liveword.longh.org/api/celestrak/gp.php?GROUP=ACTIVE&FORMAT=JSON' \
  -o /tmp/liveworld-active.json

jq 'length' /tmp/liveworld-active.json
```

## Deploy frontend

```bash
chmod +x deploy.sh
./deploy.sh
```

The script syncs `public/` to:

```text
/var/www/liveword/public
```

Do not run `rsync --delete` from an unverified directory. The included script resolves its own directory first.

## Object profile registry

Curated profiles are keyed by NORAD catalog ID:

```json
{
  "25544": {
    "displayName": "International Space Station",
    "operator": "ISS Partners",
    "heroImage": "https://images-assets.nasa.gov/image/iss066e080360/iss066e080360~orig.jpg"
  }
}
```

SATCAT remains the factual source for launch/orbit metadata. The local profile registry is only for presentation data such as a friendly name, official image, image credit, mission note, and friendly operator/site label.

## Next recommended v0.6 steps

1. Add curated profiles for Tiangong, Hubble, JWST, Crew Dragon, Soyuz, Progress, Cygnus and notable probes.
2. Replace name-regex constellation detection with membership lists fetched from CelesTrak groups and mapped by NORAD ID.
3. Introduce far-view point LOD for the ~16k+ ACTIVE set while keeping stations/selected objects as billboards.
4. Add SupGP / operator-derived Starlink ephemeris as a higher-priority orbit source.
5. Start the body/reference-frame object model needed for Moon, Mars and interplanetary spacecraft.

## v0.6.2 — Solar System bridge

This build adds the first cross-body navigation layer while keeping the Earth/CelesTrak engine intact.

- Visible build badge `v0.6.2` in the header so deployment can be verified immediately.
- `EARTH / SOLAR` world switch.
- Automatic transition to Solar mode when the Cesium Earth camera is pulled beyond ~70,000 km altitude.
- Sun, Mercury, Venus, Earth, Moon, Mars, Jupiter, Saturn, Uranus, Neptune in a Three.js solar scene.
- Click/focus planets; search supports `Mars`, `Moon`, `Earth`, etc.
- Double-click Earth or use `EARTH` to return to the live CelesTrak view.
- Distances and sizes in Solar mode are intentionally compressed/exaggerated for navigation.
- Solar positions are a lightweight approximate heliocentric preview, clearly labelled APPROX. This is not spacecraft navigation-grade ephemeris. The next source-fusion step is JPL Horizons/SPICE.
- Object Intelligence from v0.6.1 remains in place: SATCAT lazy metadata, age since launch, mission history, ISS profile support.

### Deploy verification

After `./deploy.sh`, verify that the server is really serving this build:

```bash
curl -s https://liveword.longh.org/ | grep -E 'v0.6.2|app.js\\?v=6.2|styles.css\\?v=6.2'
```

You should see `v0.6.2` and asset query versions `6.2`. If the browser still shows the old compact object panel, the old frontend is still being served; this is a deployment/cache issue, not a SATCAT issue.
