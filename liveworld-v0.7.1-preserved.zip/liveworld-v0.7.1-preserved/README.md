# LIVEWORLD v0.7.1 — Warm Data + Earth Day/Night

This build fixes two core issues before adding more layers.

## 1. Warm boot orbital data

- Server refreshes CelesTrak `GROUP=ACTIVE&FORMAT=JSON` every 15 minutes.
- Snapshot is validated (`>10,000` OMM rows) and replaced atomically.
- Snapshot version is the SHA-256 hash of the actual catalog, so unchanged data does not force browser downloads.
- Browser persists the last valid catalog in IndexedDB.
- Returning visitors boot from IndexedDB immediately; network refresh happens in the background.
- If CelesTrak/network is down, the cached OMM snapshot still propagates locally with SGP4.

One-time server setup:

```bash
sudo bash server/install-live-data.sh
```

The public snapshot endpoints are:

- `/live-data/space-active.meta.json`
- `/live-data/space-active.json`

## 2. Real Earth day/night rendering

Cesium globe lighting remains enabled at every Earth zoom. Imagery layers use Cesium's native `dayAlpha` / `nightAlpha` split:

- Day: bundled NASA Blue Marble.
- Night: NASA Black Marble 2016 (Suomi NPP / VIIRS) city lights.
- ArcGIS detail imagery is nearly hidden on the night hemisphere so city lights remain readable.
- Earth no longer automatically jumps into Space mode when zoomed far away. EARTH/SPACE is user-controlled.

`deploy.sh` downloads the Black Marble texture once and self-hosts it under `/assets/`.

## Deploy

```bash
chmod +x deploy.sh
./deploy.sh
sudo bash server/install-live-data.sh   # one time only
```

Then hard refresh once (`Ctrl+Shift+R`). Subsequent visits use IndexedDB warm boot.

## Data provenance

- Orbital elements: CelesTrak ACTIVE OMM JSON, propagated in-browser with SGP4.
- Earth day texture: NASA Blue Marble.
- Earth night lights: NASA Black Marble 2016, Suomi NPP/VIIRS.
- Solar-system state vectors: JPL Horizons (existing v0.7.0 integration).
