#!/usr/bin/env bash
set -euo pipefail
DEST=/var/www/liveword/public
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ASSETS="$SCRIPT_DIR/public/assets"

ensure_image() {
  local target="$1"; shift
  if [[ -s "$target" ]] && [[ $(stat -c%s "$target") -gt 10000 ]]; then
    return 0
  fi
  mkdir -p "$(dirname "$target")"
  local tmp="${target}.tmp"
  rm -f "$tmp"
  for url in "$@"; do
    echo "==> Download asset: $(basename "$target")"
    if curl -fL --retry 2 --connect-timeout 15 --max-time 120 -A 'LIVEWORLD/0.7.1' "$url" -o "$tmp"; then
      mime="$(file -b --mime-type "$tmp" 2>/dev/null || true)"
      if [[ -s "$tmp" ]] && [[ $(stat -c%s "$tmp") -gt 10000 ]] && [[ "$mime" == image/* ]]; then
        mv -f "$tmp" "$target"
        return 0
      fi
    fi
    rm -f "$tmp"
  done
  echo "WARNING: could not download $(basename "$target"); LIVEWORLD will use its visual fallback."
  return 0
}

echo "==> Prepare NASA/JPL static imagery"
ensure_image "$ASSETS/earth-night-lights.jpg" \
  'https://eoimages.gsfc.nasa.gov/images/imagerecords/144000/144898/BlackMarble_2016_01deg.jpg'
ensure_image "$ASSETS/space/background/wise-allsky.jpg" \
  'https://assets.science.nasa.gov/dynamicimage/assets/science/psd/photojournal/pia/pia15/pia15481/PIA15481.jpg?fit=clip&w=4000' \
  'https://photojournal.jpl.nasa.gov/jpeg/PIA15481.jpg'
ensure_image "$ASSETS/space/planets/mercury.jpg" \
  'https://assets.science.nasa.gov/dynamicimage/assets/science/psd/photojournal/pia/pia15/pia15190/PIA15190.jpg?fit=clip&w=1600' \
  'https://photojournal.jpl.nasa.gov/jpeg/PIA15190.jpg'
ensure_image "$ASSETS/space/planets/venus.jpg" \
  'https://assets.science.nasa.gov/dynamicimage/assets/science/psd/photojournal/pia/pia00/pia00157/PIA00157.jpg?fit=clip&w=1600' \
  'https://photojournal.jpl.nasa.gov/jpeg/PIA00157.jpg'
ensure_image "$ASSETS/space/planets/moon.jpg" \
  'https://assets.science.nasa.gov/dynamicimage/assets/science/psd/photojournal/pia/pia14/pia14114/PIA14114.jpg?fit=clip&w=1600' \
  'https://photojournal.jpl.nasa.gov/jpeg/PIA14114.jpg'
ensure_image "$ASSETS/space/planets/mars.jpg" \
  'https://assets.science.nasa.gov/dynamicimage/assets/science/psd/photojournal/pia/pia00/pia00407/PIA00407.jpg?fit=clip&w=1600' \
  'https://photojournal.jpl.nasa.gov/jpeg/PIA00407.jpg'
ensure_image "$ASSETS/space/planets/jupiter.jpg" \
  'https://assets.science.nasa.gov/dynamicimage/assets/science/psd/photojournal/pia/pia01/pia01509/PIA01509.jpg?fit=clip&w=1600' \
  'https://photojournal.jpl.nasa.gov/jpeg/PIA01509.jpg'
ensure_image "$ASSETS/space/planets/saturn.jpg" \
  'https://assets.science.nasa.gov/dynamicimage/assets/science/psd/photojournal/pia/pia05/pia05389/PIA05389.jpg?fit=clip&w=1800' \
  'https://photojournal.jpl.nasa.gov/jpeg/PIA05389.jpg'
ensure_image "$ASSETS/space/planets/uranus.jpg" \
  'https://assets.science.nasa.gov/dynamicimage/assets/science/psd/photojournal/pia/pia18/pia18182/PIA18182.jpg?fit=clip&w=1600' \
  'https://photojournal.jpl.nasa.gov/jpeg/PIA18182.jpg'
ensure_image "$ASSETS/space/planets/neptune.jpg" \
  'https://assets.science.nasa.gov/dynamicimage/assets/science/psd/photojournal/pia/pia02/pia02210/PIA02210.jpg?fit=clip&w=1600' \
  'https://photojournal.jpl.nasa.gov/jpeg/PIA02210.jpg'

echo "==> Deploy LIVEWORLD v0.7.1-preserved"
sudo mkdir -p "$DEST"
sudo rsync -a --delete "$SCRIPT_DIR/public/" "$DEST/"
sudo chown -R www-data:www-data /var/www/liveword
sudo find /var/www/liveword -type d -exec chmod 755 {} \;
sudo find /var/www/liveword -type f -exec chmod 644 {} \;

echo "==> Local deploy check"
grep -q 'v0.7.1-preserved' "$DEST/index.html"
grep -q 'app.js?v=7.1-preserved' "$DEST/index.html"
grep -q 'styles.css?v=7.1-preserved' "$DEST/index.html"
grep -q 'solar-system.js?v=7.1-preserved' "$DEST/app.js"
test -f "$DEST/solar-system.js"
test -f "$DEST/assets/earth-blue-marble.jpg"
test -s "$DEST/assets/earth-blue-marble-master-5400x2700.jpg"
test -s "$DEST/assets/earth-blue-marble-web-3600x1800.jpg"

if [[ -s "$DEST/assets/earth-night-lights.jpg" ]]; then
  echo "OK: NASA Black Marble night-lights texture installed"
else
  echo "WARNING: night-lights texture missing"
fi

echo "OK: LIVEWORLD v0.7.1-preserved copied to $DEST"
echo "One-time warm-cache setup (if not already done):"
echo "  sudo bash $SCRIPT_DIR/server/install-live-data.sh"
echo "Verify:"
echo "  curl -s https://liveword.longh.org/ | grep -E 'v0.7.1|app.js\\?v=7.1|styles.css\\?v=7.1'"
echo "  curl -s https://liveword.longh.org/live-data/space-active.meta.json | python3 -m json.tool"
