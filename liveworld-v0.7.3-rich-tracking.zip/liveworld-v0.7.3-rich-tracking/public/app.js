import * as satellite from 'https://cdn.jsdelivr.net/npm/satellite.js@7.1.0/+esm';

const ORBIT_GROUP = 'ACTIVE';
const ORBIT_ENDPOINT = `/api/celestrak/gp.php?GROUP=${ORBIT_GROUP}&FORMAT=JSON`;
const ORBIT_SNAPSHOT_META = '/live-data/space-active.meta.json';
const ORBIT_SNAPSHOT_DATA = '/live-data/space-active.json';
const ORBIT_CACHE_DB = 'liveworld-cache-v1';
const ORBIT_CACHE_STORE = 'orbit';
const ORBIT_CACHE_KEY = 'active';
const SATCAT_ENDPOINT = (norad) => `/api/celestrak/satcat?CATNR=${encodeURIComponent(norad)}`;
const PROFILE_ENDPOINT = '/data/object-profiles.json?v=7.3-rich';
const NASA_IMAGE_SEARCH = 'https://images-api.nasa.gov/search';
const MAP_TILE_URL = 'https://tile.openstreetmap.org/{z}/{x}/{y}.png';
const MAP_MAX_ZOOM = 19;
const EXTERNAL_LAYER_CONFIG = {
  air: { endpoint: '/live-data/aircraft.json', category: 'aircraft', label: 'Aircraft / ADS-B', refreshMs: 5000 },
  sea: { endpoint: '/live-data/ships.json', category: 'ship', label: 'Ships / AIS', refreshMs: 15000 },
  rail: { endpoint: '/live-data/rail.json', category: 'train', label: 'High-speed rail', refreshMs: 10000 },
  launch: { endpoint: '/live-data/launch.json', category: 'rocket', label: 'Rocket / launch telemetry', refreshMs: 5000 },
};
const EARTH_RADIUS_KM = 6378.137;
const POSITION_APPLY_BATCH = 1400;

const ICONS = {
  satellite: '/assets/icons/satellite.svg',
  station: '/assets/icons/station.svg',
  spacecraft: '/assets/icons/spacecraft.svg',
  debris: '/assets/icons/debris.svg',
  aircraft: '/assets/icons/aircraft.svg',
  ship: '/assets/icons/ship.svg',
  train: '/assets/icons/train.svg',
  rocket: '/assets/icons/rocket.svg',
  lunar_base: '/assets/icons/station.svg',
};

const TYPE_LABEL = {
  satellite: 'SATELLITE',
  station: 'SPACE STATION',
  spacecraft: 'SPACECRAFT',
  debris: 'ORBITAL OBJECT',
  aircraft: 'AIRCRAFT',
  ship: 'SHIP',
  train: 'TRAIN',
  rocket: 'ROCKET',
  lunar_base: 'LUNAR BASE',
};

const OWNER_LABELS = {
  ISS: 'ISS Partners', US: 'United States', CIS: 'Russia / CIS', PRC: 'China',
  ESA: 'European Space Agency', JPN: 'Japan', IND: 'India', FR: 'France',
  CA: 'Canada', UK: 'United Kingdom', IT: 'Italy', GER: 'Germany',
};

const LAUNCH_SITE_LABELS = {
  TYMSC: 'Baikonur Cosmodrome · Kazakhstan', AFETR: 'Cape Canaveral SFS · USA',
  AFWTR: 'Vandenberg SFB · USA', KSCUT: 'Kennedy Space Center · USA',
  FRGUI: 'Guiana Space Centre · Kourou', PLMSC: 'Plesetsk Cosmodrome · Russia',
  VOSTO: 'Vostochny Cosmodrome · Russia', XICLF: 'Xichang Satellite Launch Center · China',
  WSC: 'Wenchang Space Launch Site · China', TAISC: 'Taiyuan Satellite Launch Center · China',
  JSC: 'Jiuquan Satellite Launch Center · China', TANSC: 'Tanegashima Space Center · Japan',
  SRILR: 'Satish Dhawan Space Centre · India',
};

const state = {
  renderer: null,
  surfaceMap: null,
  orbitObjects: [],
  externalLayers: { air: [], sea: [], rail: [], launch: [] },
  externalEnabled: { air: false, sea: false, rail: false, launch: false },
  externalTimers: {},
  selected: null,
  orbitLayerVisible: true,
  following: false,
  worker: null,
  firstPositionFrame: false,
  pendingFrame: null,
  sourceLoadedAt: null,
  catalogCounts: {},
  satcatCache: new Map(),
  nasaImageCache: new Map(),
  profiles: {},
  orbitPath: null,
  orbitCatalogVersion: '',
  orbitCatalogGeneratedAt: null,
  orbitCatalogSource: 'network',
  lastOrbitStatus: '',
};

const $ = (id) => document.getElementById(id);
const panel = $('panel');
const statusText = $('statusText');
const tooltip = $('tooltip');

function clamp(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }
function toRad(v) { return v * Math.PI / 180; }
function toDeg(v) { return v * 180 / Math.PI; }
function wrapLon(v) { let x = ((v + 180) % 360 + 360) % 360 - 180; return x === -180 ? 180 : x; }

function classifyOrbitObject(row) {
  const name = String(row.OBJECT_NAME || '').toUpperCase();
  if (/^(ISS\b|CSS\b|TIANGONG\b)/.test(name) || name.includes('SPACE STATION')) return 'station';
  if (/(CREW DRAGON|DRAGON|CYGNUS|SOYUZ|PROGRESS|TIANZHOU|SHENZHOU|STARLINER|HTV-X|HTV\b)/.test(name)) return 'spacecraft';
  if (/(\bDEB\b|DEBRIS|\bR\/B\b|ROCKET BODY)/.test(name)) return 'debris';
  return 'satellite';
}

function constellationOf(nameRaw) {
  const name = String(nameRaw || '').toUpperCase();
  if (name.startsWith('STARLINK')) return 'Starlink';
  if (name.startsWith('ONEWEB')) return 'OneWeb';
  if (/\bGPS\b|NAVSTAR/.test(name)) return 'GPS';
  if (/GALILEO/.test(name)) return 'Galileo';
  if (/GLONASS/.test(name)) return 'GLONASS';
  if (/BEIDOU|COMPASS/.test(name)) return 'BeiDou';
  if (/QZS|QZSS/.test(name)) return 'QZSS';
  if (/IRNSS|NAVIC/.test(name)) return 'NavIC';
  if (/KUIPER/.test(name)) return 'Kuiper';
  if (/QIANFAN|G60/.test(name)) return 'Qianfan';
  return 'Other';
}

function safeText(value, fallback = '—') {
  const text = String(value ?? '').trim();
  return text || fallback;
}

function formatDate(value) {
  if (!value) return '—';
  const date = new Date(`${value}T00:00:00Z`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat('en', { day: '2-digit', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(date);
}

function ageBetween(startValue, endValue = new Date()) {
  if (!startValue) return null;
  const start = new Date(`${startValue}T00:00:00Z`);
  const end = endValue instanceof Date ? new Date(endValue) : new Date(`${endValue}T00:00:00Z`);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end < start) return null;
  let years = end.getUTCFullYear() - start.getUTCFullYear();
  let months = end.getUTCMonth() - start.getUTCMonth();
  let days = end.getUTCDate() - start.getUTCDate();
  if (days < 0) { months -= 1; days += new Date(Date.UTC(end.getUTCFullYear(), end.getUTCMonth(), 0)).getUTCDate(); }
  if (months < 0) { years -= 1; months += 12; }
  const totalDays = Math.floor((Date.UTC(end.getUTCFullYear(), end.getUTCMonth(), end.getUTCDate()) - start.getTime()) / 86400000);
  return { years, months, days, totalDays };
}

function formatAge(age) {
  if (!age) return '—';
  if (age.years > 0) return `${age.years} yr ${age.months} mo`;
  if (age.months > 0) return `${age.months} mo ${age.days} d`;
  return `${Math.max(0, age.days)} d`;
}

function ownerLabel(code) { const raw = safeText(code, ''); return OWNER_LABELS[raw] || raw || '—'; }
function launchSiteLabel(code) { const raw = safeText(code, ''); return LAUNCH_SITE_LABELS[raw] || raw || '—'; }
function orbitSummary(meta) {
  if (!meta) return '—';
  const center = meta.ORBIT_CENTER === 'EA' ? 'Earth' : safeText(meta.ORBIT_CENTER, '');
  const type = meta.ORBIT_TYPE === 'ORB' ? 'Orbit' : safeText(meta.ORBIT_TYPE, '');
  return [center, type].filter(Boolean).join(' · ') || '—';
}

function solarDirection(date = new Date()) {
  const start = Date.UTC(date.getUTCFullYear(), 0, 0);
  const day = (date.getTime() - start) / 86400000;
  const minutes = date.getUTCHours() * 60 + date.getUTCMinutes() + date.getUTCSeconds() / 60;
  const gamma = 2 * Math.PI / 365 * (day - 1 + (minutes / 60 - 12) / 24);
  const eq = 229.18 * (0.000075 + 0.001868 * Math.cos(gamma) - 0.032077 * Math.sin(gamma) - 0.014615 * Math.cos(2 * gamma) - 0.040849 * Math.sin(2 * gamma));
  const dec = 0.006918 - 0.399912 * Math.cos(gamma) + 0.070257 * Math.sin(gamma) - 0.006758 * Math.cos(2 * gamma) + 0.000907 * Math.sin(2 * gamma) - 0.002697 * Math.cos(3 * gamma) + 0.00148 * Math.sin(3 * gamma);
  const subsolarLon = toRad(wrapLon((720 - minutes - eq) / 4));
  return [Math.cos(dec) * Math.cos(subsolarLon), Math.cos(dec) * Math.sin(subsolarLon), Math.sin(dec)];
}

class EarthCanvasRenderer {
  constructor(container) {
    this.container = container;
    this.canvas = document.createElement('canvas');
    this.canvas.className = 'earth-canvas';
    this.canvas.setAttribute('aria-label', 'LIVEWORLD Earth tracker');
    this.container.querySelector('.earth-canvas')?.remove();
    const surfaceNode = this.container.querySelector('#surfaceMap');
    this.container.insertBefore(this.canvas, surfaceNode || null);
    this.ctx = this.canvas.getContext('2d', { alpha: false });
    if (!this.ctx) throw new Error('Canvas 2D is not available in this browser.');

    this.lon = 105;
    this.lat = 18;
    this.zoom = 0.9;
    this.width = 1;
    this.height = 1;
    this.radius = 1;
    this.centerX = 0;
    this.centerY = 0;
    this.objects = [];
    this.orbitVisible = true;
    this.selected = null;
    this.orbitPath = null;
    this.hitPoints = [];
    this.pointer = { down: false, moved: false, id: null, x: 0, y: 0, lon: 0, lat: 0 };
    this.onPick = null;
    this.onHover = null;
    this.onViewChange = null;
    this.onRequestSurface = null;
    this.earthDirty = true;
    this.lastEarthRenderAt = 0;
    this.lastFrameAt = 0;
    this.anim = 0;
    this.starSeed = this.buildStars(260);
    this.icons = {};
    this.profileImages = new Map();
    this.sourceCanvas = document.createElement('canvas');
    this.sourceCtx = this.sourceCanvas.getContext('2d', { willReadFrequently: true });
    this.sourcePixels = null;
    this.globeCanvas = document.createElement('canvas');
    this.globeCtx = this.globeCanvas.getContext('2d');
    this.precompute = null;
    this.loadIcons();
    this.loadEarth();
    this.installEvents();
    this.resize();
    window.addEventListener('resize', () => this.resize(), { passive: true });
    this.loop();
  }

  loadIcons() {
    for (const [key, src] of Object.entries(ICONS)) {
      const img = new Image();
      img.decoding = 'async';
      img.src = src;
      this.icons[key] = img;
    }
  }

  profileMarkerImage(obj) {
    const src = obj?.profile?.markerImage || (obj?.category === 'station' ? obj?.profile?.heroImage : '');
    if (!src) return null;
    if (!this.profileImages.has(src)) {
      const img = new Image();
      img.decoding = 'async';
      img.referrerPolicy = 'no-referrer';
      img.onload = () => this.draw();
      img.onerror = () => { img.failed = true; };
      img.src = src;
      this.profileImages.set(src, img);
    }
    const img = this.profileImages.get(src);
    return img && img.complete && img.naturalWidth && !img.failed ? img : null;
  }

  loadEarth() {
    const img = new Image();
    img.decoding = 'async';
    img.onload = () => {
      const w = 1440, h = 720;
      this.sourceCanvas.width = w;
      this.sourceCanvas.height = h;
      this.sourceCtx.drawImage(img, 0, 0, w, h);
      this.sourcePixels = this.sourceCtx.getImageData(0, 0, w, h).data;
      this.earthDirty = true;
      this.draw();
    };
    img.onerror = () => {
      console.warn('Earth texture unavailable; using procedural ocean/land tint.');
      this.sourcePixels = null;
      this.earthDirty = true;
    };
    img.src = '/assets/earth-blue-marble-web-3600x1800.jpg?v=7.3-rich';
  }

  buildStars(count) {
    const stars = [];
    let seed = 917231;
    const rnd = () => { seed = (seed * 16807) % 2147483647; return (seed - 1) / 2147483646; };
    for (let i = 0; i < count; i++) stars.push([rnd(), rnd(), 0.25 + rnd() * 0.75, 0.45 + rnd() * 1.4]);
    return stars;
  }

  resize() {
    const rect = this.container.getBoundingClientRect();
    const dpr = Math.min(2, window.devicePixelRatio || 1);
    this.width = Math.max(320, rect.width || window.innerWidth);
    this.height = Math.max(320, rect.height || window.innerHeight);
    this.canvas.width = Math.round(this.width * dpr);
    this.canvas.height = Math.round(this.height * dpr);
    this.canvas.style.width = `${this.width}px`;
    this.canvas.style.height = `${this.height}px`;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.updateGeometry();
    this.earthDirty = true;
  }

  updateGeometry() {
    const base = Math.min(this.width, this.height) * 0.31;
    this.radius = base * this.zoom;
    this.centerX = this.width * 0.5;
    this.centerY = this.height * 0.52;
  }

  installEvents() {
    this.canvas.addEventListener('pointerdown', (e) => {
      this.canvas.setPointerCapture?.(e.pointerId);
      this.pointer = { down: true, moved: false, id: e.pointerId, x: e.clientX, y: e.clientY, lon: this.lon, lat: this.lat };
    });
    this.canvas.addEventListener('pointermove', (e) => {
      if (this.pointer.down) {
        const dx = e.clientX - this.pointer.x;
        const dy = e.clientY - this.pointer.y;
        if (Math.abs(dx) + Math.abs(dy) > 3) this.pointer.moved = true;
        this.lon = wrapLon(this.pointer.lon - dx * 0.23 / Math.max(0.55, this.zoom));
        this.lat = clamp(this.pointer.lat + dy * 0.18 / Math.max(0.55, this.zoom), -85, 85);
        this.earthDirty = true;
        this.onViewChange?.();
      } else {
        const hit = this.pickAt(e.offsetX, e.offsetY, 9);
        this.canvas.style.cursor = hit ? 'pointer' : 'grab';
        this.onHover?.(hit, e);
      }
    });
    const end = (e) => {
      if (!this.pointer.down) return;
      const moved = this.pointer.moved;
      this.pointer.down = false;
      try { this.canvas.releasePointerCapture?.(e.pointerId); } catch {}
      if (!moved) {
        const rect = this.canvas.getBoundingClientRect();
        const hit = this.pickAt(e.clientX - rect.left, e.clientY - rect.top, 12);
        if (hit) this.onPick?.(hit);
      }
    };
    this.canvas.addEventListener('pointerup', end);
    this.canvas.addEventListener('pointercancel', end);
    this.canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      const factor = Math.exp(-e.deltaY * 0.0012);
      this.zoom = clamp(this.zoom * factor, 0.48, 4.5);
      if (this.zoom >= 4.18 && e.deltaY < 0 && this.onRequestSurface) {
        this.zoom = 4.0;
        this.updateGeometry();
        this.earthDirty = true;
        this.onViewChange?.();
        this.onRequestSurface({ lat: this.lat, lon: this.lon });
        return;
      }
      this.updateGeometry();
      this.earthDirty = true;
      this.onViewChange?.();
    }, { passive: false });

    const touchDistance = (touches) => Math.hypot(touches[0].clientX - touches[1].clientX, touches[0].clientY - touches[1].clientY);
    this.canvas.addEventListener('touchstart', (e) => {
      if (e.touches.length === 2) this.touchPinch = { distance: touchDistance(e.touches), zoom: this.zoom };
    }, { passive: true });
    this.canvas.addEventListener('touchmove', (e) => {
      if (e.touches.length !== 2 || !this.touchPinch) return;
      e.preventDefault();
      const d = touchDistance(e.touches);
      if (!Number.isFinite(d) || d <= 0) return;
      this.zoom = clamp(this.touchPinch.zoom * (d / Math.max(1, this.touchPinch.distance)), 0.48, 4.5);
      if (this.zoom >= 4.18 && this.onRequestSurface) {
        this.zoom = 4.0;
        this.updateGeometry();
        this.earthDirty = true;
        this.onRequestSurface({ lat: this.lat, lon: this.lon });
        this.touchPinch = null;
        return;
      }
      this.updateGeometry();
      this.earthDirty = true;
      this.onViewChange?.();
    }, { passive: false });
    this.canvas.addEventListener('touchend', () => { this.touchPinch = null; }, { passive: true });
  }

  setObjects(objects) { this.objects = objects || []; }
  setOrbitVisible(v) { this.orbitVisible = !!v; }
  setSelected(obj) { this.selected = obj || null; }
  setOrbitPath(path) { this.orbitPath = path || null; }
  centerOn(lat, lon, zoom = null) {
    if (Number.isFinite(lon)) this.lon = wrapLon(lon);
    if (Number.isFinite(lat)) this.lat = clamp(lat, -85, 85);
    if (Number.isFinite(zoom)) { this.zoom = clamp(zoom, 0.48, 4.5); this.updateGeometry(); }
    this.earthDirty = true;
  }

  basis() {
    const lon0 = toRad(this.lon), lat0 = toRad(this.lat);
    const sinLon = Math.sin(lon0), cosLon = Math.cos(lon0), sinLat = Math.sin(lat0), cosLat = Math.cos(lat0);
    return {
      east: [-sinLon, cosLon, 0],
      north: [-sinLat * cosLon, -sinLat * sinLon, cosLat],
      forward: [cosLat * cosLon, cosLat * sinLon, sinLat],
    };
  }

  ensureGlobeBuffers() {
    const target = clamp(Math.round(Math.min(560, Math.max(260, this.radius * 1.25))), 260, 560);
    if (this.globeCanvas.width === target && this.precompute) return;
    this.globeCanvas.width = target;
    this.globeCanvas.height = target;
    const count = target * target;
    const xs = new Float32Array(count), ys = new Float32Array(count), zs = new Float32Array(count);
    const mask = new Uint8Array(count);
    let idx = 0;
    for (let py = 0; py < target; py++) {
      const y = 1 - ((py + 0.5) / target) * 2;
      for (let px = 0; px < target; px++, idx++) {
        const x = ((px + 0.5) / target) * 2 - 1;
        const r2 = x * x + y * y;
        if (r2 <= 1) { mask[idx] = 1; xs[idx] = x; ys[idx] = y; zs[idx] = Math.sqrt(1 - r2); }
      }
    }
    this.precompute = { target, xs, ys, zs, mask };
  }

  renderEarthRaster() {
    this.ensureGlobeBuffers();
    const { target, xs, ys, zs, mask } = this.precompute;
    const image = this.globeCtx.createImageData(target, target);
    const out = image.data;
    const basis = this.basis();
    const sun = solarDirection(new Date());
    const src = this.sourcePixels;
    const sw = this.sourceCanvas.width || 1, sh = this.sourceCanvas.height || 1;
    const useTexture = !!(src && sw > 1 && sh > 1);

    for (let i = 0, o = 0; i < mask.length; i++, o += 4) {
      if (!mask[i]) { out[o + 3] = 0; continue; }
      const x = xs[i], y = ys[i], z = zs[i];
      const vx = basis.east[0] * x + basis.north[0] * y + basis.forward[0] * z;
      const vy = basis.east[1] * x + basis.north[1] * y + basis.forward[1] * z;
      const vz = basis.east[2] * x + basis.north[2] * y + basis.forward[2] * z;
      const lon = Math.atan2(vy, vx);
      const lat = Math.asin(clamp(vz, -1, 1));
      const u = ((lon + Math.PI) / (2 * Math.PI) * sw + sw) % sw;
      const v = clamp((Math.PI / 2 - lat) / Math.PI * sh, 0, sh - 1);
      const si = ((v | 0) * sw + (u | 0)) * 4;
      let r = 14, g = 43, b = 66;
      if (useTexture) { r = src[si]; g = src[si + 1]; b = src[si + 2]; }
      const daylight = Math.max(-0.08, vx * sun[0] + vy * sun[1] + vz * sun[2]);
      const light = daylight > 0 ? 0.38 + 0.72 * Math.pow(daylight, 0.42) : 0.15;
      const limb = 0.72 + 0.28 * Math.pow(z, 0.35);
      out[o] = clamp(r * light * limb, 0, 255);
      out[o + 1] = clamp(g * light * limb, 0, 255);
      out[o + 2] = clamp(b * light * limb + (1 - z) * 11, 0, 255);
      out[o + 3] = 255;
    }
    this.globeCtx.putImageData(image, 0, 0);
    this.earthDirty = false;
    this.lastEarthRenderAt = performance.now();
  }

  project(latDeg, lonDeg, altitudeKm = 0) {
    const lat = toRad(latDeg), lon = toRad(lonDeg);
    const cosLat = Math.cos(lat);
    const vx = cosLat * Math.cos(lon), vy = cosLat * Math.sin(lon), vz = Math.sin(lat);
    const b = this.basis();
    const scale = 1 + Math.max(-100, altitudeKm || 0) / EARTH_RADIUS_KM;
    const x = scale * (vx * b.east[0] + vy * b.east[1] + vz * b.east[2]);
    const y = scale * (vx * b.north[0] + vy * b.north[1] + vz * b.north[2]);
    const z = scale * (vx * b.forward[0] + vy * b.forward[1] + vz * b.forward[2]);
    const hiddenByEarth = z < 0 && x * x + y * y < 1;
    return { x: this.centerX + x * this.radius, y: this.centerY - y * this.radius, z, hiddenByEarth };
  }

  drawStars(ctx) {
    ctx.save();
    ctx.fillStyle = '#010409';
    ctx.fillRect(0, 0, this.width, this.height);
    for (const [sx, sy, a, r] of this.starSeed) {
      ctx.globalAlpha = a;
      ctx.fillStyle = '#d9efff';
      ctx.beginPath();
      ctx.arc(sx * this.width, sy * this.height, r, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.restore();
  }

  drawAtmosphere(ctx) {
    const r = this.radius;
    const g = ctx.createRadialGradient(this.centerX, this.centerY, r * 0.8, this.centerX, this.centerY, r * 1.12);
    g.addColorStop(0, 'rgba(40,155,225,0)');
    g.addColorStop(0.86, 'rgba(74,184,245,.08)');
    g.addColorStop(0.96, 'rgba(90,207,255,.24)');
    g.addColorStop(1, 'rgba(90,207,255,0)');
    ctx.fillStyle = g;
    ctx.beginPath(); ctx.arc(this.centerX, this.centerY, r * 1.12, 0, Math.PI * 2); ctx.fill();
  }

  drawOrbitPath(ctx) {
    if (!Array.isArray(this.orbitPath) || this.orbitPath.length < 2) return;
    ctx.save();
    ctx.lineWidth = 1.2;
    ctx.strokeStyle = 'rgba(117,213,255,.62)';
    let drawing = false;
    ctx.beginPath();
    for (const p of this.orbitPath) {
      const q = this.project(p.lat, p.lon, p.altitudeKm);
      const visible = !q.hiddenByEarth && q.x > -100 && q.x < this.width + 100 && q.y > -100 && q.y < this.height + 100;
      if (!visible) { drawing = false; continue; }
      if (!drawing) { ctx.moveTo(q.x, q.y); drawing = true; } else ctx.lineTo(q.x, q.y);
    }
    ctx.stroke();
    ctx.restore();
  }

  drawObjects(ctx) {
    this.hitPoints.length = 0;
    const surfaceMode = this.zoom > 2.55;
    const satelliteIconMode = this.zoom > 1.62;
    let visibleCount = 0;
    const selected = this.selected;

    for (const obj of this.objects) {
      if (!this.orbitVisible && obj.kind === 'orbit') continue;
      if (!obj.hasPosition) continue;
      if (surfaceMode && obj.kind === 'orbit' && obj !== selected && obj.category !== 'station' && obj.category !== 'spacecraft') continue;
      const p = this.project(obj.lat, obj.lon, obj.altitudeKm);
      if (p.hiddenByEarth || p.x < -44 || p.x > this.width + 44 || p.y < -44 || p.y > this.height + 44) continue;
      visibleCount++;
      const isSelected = obj === selected;
      const realImage = this.profileMarkerImage(obj);
      const typeSize = { station: 24, spacecraft: 18, aircraft: 18, ship: 18, train: 18, rocket: 20, lunar_base: 22, debris: 2, satellite: 3 };
      let size = typeSize[obj.category] || 14;
      if (obj.category === 'satellite' && satelliteIconMode) size = this.zoom > 2.2 ? 12 : 9;
      if (isSelected) size = realImage ? 38 : Math.max(30, size + 10);
      const img = realImage || this.icons[obj.category] || this.icons.satellite;
      const useIcon = isSelected || !!realImage || obj.kind !== 'orbit' || obj.category === 'station' || obj.category === 'spacecraft' || (obj.category === 'satellite' && satelliteIconMode);

      if (useIcon && img?.complete && img.naturalWidth) {
        ctx.save();
        if (!isSelected) ctx.globalAlpha = obj.category === 'satellite' ? 0.76 : 0.95;
        if (realImage) {
          ctx.beginPath();
          ctx.arc(p.x, p.y, size * 0.5, 0, Math.PI * 2);
          ctx.clip();
          ctx.drawImage(img, p.x - size / 2, p.y - size / 2, size, size);
          ctx.restore();
          ctx.save();
          ctx.strokeStyle = 'rgba(222,246,255,.88)';
          ctx.lineWidth = isSelected ? 1.7 : 1;
          ctx.beginPath(); ctx.arc(p.x, p.y, size * 0.5, 0, Math.PI * 2); ctx.stroke();
        } else {
          ctx.drawImage(img, p.x - size / 2, p.y - size / 2, size, size);
        }
        ctx.restore();
      } else {
        ctx.save();
        ctx.globalAlpha = obj.category === 'debris' ? 0.35 : 0.78;
        ctx.fillStyle = obj.category === 'debris' ? '#ffcc7a' : '#9edfff';
        ctx.beginPath();
        if (size <= 2.5) ctx.arc(p.x, p.y, size * 0.5, 0, Math.PI * 2);
        else { ctx.moveTo(p.x, p.y - size); ctx.lineTo(p.x + size * .72, p.y); ctx.lineTo(p.x, p.y + size); ctx.lineTo(p.x - size * .72, p.y); ctx.closePath(); }
        ctx.fill();
        ctx.restore();
      }

      if (isSelected) {
        ctx.save();
        ctx.strokeStyle = 'rgba(117,213,255,.95)'; ctx.lineWidth = 1.3;
        ctx.beginPath(); ctx.arc(p.x, p.y, Math.max(18, size * .65), 0, Math.PI * 2); ctx.stroke();
        ctx.fillStyle = '#edf7ff'; ctx.font = '700 11px ui-monospace, monospace';
        ctx.textAlign = 'center'; ctx.fillText(obj.name, p.x, p.y - Math.max(25, size * .65 + 8));
        ctx.restore();
      }
      this.hitPoints.push({ obj, x: p.x, y: p.y, size: Math.max(9, size) });
    }
    this.visibleObjectCount = visibleCount;
  }

  pickAt(x, y, tolerance = 10) {
    let best = null, bestD = Infinity;
    for (const h of this.hitPoints) {
      const dx = h.x - x, dy = h.y - y;
      const d = Math.hypot(dx, dy);
      const limit = Math.max(tolerance, h.size * 0.8);
      if (d <= limit && d < bestD) { best = h.obj; bestD = d; }
    }
    return best;
  }

  draw() {
    const now = performance.now();
    const ctx = this.ctx;
    this.drawStars(ctx);
    this.drawAtmosphere(ctx);
    if (this.earthDirty && (now - this.lastEarthRenderAt > (this.pointer.down ? 90 : 20))) this.renderEarthRaster();
    if (this.globeCanvas.width) {
      ctx.save();
      ctx.beginPath(); ctx.arc(this.centerX, this.centerY, this.radius, 0, Math.PI * 2); ctx.clip();
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(this.globeCanvas, this.centerX - this.radius, this.centerY - this.radius, this.radius * 2, this.radius * 2);
      ctx.restore();
      ctx.save();
      ctx.strokeStyle = 'rgba(160,225,255,.28)'; ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(this.centerX, this.centerY, this.radius, 0, Math.PI * 2); ctx.stroke(); ctx.restore();
    }
    this.drawOrbitPath(ctx);
    this.drawObjects(ctx);
    this.lastFrameAt = now;
  }

  loop() {
    this.draw();
    this.anim = requestAnimationFrame(() => this.loop());
  }
}


class SurfaceMapController {
  constructor(container) {
    this.container = container;
    this.map = null;
    this.active = false;
    this.objects = [];
    this.selected = null;
    this.orbitVisible = true;
    this.markerLayer = null;
    this.dotLayer = null;
    this.trajectoryLayer = null;
    this.orbitPath = null;
    this.canvasRenderer = null;
    this.onPick = null;
    this.onExit = null;
    this.refreshQueued = false;
  }

  ensureMap() {
    if (this.map) return true;
    if (!window.L) return false;
    const L = window.L;
    this.map = L.map(this.container, {
      minZoom: 2,
      maxZoom: MAP_MAX_ZOOM,
      worldCopyJump: true,
      zoomControl: true,
      preferCanvas: true,
      attributionControl: true,
    });
    L.tileLayer(MAP_TILE_URL, {
      minZoom: 2,
      maxZoom: MAP_MAX_ZOOM,
      maxNativeZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap contributors</a>',
    }).addTo(this.map);
    this.canvasRenderer = L.canvas({ padding: 0.35 });
    this.dotLayer = L.layerGroup().addTo(this.map);
    this.markerLayer = L.layerGroup().addTo(this.map);
    this.trajectoryLayer = L.layerGroup().addTo(this.map);
    this.map.on('moveend', () => this.queueRefresh());
    this.map.on('zoomend', () => {
      if (this.active && this.map.getZoom() <= 2) {
        const c = this.map.getCenter();
        this.exit(c.lat, c.lng);
        return;
      }
      this.queueRefresh();
      if (this.active) {
        $('viewModeName').textContent = 'SURFACE MAP';
        $('viewModeHint').textContent = `OpenStreetMap · zoom ${this.map.getZoom()} · building-level detail where mapped`;
      }
    });
    return true;
  }

  setObjects(objects) { this.objects = objects || []; this.queueRefresh(); }
  setSelected(obj) { this.selected = obj || null; this.queueRefresh(); }
  setOrbitVisible(v) { this.orbitVisible = !!v; this.queueRefresh(); }
  setOrbitPath(path) { this.orbitPath = Array.isArray(path) ? path : null; this.updateTrajectory(); }

  enter(lat, lon, zoom = 5) {
    this.container.hidden = false;
    if (!this.ensureMap()) {
      this.container.hidden = true;
      showToast('Surface map library chưa tải được · globe vẫn hoạt động.');
      return false;
    }
    this.active = true;
    $('app').classList.add('surface-mode');
    state.renderer.canvas.style.visibility = 'hidden';
    $('surfaceExitBtn').hidden = false;
    $('surfaceLegend').hidden = false;
    $('viewModeName').textContent = 'SURFACE MAP';
    $('viewModeHint').textContent = 'OpenStreetMap · tiếp tục zoom để xem đường và toà nhà';
    requestAnimationFrame(() => {
      this.map.invalidateSize(false);
      this.map.setView([clamp(lat, -85, 85), wrapLon(lon)], clamp(zoom, 2, MAP_MAX_ZOOM), { animate: false });
      this.updateObjects();
      this.updateTrajectory();
    });
    return true;
  }

  exit(lat = null, lon = null) {
    if (!this.active) return;
    const c = this.map?.getCenter();
    const targetLat = Number.isFinite(lat) ? lat : c?.lat;
    const targetLon = Number.isFinite(lon) ? lon : c?.lng;
    this.active = false;
    this.container.hidden = true;
    $('app').classList.remove('surface-mode');
    state.renderer.canvas.style.visibility = 'visible';
    $('surfaceExitBtn').hidden = true;
    $('surfaceLegend').hidden = true;
    if (Number.isFinite(targetLat) && Number.isFinite(targetLon)) state.renderer.centerOn(targetLat, targetLon, 3.85);
    $('viewModeName').textContent = 'SURFACE VIEW';
    $('viewModeHint').textContent = 'Globe · zoom thêm để mở bản đồ bề mặt';
    this.onExit?.();
  }

  centerOn(lat, lon, zoom = null) {
    if (!this.active || !this.map || !Number.isFinite(lat) || !Number.isFinite(lon)) return;
    const z = Number.isFinite(zoom) ? clamp(zoom, 2, MAP_MAX_ZOOM) : this.map.getZoom();
    this.map.setView([lat, lon], z, { animate: true });
  }

  queueRefresh() {
    if (!this.active || this.refreshQueued) return;
    this.refreshQueued = true;
    requestAnimationFrame(() => { this.refreshQueued = false; this.updateObjects(); });
  }

  updateTrajectory() {
    if (!this.active || !this.map || !this.trajectoryLayer) return;
    this.trajectoryLayer.clearLayers();
    if (!Array.isArray(this.orbitPath) || this.orbitPath.length < 2) return;
    const L = window.L;
    let segment = [];
    let prevLon = null;
    const flush = () => {
      if (segment.length > 1) L.polyline(segment, { color: '#75d5ff', weight: 1.5, opacity: 0.7, interactive: false }).addTo(this.trajectoryLayer);
      segment = [];
    };
    for (const p of this.orbitPath) {
      if (!Number.isFinite(p?.lat) || !Number.isFinite(p?.lon)) continue;
      if (prevLon != null && Math.abs(p.lon - prevLon) > 180) flush();
      segment.push([p.lat, p.lon]);
      prevLon = p.lon;
    }
    flush();
  }

  markerHtml(obj, size) {
    const real = obj?.profile?.markerImage || (obj?.category === 'station' ? obj?.profile?.heroImage : '');
    const src = real || ICONS[obj.category] || ICONS.satellite;
    const cls = `live-map-marker ${real ? 'real-photo' : ''} ${obj === this.selected ? 'selected' : ''}`;
    const html = `<span class="lw-marker-wrap"><img src="${String(src).replace(/"/g, '&quot;')}" alt=""></span>`;
    return window.L.divIcon({ className: cls, html, iconSize: [size, size], iconAnchor: [size / 2, size / 2] });
  }

  updateObjects() {
    if (!this.active || !this.map || !this.markerLayer || !this.dotLayer) return;
    this.markerLayer.clearLayers();
    this.dotLayer.clearLayers();
    const L = window.L;
    const zoom = this.map.getZoom();
    const bounds = this.map.getBounds().pad(0.18);
    const selected = this.selected;
    const candidates = [];
    for (const obj of this.objects) {
      if (!this.orbitVisible && obj.kind === 'orbit') continue;
      if (!obj.hasPosition || !Number.isFinite(obj.lat) || !Number.isFinite(obj.lon)) continue;
      if (!bounds.contains([obj.lat, obj.lon])) continue;
      candidates.push(obj);
    }
    candidates.sort((a, b) => {
      if (a === selected) return -1; if (b === selected) return 1;
      const rank = { aircraft: 0, ship: 1, train: 2, rocket: 3, station: 4, spacecraft: 5, satellite: 6, debris: 7 };
      return (rank[a.category] ?? 9) - (rank[b.category] ?? 9);
    });
    const cap = zoom >= 9 ? 600 : zoom >= 6 ? 450 : 260;
    for (const obj of candidates.slice(0, cap)) {
      const important = obj === selected || obj.kind !== 'orbit' || obj.category === 'station' || obj.category === 'spacecraft';
      if (important || zoom >= 8) {
        const mapSize = { station: 30, spacecraft: 23, aircraft: 24, ship: 23, train: 22, rocket: 25, lunar_base: 26, satellite: 16 };
        let size = mapSize[obj.category] || 18;
        if (obj === selected) size = Math.max(34, size + 8);
        const marker = L.marker([obj.lat, obj.lon], { icon: this.markerHtml(obj, size), keyboard: false, riseOnHover: true });
        marker.on('click', () => this.onPick?.(obj));
        marker.addTo(this.markerLayer);
      } else {
        const marker = L.circleMarker([obj.lat, obj.lon], {
          renderer: this.canvasRenderer,
          radius: obj.category === 'station' ? 5 : obj.category === 'spacecraft' ? 4 : 2,
          color: obj.category === 'debris' ? '#8e744b' : '#06111c',
          weight: 1,
          fillColor: obj.category === 'debris' ? '#e5b96d' : '#9edfff',
          fillOpacity: obj.category === 'debris' ? 0.45 : 0.9,
        });
        marker.on('click', () => this.onPick?.(obj));
        marker.addTo(this.dotLayer);
      }
    }
  }
}

async function loadProfiles() {
  try {
    const response = await fetch(PROFILE_ENDPOINT, { cache: 'no-cache' });
    if (!response.ok) throw new Error(`profile registry HTTP ${response.status}`);
    const data = await response.json();
    state.profiles = data && typeof data === 'object' ? data : {};
  } catch (error) {
    console.warn('Object profile registry unavailable.', error);
    state.profiles = {};
  }
}

async function fetchSatcatMetadata(norad) {
  const id = String(norad || '').trim();
  if (!id) return null;
  if (state.satcatCache.has(id)) return state.satcatCache.get(id);
  const response = await fetch(SATCAT_ENDPOINT(id), { headers: { Accept: 'application/json' } });
  if (!response.ok) throw new Error(`SATCAT: HTTP ${response.status}`);
  const rows = await response.json();
  const metadata = Array.isArray(rows) ? (rows[0] || null) : null;
  state.satcatCache.set(id, metadata);
  return metadata;
}


function officialImageQuery(obj) {
  const profile = obj?.profile || state.profiles[obj?.norad] || {};
  if (profile.nasaQuery) return profile.nasaQuery;
  const aliases = {
    '20580': 'Hubble Space Telescope',
    '25544': 'International Space Station',
  };
  return aliases[obj?.norad] || '';
}

async function fetchOfficialNasaImage(obj) {
  if (!obj) return null;
  const key = String(obj.norad || obj.name || '').trim();
  if (!key) return null;
  if (state.nasaImageCache.has(key)) return state.nasaImageCache.get(key);
  const query = officialImageQuery(obj);
  if (!query) { state.nasaImageCache.set(key, null); return null; }
  const url = new URL(NASA_IMAGE_SEARCH);
  url.searchParams.set('q', query);
  url.searchParams.set('media_type', 'image');
  url.searchParams.set('page_size', '6');
  const response = await fetch(url, { headers: { Accept: 'application/json' } });
  if (!response.ok) throw new Error(`NASA Images HTTP ${response.status}`);
  const payload = await response.json();
  const items = payload?.collection?.items || [];
  let result = null;
  for (const item of items) {
    const data = item?.data?.[0] || {};
    const preview = item?.links?.find((x) => x?.render === 'image')?.href || item?.links?.[0]?.href;
    if (!preview || !data.nasa_id) continue;
    result = {
      heroImage: preview,
      imageCredit: data.photographer ? `NASA · ${data.photographer}` : 'NASA Images',
      imageSourceUrl: `https://images.nasa.gov/details/${encodeURIComponent(data.nasa_id)}`,
      imageObserved: data.date_created ? new Date(data.date_created).toISOString().slice(0, 10) : '',
      imageTitle: data.title || query,
      imageNasaId: data.nasa_id,
    };
    break;
  }
  state.nasaImageCache.set(key, result);
  return result;
}

async function enrichOfficialImage(obj) {
  if (!obj || obj.imageLookupDone) return;
  const base = obj.profile || state.profiles[obj.norad] || {};
  if (base.heroImage) { obj.imageLookupDone = true; return; }
  const query = officialImageQuery(obj);
  if (!query) { obj.imageLookupDone = true; return; }
  obj.imageLookupDone = true;
  if (state.selected === obj) {
    $('entityMediaMeta').hidden = false;
    $('entityMediaMeta').textContent = 'Đang tìm ảnh public chính thức…';
  }
  try {
    const image = await fetchOfficialNasaImage(obj);
    if (!image) {
      if (state.selected === obj) { $('entityMediaMeta').hidden = false; $('entityMediaMeta').textContent = 'Chưa tìm thấy ảnh public chính thức trong NASA Images.'; }
      return;
    }
    obj.profile = { ...base, ...image, dynamicOfficialImage: true };
    if (state.selected === obj) updateSelectedPanel(obj);
  } catch (error) {
    console.warn('Official image lookup failed', error);
    if (state.selected === obj) { $('entityMediaMeta').hidden = false; $('entityMediaMeta').textContent = 'Ảnh public chính thức tạm thời không tải được.'; }
  }
}

function updateHero(obj) {
  const profile = obj.profile || {};
  const wrap = $('entityHero');
  const photo = $('entityHeroImg');
  const fallback = $('entityHeroFallback');
  const credit = $('entityHeroCredit');
  const source = $('entityHeroSource');
  const mediaMeta = $('entityMediaMeta');
  if (profile.heroImage) {
    wrap.classList.add('has-photo');
    photo.hidden = false; fallback.hidden = true;
    if (photo.dataset.src !== profile.heroImage) { photo.dataset.src = profile.heroImage; photo.src = profile.heroImage; }
    credit.textContent = profile.imageCredit ? `Photo: ${profile.imageCredit}` : 'Official / mission image';
    if (profile.imageSourceUrl) { source.href = profile.imageSourceUrl; source.hidden = false; } else source.hidden = true;
    const bits = [];
    if (profile.dynamicOfficialImage) bits.push('Official public image · NASA Images');
    else bits.push('Mission / official image');
    if (profile.imageObserved) bits.push(`image date ${profile.imageObserved}`);
    if (profile.imageTitle) bits.push(profile.imageTitle);
    mediaMeta.textContent = bits.join(' · ');
    mediaMeta.hidden = false;
  } else {
    wrap.classList.remove('has-photo');
    photo.hidden = true; photo.removeAttribute('src'); photo.dataset.src = '';
    fallback.hidden = false; fallback.src = ICONS[obj.category] || ICONS.satellite;
    credit.textContent = 'LIVEWORLD type icon'; source.hidden = true;
    if (!obj.imageLookupDone) { mediaMeta.textContent = ''; mediaMeta.hidden = true; }
  }
}

function updateSelectedPanel(obj) {
  if (!obj) return;
  const meta = obj.metadata || {};
  const profile = obj.profile || state.profiles[obj.norad] || {};
  obj.profile = profile;
  updateHero(obj);
  $('entityType').textContent = TYPE_LABEL[obj.category] || 'ORBITAL OBJECT';
  $('entityName').textContent = profile.shortName || obj.name;
  const displayName = profile.displayName && profile.displayName !== obj.name ? profile.displayName : '';
  $('entityDisplayName').textContent = displayName;
  $('entityDisplayName').hidden = !displayName;
  if (obj.kind === 'orbit') {
    $('entityId').textContent = `NORAD ${obj.norad}${obj.objectId ? ` · ${obj.objectId}` : ''}${obj.constellation !== 'Other' ? ` · ${obj.constellation}` : ''}`;
  } else {
    $('entityId').textContent = `${TYPE_LABEL[obj.category] || 'LIVE OBJECT'}${obj.objectId ? ` · ${obj.objectId}` : ''}`;
  }
  $('entityStatus').textContent = profile.status || 'ACTIVE';
  $('entityStatus').classList.toggle('inactive', String(profile.status || 'ACTIVE').toUpperCase() !== 'ACTIVE');

  const launchDate = meta.LAUNCH_DATE || profile.launchDate || '';
  const age = ageBetween(launchDate);
  $('mAgeLabel').textContent = profile.ageLabel || 'AGE SINCE LAUNCH';
  $('mAge').textContent = formatAge(age);
  $('mAgeSince').textContent = launchDate ? `${profile.launchLabel || 'Launch'} · ${formatDate(launchDate)}${age ? ` · ${age.totalDays.toLocaleString()} days` : ''}` : 'Launch date unavailable';
  const crew = profile.continuousCrewedSince ? ageBetween(profile.continuousCrewedSince) : null;
  $('crewAgeBlock').hidden = !crew;
  if (crew) { $('mCrewAgeLabel').textContent = profile.continuousCrewedLabel || 'CONTINUOUSLY CREWED'; $('mCrewAge').textContent = formatAge(crew); $('mCrewSince').textContent = `Since ${formatDate(profile.continuousCrewedSince)}`; }

  $('mAltitude').textContent = Number.isFinite(obj.altitudeKm) ? `${obj.altitudeKm.toFixed(obj.altitudeKm < 1000 ? 1 : 0)} km` : '—';
  $('mVelocity').textContent = Number.isFinite(obj.speedKmS) ? `${obj.speedKmS.toFixed(2)} km/s` : '—';
  $('mLat').textContent = Number.isFinite(obj.lat) ? `${Math.abs(obj.lat).toFixed(3)}° ${obj.lat >= 0 ? 'N' : 'S'}` : '—';
  $('mLon').textContent = Number.isFinite(obj.lon) ? `${Math.abs(obj.lon).toFixed(3)}° ${obj.lon >= 0 ? 'E' : 'W'}` : '—';
  $('mTime').textContent = obj.updatedAt ? `${obj.updatedAt.toISOString().slice(11, 19)} UTC` : '—';
  $('mSource').textContent = obj.sourceLabel || (obj.kind === 'orbit' ? 'CelesTrak OMM · SGP4' : 'LIVE feed');

  $('mLaunchDate').textContent = formatDate(launchDate);
  $('mOperator').textContent = profile.operator || ownerLabel(meta.OWNER);
  $('mLaunchSite').textContent = profile.launchSiteDisplay || launchSiteLabel(meta.LAUNCH_SITE);
  $('mOrbitClass').textContent = obj.kind === 'orbit' ? orbitSummary(meta) : '—';
  $('mInclination').textContent = obj.kind === 'orbit' && Number.isFinite(Number(meta.INCLINATION ?? obj.row?.INCLINATION)) ? `${Number(meta.INCLINATION ?? obj.row?.INCLINATION).toFixed(2)}°` : '—';
  $('mApogee').textContent = Number.isFinite(Number(meta.APOGEE)) ? `${Number(meta.APOGEE).toLocaleString()} km` : '—';
  $('mPerigee').textContent = Number.isFinite(Number(meta.PERIGEE)) ? `${Number(meta.PERIGEE).toLocaleString()} km` : '—';
  $('mPeriod').textContent = Number.isFinite(Number(meta.PERIOD)) ? `${Number(meta.PERIOD).toFixed(1)} min` : '—';

  const ms = $('metadataState');
  if (obj.kind !== 'orbit') { ms.textContent = `Live metadata · ${obj.sourceLabel || TYPE_LABEL[obj.category] || 'external feed'}`; ms.dataset.state = 'ready'; }
  else if (obj.metadataStatus === 'loading') { ms.textContent = 'Loading mission metadata from CelesTrak SATCAT…'; ms.dataset.state = 'loading'; }
  else if (obj.metadataStatus === 'error') { ms.textContent = 'Mission metadata unavailable · live position still active'; ms.dataset.state = 'error'; }
  else if (obj.metadataStatus === 'empty') { ms.textContent = 'No SATCAT mission metadata returned for this object'; ms.dataset.state = 'empty'; }
  else { ms.textContent = obj.metadata ? 'Mission metadata · CelesTrak SATCAT' : 'Mission metadata loads when selected'; ms.dataset.state = obj.metadata ? 'ready' : 'idle'; }
  $('missionNote').textContent = profile.missionNote || '';
  $('missionNote').hidden = !$('missionNote').textContent;
  $('followBtn').textContent = state.following ? 'Stop follow' : 'Follow';
  $('trackBtn').textContent = state.orbitPath ? 'Hide orbit' : 'Show orbit';
}

async function enrichSelectedObject(obj) {
  if (!obj) return;
  obj.profile = obj.profile || state.profiles[obj.norad] || null;
  updateSelectedPanel(obj);
  if (obj.kind !== 'orbit') return;
  if (obj.metadataStatus === 'ready' || obj.metadataStatus === 'loading') return;
  obj.metadataStatus = 'loading'; updateSelectedPanel(obj);
  try {
    obj.metadata = await fetchSatcatMetadata(obj.norad);
    obj.metadataStatus = obj.metadata ? 'ready' : 'empty';
  } catch (error) {
    console.warn(`SATCAT metadata failed for ${obj.norad}`, error);
    obj.metadataStatus = 'error';
  }
  if (state.selected === obj) updateSelectedPanel(obj);
}

function selectObject(obj, focus = false) {
  if (!obj) return;
  if (state.selected && state.selected !== obj) {
    state.following = false;
    state.orbitPath = null;
    state.renderer.setOrbitPath(null);
    state.surfaceMap?.setOrbitPath(null);
  }
  state.selected = obj;
  state.renderer.setSelected(obj);
  panel.classList.add('open');
  if (focus && obj.hasPosition) {
    if (state.surfaceMap?.active) state.surfaceMap.centerOn(obj.lat, obj.lon, Math.max(6, state.surfaceMap.map?.getZoom() || 6));
    else state.renderer.centerOn(obj.lat, obj.lon, Math.max(1.15, state.renderer.zoom));
  }
  updateSelectedPanel(obj);
  enrichSelectedObject(obj);
  enrichOfficialImage(obj);
  state.surfaceMap?.setSelected(obj);
}

function propagateSelected(obj, date) {
  try {
    if (!obj.satrec) obj.satrec = satellite.json2satrec(obj.row);
    const pv = satellite.propagate(obj.satrec, date);
    if (!pv?.position || !pv?.velocity) return null;
    const gmst = satellite.gstime(date);
    const geo = satellite.eciToGeodetic(pv.position, gmst);
    const lat = satellite.degreesLat(geo.latitude), lon = satellite.degreesLong(geo.longitude), altitudeKm = geo.height;
    const speedKmS = Math.hypot(pv.velocity.x, pv.velocity.y, pv.velocity.z);
    if (![lat, lon, altitudeKm, speedKmS].every(Number.isFinite)) return null;
    return { lat, lon, altitudeKm, speedKmS };
  } catch { return null; }
}

function toggleFollow() {
  if (!state.selected?.hasPosition) return;
  state.following = !state.following;
  if (state.following) {
    if (state.surfaceMap?.active) state.surfaceMap.centerOn(state.selected.lat, state.selected.lon, Math.max(5, state.surfaceMap.map?.getZoom() || 5));
    else state.renderer.centerOn(state.selected.lat, state.selected.lon, Math.max(1.1, state.renderer.zoom));
  }
  updateSelectedPanel(state.selected);
}

function toggleOrbitLine() {
  if (!state.selected) return;
  if (state.selected.kind !== 'orbit') { showToast('Trajectory dự đoán chỉ bật khi feed cung cấp quỹ đạo / route.'); return; }
  if (state.orbitPath) {
    state.orbitPath = null;
    state.renderer.setOrbitPath(null);
    state.surfaceMap?.setOrbitPath(null);
    updateSelectedPanel(state.selected);
    return;
  }
  const positions = [];
  const center = Date.now();
  for (let min = -100; min <= 100; min += 2) {
    const p = propagateSelected(state.selected, new Date(center + min * 60000));
    if (p) positions.push(p);
  }
  state.orbitPath = positions;
  state.renderer.setOrbitPath(positions);
  state.surfaceMap?.setOrbitPath(positions);
  updateSelectedPanel(state.selected);
}

function showToast(message) {
  const el = $('toast');
  el.textContent = message; el.hidden = false;
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => { el.hidden = true; }, 3000);
}


function allVisibleObjects() {
  const objects = state.orbitLayerVisible ? [...state.orbitObjects] : [];
  for (const [layer, rows] of Object.entries(state.externalLayers)) {
    if (state.externalEnabled[layer]) objects.push(...rows);
  }
  return objects;
}

function refreshRendererObjects() {
  const objects = allVisibleObjects();
  state.renderer?.setObjects(objects);
  state.surfaceMap?.setObjects(objects);
}

function normalizeExternalObject(row, layer, index) {
  const cfg = EXTERNAL_LAYER_CONFIG[layer];
  const number = (...vals) => {
    for (const v of vals) { const n = Number(v); if (Number.isFinite(n)) return n; }
    return NaN;
  };
  const lat = number(row.lat, row.latitude);
  const lon = number(row.lon, row.lng, row.longitude);
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
  let altitudeKm = number(row.altitudeKm);
  if (!Number.isFinite(altitudeKm)) {
    const meters = number(row.altitude_m, row.altitudeM, row.geo_altitude, row.baro_altitude);
    altitudeKm = Number.isFinite(meters) ? meters / 1000 : 0;
  }
  let speedKmS = number(row.speedKmS);
  if (!Number.isFinite(speedKmS)) {
    const ms = number(row.speed_mps, row.velocity, row.speedMps);
    const kmh = number(row.speed_kmh, row.speedKmh);
    const knots = number(row.speed_knots, row.speedKnots);
    if (Number.isFinite(ms)) speedKmS = ms / 1000;
    else if (Number.isFinite(kmh)) speedKmS = kmh / 3600;
    else if (Number.isFinite(knots)) speedKmS = knots * 0.000514444;
    else speedKmS = NaN;
  }
  const id = String(row.id ?? row.icao24 ?? row.mmsi ?? row.norad ?? row.callsign ?? `${layer}-${index}`);
  const name = String(row.name ?? row.callsign ?? row.flight ?? row.vesselName ?? row.shipName ?? row.trainName ?? row.mission ?? id).trim() || id;
  const launched = row.launchDate || row.startedAt || row.commissionedAt || '';
  const profile = {
    displayName: row.displayName || '',
    shortName: row.shortName || '',
    status: row.status || 'LIVE',
    operator: row.operator || row.airline || row.owner || '',
    launchDate: launched,
    heroImage: row.imageUrl || row.image || '',
    markerImage: row.markerImage || '',
    imageCredit: row.imageCredit || '',
    imageSourceUrl: row.imageSourceUrl || '',
    missionNote: row.note || row.description || '',
  };
  const tsCandidate = row.timestamp ? new Date(row.timestamp) : new Date();
  const updatedAt = Number.isNaN(tsCandidate.getTime()) ? new Date() : tsCandidate;
  return {
    kind: layer,
    index,
    category: cfg.category,
    constellation: 'Other',
    row: row || {},
    name,
    norad: '',
    objectId: id,
    epoch: '',
    lat, lon, altitudeKm, speedKmS,
    updatedAt,
    hasPosition: true,
    metadata: null,
    metadataStatus: 'ready',
    profile,
    sourceLabel: row.source || cfg.label,
  };
}

async function refreshExternalLayer(layer, quiet = false) {
  const cfg = EXTERNAL_LAYER_CONFIG[layer];
  if (!cfg) return;
  try {
    const response = await fetch(`${cfg.endpoint}?t=${Date.now()}`, { cache: 'no-store', headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const payload = await response.json();
    const raw = Array.isArray(payload) ? payload : (Array.isArray(payload?.data) ? payload.data : Array.isArray(payload?.objects) ? payload.objects : []);
    const objects = raw.map((row, i) => normalizeExternalObject(row, layer, i)).filter(Boolean);
    state.externalLayers[layer] = objects;
    refreshRendererObjects();
    if (!quiet) showToast(`${cfg.label} · ${objects.length.toLocaleString()} live objects`);
  } catch (error) {
    state.externalLayers[layer] = [];
    refreshRendererObjects();
    if (!quiet) showToast(`${cfg.label}: chưa có live feed tại ${cfg.endpoint}`);
    console.warn(`${cfg.label} feed unavailable`, error);
  }
}

function toggleExternalLayer(layer, button) {
  const cfg = EXTERNAL_LAYER_CONFIG[layer];
  if (!cfg) return;
  state.externalEnabled[layer] = !state.externalEnabled[layer];
  button.classList.toggle('active', state.externalEnabled[layer]);
  if (!state.externalEnabled[layer]) {
    clearInterval(state.externalTimers[layer]);
    delete state.externalTimers[layer];
    refreshRendererObjects();
    return;
  }
  refreshExternalLayer(layer, false);
  clearInterval(state.externalTimers[layer]);
  state.externalTimers[layer] = setInterval(() => refreshExternalLayer(layer, true), cfg.refreshMs);
}

function installUI() {
  $('panelClose').addEventListener('click', () => panel.classList.remove('open'));
  $('followBtn').addEventListener('click', toggleFollow);
  $('trackBtn').addEventListener('click', toggleOrbitLine);
  $('entityHeroImg').addEventListener('error', () => {
    const obj = state.selected; const photo = $('entityHeroImg'); const fallback = $('entityHeroFallback');
    photo.hidden = true; fallback.hidden = false; fallback.src = ICONS[obj?.category] || ICONS.satellite;
    $('entityHero').classList.remove('has-photo'); $('entityHeroCredit').textContent = 'Mission image unavailable';
  });

  $('earthModeBtn').classList.add('active');
  $('earthModeBtn').addEventListener('click', () => { if (state.surfaceMap?.active) state.surfaceMap.exit(); });
  $('surfaceExitBtn').addEventListener('click', () => state.surfaceMap?.exit());
  $('solarModeBtn').addEventListener('click', () => showToast('SPACE đang được build lại sau khi lõi tracking Earth ổn định.'));
  $('bodyPanelClose').addEventListener('click', () => $('bodyPanel').classList.remove('open'));
  $('openEarthBtn').addEventListener('click', () => {});

  $('searchForm').addEventListener('submit', (event) => {
    event.preventDefault();
    const raw = $('searchInput').value.trim();
    const q = raw.toLowerCase().replace(/^norad\s*/, '');
    if (!q) return;
    const searchObjects = allVisibleObjects();
    const exact = searchObjects.find((x) => (x.norad && x.norad === q) || String(x.objectId || '').toLowerCase() === q || x.name.toLowerCase() === q);
    const partial = searchObjects.find((x) => x.name.toLowerCase().includes(q) || String(x.norad || '').includes(q) || String(x.objectId || '').toLowerCase().includes(q));
    const match = exact || partial;
    if (!match) return showToast(`Không tìm thấy “${raw}” trong ACTIVE catalog.`);
    selectObject(match, true);
  });

  document.querySelectorAll('.layer').forEach((button) => {
    button.addEventListener('click', () => {
      const layer = button.dataset.layer;
      if (layer === 'orbit') {
        state.orbitLayerVisible = !state.orbitLayerVisible;
        button.classList.toggle('active', state.orbitLayerVisible);
        state.renderer.setOrbitVisible(state.orbitLayerVisible);
        state.surfaceMap?.setOrbitVisible(state.orbitLayerVisible);
        refreshRendererObjects();
        return;
      }
      toggleExternalLayer(layer, button);
    });
  });

  const clock = () => { $('clock').textContent = `${new Date().toISOString().slice(11, 19)} UTC`; };
  clock(); setInterval(clock, 1000);
}

function setupRenderer() {
  const renderer = new EarthCanvasRenderer($('cesiumContainer'));
  state.renderer = renderer;
  const surface = new SurfaceMapController($('surfaceMap'));
  state.surfaceMap = surface;
  surface.onPick = (obj) => selectObject(obj, false);
  surface.onExit = () => renderer.draw();
  renderer.onRequestSurface = ({ lat, lon }) => surface.enter(lat, lon, 5);
  renderer.onPick = (obj) => selectObject(obj, false);
  renderer.onHover = (obj, event) => {
    if (!obj) { tooltip.hidden = true; return; }
    tooltip.hidden = false;
    const alt = Number.isFinite(obj.altitudeKm) ? ` · ${obj.altitudeKm.toFixed(0)} km` : '';
    tooltip.textContent = `${TYPE_LABEL[obj.category] || 'OBJECT'} · ${obj.name} · NORAD ${obj.norad}${alt}`;
    tooltip.style.left = `${event.clientX}px`; tooltip.style.top = `${event.clientY}px`;
  };
  renderer.onViewChange = () => {
    if (surface.active) return;
    const name = $('viewModeName'), hint = $('viewModeHint');
    if (renderer.zoom > 3.65) { name.textContent = 'SURFACE VIEW'; hint.textContent = 'Zoom thêm để chuyển sang bản đồ đường / toà nhà'; }
    else if (renderer.zoom > 2.55) { name.textContent = 'SURFACE VIEW'; hint.textContent = 'Orbital clutter reduced automatically'; }
    else if (renderer.zoom > 1.62) { name.textContent = 'ICON VIEW'; hint.textContent = 'Satellite icons enabled · stations / spacecraft remain prominent'; }
    else { name.textContent = 'ORBIT VIEW'; hint.textContent = 'Worldwide active orbital catalog'; }
  };
}

async function openOrbitCacheDb() {
  if (!('indexedDB' in window)) return null;
  return await new Promise((resolve, reject) => {
    const req = indexedDB.open(ORBIT_CACHE_DB, 1);
    req.onupgradeneeded = () => { const db = req.result; if (!db.objectStoreNames.contains(ORBIT_CACHE_STORE)) db.createObjectStore(ORBIT_CACHE_STORE); };
    req.onsuccess = () => resolve(req.result); req.onerror = () => reject(req.error);
  });
}

async function readOrbitCache() {
  try {
    const db = await openOrbitCacheDb(); if (!db) return null;
    const value = await new Promise((resolve, reject) => {
      const tx = db.transaction(ORBIT_CACHE_STORE, 'readonly'); const req = tx.objectStore(ORBIT_CACHE_STORE).get(ORBIT_CACHE_KEY);
      req.onsuccess = () => resolve(req.result || null); req.onerror = () => reject(req.error);
    });
    db.close();
    if (!value || !Array.isArray(value.rows) || value.rows.length < 10000) return null;
    return value;
  } catch (error) { console.warn('Orbit cache unavailable.', error); return null; }
}

async function writeOrbitCache(record) {
  try {
    const db = await openOrbitCacheDb(); if (!db) return false;
    await new Promise((resolve, reject) => {
      const tx = db.transaction(ORBIT_CACHE_STORE, 'readwrite'); tx.objectStore(ORBIT_CACHE_STORE).put(record, ORBIT_CACHE_KEY);
      tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); tx.onabort = () => reject(tx.error || new Error('IndexedDB write aborted'));
    }); db.close(); return true;
  } catch (error) { console.warn('Unable to persist orbit catalog.', error); return false; }
}

async function fetchOrbitSnapshotMeta() {
  const response = await fetch(`${ORBIT_SNAPSHOT_META}?t=${Date.now()}`, { cache: 'no-store', headers: { Accept: 'application/json' } });
  if (!response.ok) throw new Error(`orbit snapshot meta HTTP ${response.status}`);
  const meta = await response.json();
  if (!meta || !meta.version || Number(meta.count || 0) < 10000) throw new Error('invalid orbit snapshot meta');
  return meta;
}

async function fetchOrbitSnapshot(meta = null) {
  statusText.textContent = 'Loading LIVEWORLD orbital snapshot…';
  const response = await fetch(ORBIT_SNAPSHOT_DATA, { cache: 'no-cache', headers: { Accept: 'application/json' } });
  if (!response.ok) throw new Error(`orbit snapshot HTTP ${response.status}`);
  const rows = await response.json();
  if (!Array.isArray(rows) || rows.length < 10000) throw new Error(`orbit snapshot invalid (${Array.isArray(rows) ? rows.length : 'not-array'} rows)`);
  return { rows, version: meta?.version || `network-${Date.now()}`, generatedAt: meta?.generatedAt || new Date().toISOString(), source: meta?.source || 'LIVEWORLD snapshot' };
}

async function fetchActiveCatalog() {
  statusText.textContent = 'Downloading CelesTrak ACTIVE catalog fallback…';
  const response = await fetch(ORBIT_ENDPOINT, { cache: 'no-cache', headers: { Accept: 'application/json' } });
  if (!response.ok) throw new Error(`CelesTrak ACTIVE: HTTP ${response.status}`);
  const rows = await response.json();
  if (!Array.isArray(rows) || rows.length < 10000) throw new Error('CelesTrak ACTIVE returned invalid JSON.');
  return rows;
}

function uniqueRows(rows) {
  const seen = new Set(), clean = [];
  for (const row of rows) { const norad = String(row.NORAD_CAT_ID || '').trim(); if (!norad || seen.has(norad)) continue; seen.add(norad); clean.push(row); }
  return clean;
}

async function buildCatalog(rows) {
  statusText.textContent = `Preparing ${rows.length.toLocaleString()} orbital objects…`;
  const counts = { satellite: 0, station: 0, spacecraft: 0, debris: 0, constellations: {} };
  state.orbitObjects = rows.map((row, i) => {
    const category = classifyOrbitObject(row), name = row.OBJECT_NAME || `NORAD ${row.NORAD_CAT_ID || ''}`, constellation = constellationOf(name);
    counts[category] = (counts[category] || 0) + 1; counts.constellations[constellation] = (counts.constellations[constellation] || 0) + 1;
    return {
      kind: 'orbit', index: i, category, constellation, row, name,
      norad: String(row.NORAD_CAT_ID || ''), objectId: row.OBJECT_ID || '', epoch: row.EPOCH || '',
      lat: NaN, lon: NaN, altitudeKm: NaN, speedKmS: NaN, updatedAt: null, hasPosition: false,
      satrec: null, metadata: null, metadataStatus: 'idle', profile: state.profiles[String(row.NORAD_CAT_ID || '')] || null,
    };
  });
  state.catalogCounts = counts;
  refreshRendererObjects();
}

function startOrbitWorker(rows) {
  if (state.worker) state.worker.terminate();
  const worker = new Worker('/workers/orbit-worker.js?v=7.3-rich', { type: 'module' });
  state.worker = worker;
  worker.addEventListener('message', (event) => {
    const message = event.data || {};
    if (message.type === 'ready') { statusText.textContent = `Orbit engine ready · propagating ${message.parsed.toLocaleString()} objects…`; return; }
    if (message.type === 'positions' && message.buffer) queuePositionFrame(new Float32Array(message.buffer), new Date(message.timestamp), message.valid || 0);
  });
  worker.addEventListener('error', (event) => { console.error('Orbit worker failed', event); statusText.textContent = 'Catalog loaded · orbit propagation worker failed'; });
  worker.postMessage({ type: 'init', rows });
}

function queuePositionFrame(positions, timestamp, valid) {
  state.pendingFrame = { positions, timestamp, valid };
  applyPendingFrame();
}

function applyPendingFrame() {
  if (!state.pendingFrame || applyPendingFrame.running) return;
  applyPendingFrame.running = true;
  const frame = state.pendingFrame; state.pendingFrame = null; let index = 0;
  const step = () => {
    const end = Math.min(index + POSITION_APPLY_BATCH, state.orbitObjects.length);
    for (; index < end; index++) {
      const obj = state.orbitObjects[index], offset = index * 4;
      const lon = frame.positions[offset], lat = frame.positions[offset + 1], altitudeKm = frame.positions[offset + 2], speedKmS = frame.positions[offset + 3];
      if (![lon, lat, altitudeKm, speedKmS].every(Number.isFinite)) { obj.hasPosition = false; continue; }
      obj.lon = lon; obj.lat = lat; obj.altitudeKm = altitudeKm; obj.speedKmS = speedKmS; obj.updatedAt = frame.timestamp; obj.hasPosition = true;
    }
    if (index < state.orbitObjects.length) { requestAnimationFrame(step); return; }
    applyPendingFrame.running = false;
    if (!state.firstPositionFrame) { state.firstPositionFrame = true; updateLiveStatus(frame.valid); }
    state.surfaceMap?.queueRefresh();
    if (state.selected?.hasPosition) {
      updateSelectedPanel(state.selected);
      if (state.following) {
        if (state.surfaceMap?.active) state.surfaceMap.centerOn(state.selected.lat, state.selected.lon);
        else state.renderer.centerOn(state.selected.lat, state.selected.lon);
      }
    }
    if (state.pendingFrame) applyPendingFrame();
  };
  requestAnimationFrame(step);
}

function updateLiveStatus(validCount) {
  const top = Object.entries(state.catalogCounts.constellations || {}).filter(([n]) => n !== 'Other').sort((a, b) => b[1] - a[1]).slice(0, 2).map(([n, c]) => `${n} ${c.toLocaleString()}`).join(' · ');
  const src = state.orbitCatalogSource === 'IndexedDB' ? 'LOCAL CACHE' : 'LIVEWORLD SNAPSHOT';
  state.lastOrbitStatus = `LIVE · ${validCount.toLocaleString()} / ${state.orbitObjects.length.toLocaleString()} active orbital objects · ${src} · SGP4${top ? ` · ${top}` : ''}`;
  statusText.textContent = state.lastOrbitStatus;
}

async function replaceOrbitCatalog(rawRows, info = {}) {
  const rows = uniqueRows(rawRows);
  if (rows.length < 10000) throw new Error(`Refusing orbital catalog with only ${rows.length} unique objects.`);
  if (state.worker) { state.worker.terminate(); state.worker = null; }
  state.firstPositionFrame = false; state.pendingFrame = null; state.selected = null; state.following = false; state.orbitPath = null;
  state.renderer.setSelected(null); state.renderer.setOrbitPath(null); state.surfaceMap?.setSelected(null); state.surfaceMap?.setOrbitPath(null); panel.classList.remove('open');
  state.orbitCatalogVersion = info.version || ''; state.orbitCatalogGeneratedAt = info.generatedAt || null; state.orbitCatalogSource = info.source || 'network';
  await buildCatalog(rows);
  statusText.textContent = `Catalog ready · ${rows.length.toLocaleString()} active objects · starting SGP4 worker…`;
  startOrbitWorker(rows);
  return rows;
}

async function getFreshOrbitSnapshot() {
  try { const meta = await fetchOrbitSnapshotMeta(); return await fetchOrbitSnapshot(meta); }
  catch (snapshotError) {
    console.warn('LIVEWORLD server snapshot unavailable; using CelesTrak proxy fallback.', snapshotError);
    const rows = await fetchActiveCatalog();
    return { rows, version: `fallback-${Date.now()}`, generatedAt: new Date().toISOString(), source: 'CelesTrak ACTIVE fallback' };
  }
}

async function refreshOrbitCatalogInBackground(currentVersion) {
  try {
    const meta = await fetchOrbitSnapshotMeta(); if (meta.version === currentVersion) return;
    const fresh = await fetchOrbitSnapshot(meta), rows = uniqueRows(fresh.rows);
    if (rows.length < 10000) throw new Error('fresh snapshot failed validation');
    await writeOrbitCache({ ...fresh, rows, cachedAt: new Date().toISOString() });
    showToast(`Orbital catalog updated · ${rows.length.toLocaleString()} objects`);
    await replaceOrbitCatalog(rows, fresh);
  } catch (error) { console.warn('Background orbit refresh skipped.', error); }
}

async function loadSpaceCatalog() {
  const cached = await readOrbitCache();
  if (cached) {
    const rows = uniqueRows(cached.rows);
    const ageMin = cached.cachedAt ? Math.max(0, Math.round((Date.now() - Date.parse(cached.cachedAt)) / 60000)) : null;
    statusText.textContent = `LOCAL CACHE · ${rows.length.toLocaleString()} orbital objects${ageMin != null ? ` · saved ${ageMin} min ago` : ''}`;
    await replaceOrbitCatalog(rows, { ...cached, source: 'IndexedDB' });
    refreshOrbitCatalogInBackground(cached.version);
    return;
  }
  const fresh = await getFreshOrbitSnapshot(), rows = uniqueRows(fresh.rows);
  await writeOrbitCache({ ...fresh, rows, cachedAt: new Date().toISOString() });
  await replaceOrbitCatalog(rows, fresh);
}

async function boot() {
  try {
    installUI();
    setupRenderer();
    statusText.textContent = 'Earth ready · loading object profiles…';
    await loadProfiles();
    await loadSpaceCatalog();
  } catch (error) {
    console.error(error);
    $('fatal').hidden = false;
    $('fatalText').textContent = error?.message || String(error);
    statusText.textContent = 'Startup failed';
  }
}

boot();
