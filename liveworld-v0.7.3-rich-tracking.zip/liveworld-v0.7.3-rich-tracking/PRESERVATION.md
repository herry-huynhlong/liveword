# Preservation note — v0.7.3-rich

This package continues directly from the working `v0.7.2-rebuilt` recovery core. The main route remains `/`; no alternate tracking page is introduced.

The stable Canvas 2D Earth renderer, CelesTrak ACTIVE OMM catalog, satellite.js/SGP4 Web Worker, search, selection, follow, orbit path, warm cache and SATCAT metadata remain the foundation.

v0.7.3 adds richer object presentation without reintroducing Cesium/WebGL into Earth startup:

- type-specific icons and prominent station/spacecraft markers,
- a real NASA image profile for ISS,
- official-image lookup hooks for curated NASA objects,
- an in-page Leaflet/OpenStreetMap surface map for close zoom,
- optional adapters for aircraft/ship/rail/launch live JSON feeds.

No fake aircraft, ships, trains or rockets are included. Those layers display only when their live-data endpoints exist.
