# LIVEWORLD v0.7.3-rich — Rich Live Tracking

Built incrementally on top of the working `v0.7.2-rebuilt` Canvas tracking core. The root page remains `/`; there is no separate tracking page.

## What is new

- Type-aware object rendering:
  - satellite → satellite icon when zoom is close enough,
  - station → station icon / real mission photo when a profile supplies one,
  - spacecraft → spacecraft icon,
  - future external feeds: aircraft / ship / train / rocket use their matching icons.
- ISS uses a real NASA mission image in the object profile and as its prominent station marker.
- Object details still include live position, altitude, velocity, CelesTrak SATCAT mission metadata and age since launch.
- Age cards now also include total days since launch when the launch date is known.
- Official-image lookup hook for curated NASA objects via the NASA Images API. Hubble is included as an example profile; the registry can be expanded without changing renderer code.
- Close zoom now transitions from the globe to an in-page Leaflet/OpenStreetMap surface map. It can continue to building-level map detail where OpenStreetMap has building data. Zoom out to level 2 or press `GLOBE` to return to the globe.
- Selected orbit tracks can also be drawn on the surface map.
- Touch pinch on the Canvas globe is supported; pinching in far enough enters the surface map.
- Optional live-feed adapters are wired for:
  - `/live-data/aircraft.json`
  - `/live-data/ships.json`
  - `/live-data/rail.json`
  - `/live-data/launch.json`
  These endpoints are not faked. If they do not exist, the layer reports that no live feed is connected.

## Optional external feed schema

Each endpoint may return an array, `{ "data": [...] }`, or `{ "objects": [...] }`. LIVEWORLD accepts common fields such as:

```json
{
  "id": "abc123",
  "name": "Flight VN123",
  "lat": 10.78,
  "lon": 106.70,
  "altitude_m": 10200,
  "speed_mps": 230,
  "timestamp": "2026-09-22T15:00:00Z",
  "operator": "Example operator",
  "source": "ADS-B provider",
  "imageUrl": "https://..."
}
```

For aircraft, `icao24`, `callsign`, `geo_altitude`, and `velocity` are also recognized. For ships, `mmsi`, `vesselName`, `speed_knots` are recognized.

## Surface map

The initial surface map uses the standard OpenStreetMap raster tile service through Leaflet and shows required attribution. It is suitable for development / modest use. For a large public deployment, configure a dedicated tile provider or self-hosted tiles rather than placing heavy traffic on the community tile service.

## Data provenance

- Earth globe texture: bundled NASA Blue Marble from the preserved build.
- Orbital elements: CelesTrak ACTIVE OMM JSON.
- Position propagation: satellite.js / SGP4 in a Web Worker.
- Mission metadata: CelesTrak SATCAT plus local object profiles.
- Curated official imagery: NASA mission pages / NASA Images API where configured.
- Surface map: OpenStreetMap tiles and data, with attribution shown in the map.

## Deploy

```bash
chmod +x deploy.sh
./deploy.sh
```

The deploy script backs up the current `/var/www/liveword/public` before replacing it.

## Scope

This release enriches the working Earth/live-object experience without reintroducing Cesium/WebGL. `SPACE` is still not enabled in this build; the next safe step is a Canvas-based Earth–Moon / Solar System tracker using the same object/profile model and official imagery/ephemeris rules.
