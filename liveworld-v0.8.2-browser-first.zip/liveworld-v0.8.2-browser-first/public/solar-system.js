import * as THREE from 'https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js';

const DAY_MS = 86_400_000;
const AU_KM = 149_597_870.7;
const SOLAR_AU_TO_SCENE = 40;
const STATE_REFRESH_MS = 5 * 60_000;
const HORIZONS_ENDPOINT = '/api/jpl/horizons';
const WISE_SKY = '/assets/space/background/wise-allsky.jpg';
const MAX_PIXEL_RATIO = 1.75;

// LIVEWORLD v0.8 Solar Core.
// JPL Horizons remains the positional truth. Rendering scale changes by semantic frame so
// Earth–Moon, planet neighborhoods and the full Solar System can all be readable without
// falsifying the underlying state vectors.
const FRAME_PRESETS = {
  solar: {
    id: 'solar',
    label: 'SOLAR SYSTEM',
    detail: 'Heliocentric · linear AU scale',
    scale: SOLAR_AU_TO_SCENE,
    defaultDistance: 1650,
    exitDistance: Infinity,
  },
  earth: {
    id: 'earth',
    label: 'EARTH · MOON NEIGHBORHOOD',
    detail: 'Earth-centered semantic scale · JPL positions',
    scale: 13_000,
    defaultDistance: 96,
    exitDistance: 360,
  },
  moon: {
    id: 'moon',
    label: 'MOON NEIGHBORHOOD',
    detail: 'Moon-centered semantic scale · lunar orbiters',
    scale: 1_500_000,
    defaultDistance: 64,
    exitDistance: 230,
  },
  mars: {
    id: 'mars',
    label: 'MARS NEIGHBORHOOD',
    detail: 'Mars-centered semantic scale · mission orbiters',
    scale: 300_000,
    defaultDistance: 58,
    exitDistance: 240,
  },
  jupiter: {
    id: 'jupiter',
    label: 'JUPITER NEIGHBORHOOD',
    detail: 'Jupiter-centered semantic scale · mission spacecraft',
    scale: 30_000,
    defaultDistance: 62,
    exitDistance: 260,
  },
};

const BODY_COLORS = {
  sun: '#ffd980', mercury: '#b8aaa0', venus: '#e5bd78', earth: '#6aaee8', moon: '#d5d4cf',
  mars: '#d87954', jupiter: '#d7b396', saturn: '#e2c986', uranus: '#8ed6dc', neptune: '#6689de',
};

// Positions are requested from JPL Horizons in heliocentric ecliptic J2000/ICRF coordinates.
// Marker pixel sizes are UI affordances only. Position vectors remain physical and linear;
// only the render transform changes when entering a local semantic frame.
export const SPACE_OBJECTS = [
  {
    id: 'sun', name: 'Sun', type: 'Star', kind: 'body', horizonsId: null, diameterKm: 1_392_700,
    periodDays: null, rotation: '~25–35 d', image: '/api/nasa/sdo/latest.jpg', imageFit: 'contain', markerSize: 96,
    imageCredit: 'NASA SDO · near-real-time 171 Å', imageObserved: 'Near-real-time · source cadence ~15 min',
    visualType: 'observed', sourcePage: 'https://sdo.gsfc.nasa.gov/data/',
    description: 'The Sun. LIVEWORLD uses NASA SDO near-real-time imagery while JPL/ICRF defines the surrounding Solar System frame.'
  },
  {
    id: 'mercury', name: 'Mercury', type: 'Planet', kind: 'body', horizonsId: '199', diameterKm: 4_879.4,
    periodDays: 87.969, rotation: '58.6 d', image: '/assets/space/planets/mercury.jpg', markerSize: 30,
    imageCredit: 'NASA/JHUAPL/Carnegie · MESSENGER global mosaic', imageObserved: 'MESSENGER mission mosaic',
    visualType: 'derived', sourcePage: 'https://photojournal.jpl.nasa.gov/catalog/PIA15190',
    description: 'Innermost planet. Current position is a JPL Horizons heliocentric state vector.'
  },
  {
    id: 'venus', name: 'Venus', type: 'Planet', kind: 'body', horizonsId: '299', diameterKm: 12_104,
    periodDays: 224.701, rotation: '243 d retrograde', image: '/assets/space/planets/venus.jpg', markerSize: 36,
    imageCredit: 'NASA/JPL/USGS · Magellan radar data', imageObserved: 'Radar-data globe · Magellan',
    visualType: 'derived', sourcePage: 'https://photojournal.jpl.nasa.gov/catalog/PIA00157',
    description: 'Second planet from the Sun. Surface visual is derived from Magellan radar mapping.'
  },
  {
    id: 'earth', name: 'Earth', type: 'Planet', kind: 'body', horizonsId: '399', diameterKm: 12_742,
    periodDays: 365.256, rotation: '23 h 56 m', image: '/assets/earth-blue-marble.jpg', markerSize: 42,
    imageCredit: 'NASA · Blue Marble', imageObserved: 'NASA Earth imagery composite',
    visualType: 'derived', sourcePage: 'https://science.nasa.gov/earth/',
    description: 'LIVEWORLD home body. Solar mode uses a mission-derived Earth marker; Earth mode remains the real Cesium globe.'
  },
  {
    id: 'moon', name: 'Moon', type: 'Natural satellite', kind: 'body', horizonsId: '301', parentId: 'earth', diameterKm: 3_474.8,
    periodDays: 27.3217, rotation: '27.3 d', image: '/assets/space/planets/moon.jpg', markerSize: 28,
    imageCredit: 'NASA/JPL-Caltech · spacecraft observation', imageObserved: 'Spacecraft observation',
    visualType: 'observed', sourcePage: 'https://photojournal.jpl.nasa.gov/catalog/PIA14114',
    description: 'Earth’s Moon. In Earth neighborhood view its position is the difference of current JPL heliocentric Earth and Moon states.'
  },
  {
    id: 'mars', name: 'Mars', type: 'Planet', kind: 'body', horizonsId: '499', diameterKm: 6_779,
    periodDays: 686.980, rotation: '24 h 37 m', image: '/assets/space/planets/mars.jpg', markerSize: 36,
    imageCredit: 'NASA/JPL/USGS · Viking global mosaic', imageObserved: 'Viking orbital image mosaic',
    visualType: 'derived', sourcePage: 'https://photojournal.jpl.nasa.gov/catalog/PIA00407',
    description: 'Mars. This body is a parent frame for Mars orbiters; surface imagery/terrain can be attached without changing spacecraft coordinates.'
  },
  {
    id: 'jupiter', name: 'Jupiter', type: 'Planet', kind: 'body', horizonsId: '599', diameterKm: 139_820,
    periodDays: 4332.59, rotation: '9 h 56 m', image: '/assets/space/planets/jupiter.jpg', markerSize: 60,
    imageCredit: 'NASA/JPL · Voyager full-disk image', imageObserved: 'Voyager observation',
    visualType: 'observed', sourcePage: 'https://photojournal.jpl.nasa.gov/catalog/PIA01509',
    description: 'Largest planet. Position comes from JPL Horizons; the marker uses spacecraft imagery.'
  },
  {
    id: 'saturn', name: 'Saturn', type: 'Planet', kind: 'body', horizonsId: '699', diameterKm: 116_460,
    periodDays: 10759.22, rotation: '10 h 42 m', image: '/assets/space/planets/saturn.jpg', imageFit: 'contain', markerSize: 82,
    imageCredit: 'NASA/JPL/Space Science Institute · Cassini', imageObserved: 'Cassini natural color · 27 Mar 2004',
    visualType: 'observed', sourcePage: 'https://photojournal.jpl.nasa.gov/catalog/PIA05389',
    description: 'Saturn shown with a real Cassini image. Position is supplied by JPL Horizons.'
  },
  {
    id: 'uranus', name: 'Uranus', type: 'Planet', kind: 'body', horizonsId: '799', diameterKm: 50_724,
    periodDays: 30688.5, rotation: '17 h 14 m retrograde', image: '/assets/space/planets/uranus.jpg', markerSize: 46,
    imageCredit: 'NASA/JPL · Voyager 2', imageObserved: 'Voyager 2 observation · 1986',
    visualType: 'observed', sourcePage: 'https://photojournal.jpl.nasa.gov/catalog/PIA18182',
    description: 'Ice giant. The displayed disk is a real Voyager 2 observation; location is JPL Horizons.'
  },
  {
    id: 'neptune', name: 'Neptune', type: 'Planet', kind: 'body', horizonsId: '899', diameterKm: 49_244,
    periodDays: 60182, rotation: '16 h 6 m', image: '/assets/space/planets/neptune.jpg', markerSize: 46,
    imageCredit: 'NASA/JPL · Voyager 2', imageObserved: 'Voyager 2 observation · 14 Aug 1989',
    visualType: 'observed', sourcePage: 'https://photojournal.jpl.nasa.gov/catalog/PIA02210',
    description: 'Outermost major planet in LIVEWORLD Solar view. Position is JPL Horizons.'
  },

  // Selected public spacecraft. parentId tells semantic zoom which local frame should own the object.
  { id: 'voyager-1', name: 'Voyager 1', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-31', markerSize: 24, mission: 'Interstellar mission', launchDate: '1977-09-05', operator: 'NASA/JPL' },
  { id: 'voyager-2', name: 'Voyager 2', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-32', markerSize: 24, mission: 'Interstellar mission', launchDate: '1977-08-20', operator: 'NASA/JPL' },
  { id: 'new-horizons', name: 'New Horizons', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-98', markerSize: 24, mission: 'Kuiper Belt / extended mission', launchDate: '2006-01-19', operator: 'NASA/JHUAPL' },
  { id: 'parker-solar-probe', name: 'Parker Solar Probe', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-96', markerSize: 24, mission: 'Solar probe', launchDate: '2018-08-12', operator: 'NASA/JHUAPL' },
  { id: 'solar-orbiter', name: 'Solar Orbiter', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-144', markerSize: 24, mission: 'Solar mission', launchDate: '2020-02-10', operator: 'ESA/NASA' },
  { id: 'juno', name: 'Juno', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-61', parentId: 'jupiter', markerSize: 24, mission: 'Jupiter orbiter', launchDate: '2011-08-05', operator: 'NASA/JPL' },
  { id: 'lucy', name: 'Lucy', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-49', markerSize: 24, mission: 'Trojan asteroid mission', launchDate: '2021-10-16', operator: 'NASA/SwRI' },
  { id: 'juice', name: 'JUICE', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-28', markerSize: 24, mission: 'Jupiter Icy Moons Explorer', launchDate: '2023-04-14', operator: 'ESA' },
  { id: 'europa-clipper', name: 'Europa Clipper', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-159', markerSize: 24, mission: 'Europa mission', launchDate: '2024-10-14', operator: 'NASA/JPL' },
  { id: 'psyche', name: 'Psyche', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-255', markerSize: 24, mission: '16 Psyche mission', launchDate: '2023-10-13', operator: 'NASA/JPL' },
  { id: 'jwst', name: 'James Webb Space Telescope', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-170', parentId: 'earth', markerSize: 24, mission: 'Sun–Earth L2 observatory', launchDate: '2021-12-25', operator: 'NASA/ESA/CSA' },
  { id: 'soho', name: 'SOHO', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-21', parentId: 'earth', markerSize: 24, mission: 'Sun–Earth L1 solar observatory', launchDate: '1995-12-02', operator: 'ESA/NASA' },
  { id: 'osiris-apex', name: 'OSIRIS-APEX', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-64', markerSize: 24, mission: 'Apophis extended mission (formerly OSIRIS-REx)', launchDate: '2016-09-08', operator: 'NASA/University of Arizona' },
  { id: 'hayabusa2', name: 'Hayabusa2', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-37', markerSize: 24, mission: 'Asteroid extended mission', launchDate: '2014-12-03', operator: 'JAXA' },
  { id: 'bepicolombo', name: 'BepiColombo MPO', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-121', parentId: 'mercury', markerSize: 24, mission: 'Mercury cruise / Mercury Planetary Orbiter', launchDate: '2018-10-20', operator: 'ESA/JAXA' },
  { id: 'mars-express', name: 'Mars Express', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-41', parentId: 'mars', markerSize: 24, mission: 'Mars orbiter', launchDate: '2003-06-02', operator: 'ESA' },
  { id: 'mars-odyssey', name: '2001 Mars Odyssey', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-53', parentId: 'mars', markerSize: 24, mission: 'Mars orbiter', launchDate: '2001-04-07', operator: 'NASA/JPL' },
  { id: 'mro', name: 'Mars Reconnaissance Orbiter', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-74', parentId: 'mars', markerSize: 24, mission: 'Mars orbiter', launchDate: '2005-08-12', operator: 'NASA/JPL' },
  { id: 'maven', name: 'MAVEN', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-202', parentId: 'mars', markerSize: 24, mission: 'Mars atmosphere orbiter', launchDate: '2013-11-18', operator: 'NASA/GSFC' },
  { id: 'hope', name: 'Emirates Mars Mission (Hope)', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-62', parentId: 'mars', markerSize: 24, mission: 'Mars orbiter', launchDate: '2020-07-19', operator: 'UAE Space Agency / MBRSC' },
  { id: 'lro', name: 'Lunar Reconnaissance Orbiter', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-85', parentId: 'moon', markerSize: 24, mission: 'Lunar orbiter', launchDate: '2009-06-18', operator: 'NASA/GSFC' },
  { id: 'danuri', name: 'Danuri (KPLO)', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-155', parentId: 'moon', markerSize: 24, mission: 'Lunar orbiter', launchDate: '2022-08-04', operator: 'KARI' },
  { id: 'aditya-l1', name: 'Aditya-L1', type: 'Spacecraft', kind: 'spacecraft', horizonsId: '-156', parentId: 'earth', markerSize: 24, mission: 'Sun–Earth L1 solar observatory', launchDate: '2023-09-02', operator: 'ISRO' },
];

const OBJECT_BY_ID = new Map(SPACE_OBJECTS.map((x) => [x.id, x]));

function julianDay(ms) {
  return ms / DAY_MS + 2440587.5;
}

function roundedEpochMs(ms = Date.now()) {
  return Math.floor(ms / STATE_REFRESH_MS) * STATE_REFRESH_MS;
}

function quoted(value) {
  return `'${value}'`;
}

function buildVectorParams(targetId, options = {}) {
  const params = new URLSearchParams({
    format: 'json',
    COMMAND: quoted(targetId),
    OBJ_DATA: quoted('NO'),
    MAKE_EPHEM: quoted('YES'),
    EPHEM_TYPE: quoted('VECTORS'),
    CENTER: quoted(options.center || '500@10'),
    OUT_UNITS: quoted('AU-D'),
    REF_PLANE: quoted('ECLIPTIC'),
    REF_SYSTEM: quoted('ICRF'),
    VEC_TABLE: quoted('2'),
    VEC_CORR: quoted('NONE'),
    CSV_FORMAT: quoted('YES'),
    TIME_DIGITS: quoted('SECONDS'),
  });
  if (options.tlist) {
    params.set('TLIST', quoted(options.tlist));
    params.set('TLIST_TYPE', quoted('JD'));
  } else {
    params.set('START_TIME', quoted(options.start));
    params.set('STOP_TIME', quoted(options.stop));
    params.set('STEP_SIZE', quoted(options.step));
  }
  return params;
}

function parseHorizonsStates(payload) {
  if (!payload || typeof payload !== 'object') throw new Error('Horizons returned an invalid JSON payload.');
  if (payload.error) throw new Error(payload.error);
  const text = String(payload.result || '');
  const start = text.indexOf('$$SOE');
  const end = text.indexOf('$$EOE');
  if (start < 0 || end < 0 || end <= start) throw new Error('Horizons response has no ephemeris table.');
  const rows = text.slice(start + 5, end).split(/\r?\n/).map((x) => x.trim()).filter(Boolean);
  const states = [];
  for (const row of rows) {
    const fields = row.split(',').map((x) => x.trim()).filter((x) => x !== '');
    if (fields.length < 8) continue;
    const jd = Number(fields[0]);
    const numeric = fields.slice(2).map(Number).filter(Number.isFinite);
    if (!Number.isFinite(jd) || numeric.length < 6) continue;
    states.push({
      jd,
      calendar: fields[1] || '',
      // Three uses Y as up. Swap Horizons Y/Z only for rendering convention.
      positionAu: new THREE.Vector3(numeric[0], numeric[2], numeric[1]),
      velocityAuPerDay: new THREE.Vector3(numeric[3], numeric[5], numeric[4]),
    });
  }
  if (!states.length) throw new Error('Horizons ephemeris table could not be parsed.');
  return states;
}

function formatDateUTC(date) {
  const y = date.getUTCFullYear();
  const m = String(date.getUTCMonth() + 1).padStart(2, '0');
  const d = String(date.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function speedKmS(vectorAuPerDay) {
  return vectorAuPerDay.length() * AU_KM / 86400;
}

function bodyCenterCode(id) {
  const def = OBJECT_BY_ID.get(id);
  return def?.horizonsId ? `500@${def.horizonsId}` : '500@10';
}

function markerVisualLabel(def) {
  if (def.kind === 'spacecraft') return 'EPHEMERIS';
  if (def.visualType === 'observed') return 'OBSERVED';
  if (def.visualType === 'derived') return 'DERIVED';
  return 'SIMULATED';
}

function createMarker(def) {
  const marker = document.createElement('button');
  marker.type = 'button';
  marker.className = `space-marker ${def.kind === 'spacecraft' ? 'spacecraft-marker' : 'body-marker'}`;
  marker.dataset.id = def.id;
  marker.dataset.visual = def.kind === 'spacecraft' ? 'ephemeris' : (def.visualType || 'simulated');
  marker.hidden = def.id !== 'sun';
  marker.title = def.name;

  if (def.kind === 'spacecraft') {
    const glyph = document.createElement('span');
    glyph.className = 'spacecraft-glyph';
    glyph.textContent = '◇';
    marker.appendChild(glyph);
  } else {
    const image = document.createElement('img');
    image.src = def.image;
    image.alt = '';
    image.loading = 'lazy';
    image.referrerPolicy = 'no-referrer';
    image.style.objectFit = def.imageFit || 'cover';
    image.addEventListener('error', () => marker.classList.add('image-error'));
    marker.appendChild(image);
  }

  const label = document.createElement('span');
  label.className = 'space-marker-label';
  label.textContent = def.name;
  marker.appendChild(label);

  const provenance = document.createElement('span');
  provenance.className = 'space-marker-provenance';
  provenance.textContent = markerVisualLabel(def);
  marker.appendChild(provenance);
  return marker;
}

function genericFramePreset(bodyId) {
  const def = OBJECT_BY_ID.get(bodyId);
  const diameter = Number(def?.diameterKm) || 12_000;
  const kmPerUnit = Math.max(300, Math.min(30_000, diameter / 10));
  return {
    id: bodyId,
    label: `${String(def?.name || bodyId).toUpperCase()} NEIGHBORHOOD`,
    detail: `${def?.name || bodyId}-centered semantic scale · JPL positions`,
    scale: AU_KM / kmPerUnit,
    defaultDistance: 60,
    exitDistance: 250,
  };
}

export class SolarSystemEngine {
  constructor(container, options = {}) {
    this.container = container;
    this.onSelectBody = options.onSelectBody || (() => {});
    this.onRequestEarth = options.onRequestEarth || (() => {});
    this.onStatus = options.onStatus || (() => {});
    this.onFrameChange = options.onFrameChange || (() => {});
    this.visible = false;
    this.entries = new Map();
    this.selectedId = null;
    this.followId = null;
    this.pendingFocusId = null;
    this.trajectoryLines = new Map();
    this.localGuides = new Map();
    this.lastRefreshAt = 0;
    this.refreshPromise = null;
    this.pointer = { down: false, button: 0, moved: false, x: 0, y: 0 };
    this.keys = new Set();
    this.frameId = 'earth';
    this.framePreset = FRAME_PRESETS.earth;
    this.frameOriginAu = new THREE.Vector3();
    this.frameSwitchLockUntil = 0;

    this.container.classList.add('space-engine');
    this.sky = document.createElement('div');
    this.sky.className = 'space-real-sky';
    this.sky.style.backgroundImage = `linear-gradient(rgba(0,4,10,.16),rgba(0,4,10,.34)),url("${WISE_SKY}")`;
    this.container.appendChild(this.sky);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(54, 1, 0.01, 100_000);
    try {
      this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    } catch (error) {
      throw new Error(`Solar WebGL renderer could not start: ${error?.message || error}`);
    }
    this.renderer.setPixelRatio(Math.min(MAX_PIXEL_RATIO, window.devicePixelRatio || 1));
    this.renderer.setClearColor(0x000000, 0);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.domElement.className = 'solar-canvas';
    this.container.appendChild(this.renderer.domElement);

    this.overlay = document.createElement('div');
    this.overlay.className = 'space-overlay';
    this.container.appendChild(this.overlay);

    this.frameHud = document.createElement('div');
    this.frameHud.className = 'space-frame-hud';
    this.frameHud.innerHTML = '<strong></strong><span></span>';
    this.container.appendChild(this.frameHud);

    this.lookTarget = new THREE.Vector3(0, 0, 0);
    this.camera.position.set(42, 42, 78);
    this.camera.lookAt(this.lookTarget);

    for (const def of SPACE_OBJECTS) this.addObject(def);
    const sun = this.entries.get('sun');
    if (sun) {
      sun.basePositionAu.set(0, 0, 0);
      sun.currentPositionAu.set(0, 0, 0);
      sun.stateTimeMs = Date.now();
      sun.marker.hidden = false;
      sun.available = true;
    }

    this.installControls();
    this.resize();
    this._resize = () => this.resize();
    window.addEventListener('resize', this._resize);
    this.setFrame('earth', { resetCamera: true, silent: true });
    this.animate();
  }

  addObject(def) {
    const marker = createMarker(def);
    marker.style.setProperty('--marker-size', `${def.markerSize || 32}px`);
    marker.style.setProperty('--body-color', BODY_COLORS[def.id] || '#b7d7e8');
    marker.addEventListener('click', (event) => {
      event.stopPropagation();
      this.selectObject(def.id, true);
    });
    marker.addEventListener('dblclick', (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (def.id === 'earth') this.onRequestEarth();
      else this.focusBody(def.id, true);
    });
    this.overlay.appendChild(marker);
    this.entries.set(def.id, {
      def,
      marker,
      basePositionAu: new THREE.Vector3(),
      currentPositionAu: new THREE.Vector3(),
      velocityAuPerDay: new THREE.Vector3(),
      scenePosition: new THREE.Vector3(),
      stateTimeMs: 0,
      available: def.id === 'sun',
      error: '',
    });
  }

  getFramePreset(id = this.frameId) {
    return FRAME_PRESETS[id] || genericFramePreset(id);
  }

  currentOriginEntry() {
    if (this.frameId === 'solar') return null;
    return this.entries.get(this.frameId) || null;
  }

  updateFrameOrigin() {
    const origin = this.currentOriginEntry();
    if (origin?.available) this.frameOriginAu.copy(origin.currentPositionAu);
    else this.frameOriginAu.set(0, 0, 0);
  }

  isRelevantInFrame(entry) {
    if (!entry.available) return false;
    if (this.frameId === 'solar') return true;
    const id = entry.def.id;
    if (id === this.frameId) return true;

    if (this.frameId === 'earth') {
      return id === 'moon' || entry.def.parentId === 'earth' || entry.def.parentId === 'moon';
    }
    if (this.frameId === 'moon') {
      return id === 'earth' || entry.def.parentId === 'moon';
    }
    return entry.def.parentId === this.frameId;
  }

  scenePositionForAu(positionAu, out = new THREE.Vector3()) {
    if (this.frameId === 'solar') return out.copy(positionAu).multiplyScalar(SOLAR_AU_TO_SCENE);
    return out.copy(positionAu).sub(this.frameOriginAu).multiplyScalar(this.framePreset.scale);
  }

  updateScenePositions() {
    this.updateFrameOrigin();
    for (const entry of this.entries.values()) this.scenePositionForAu(entry.currentPositionAu, entry.scenePosition);
  }

  objectSnapshot(entry) {
    const def = entry.def;
    const distanceAu = entry.currentPositionAu.length();
    let relativeDistanceKm = null;
    if (this.frameId !== 'solar' && entry.available) {
      relativeDistanceKm = entry.currentPositionAu.distanceTo(this.frameOriginAu) * AU_KM;
    }
    return {
      ...def,
      available: entry.available,
      error: entry.error,
      distanceAu,
      relativeDistanceKm,
      speedKmS: speedKmS(entry.velocityAuPerDay),
      stateTime: entry.stateTimeMs ? new Date(entry.stateTimeMs).toISOString() : null,
      source: def.id === 'sun' ? 'NASA SDO NRT image' : 'JPL Horizons VECTORS',
      visualState: markerVisualLabel(def),
      renderFrame: this.framePreset.label,
      frame: def.id === 'sun' ? 'HELIOCENTRIC ORIGIN' : 'HELIOCENTRIC · ECLIPTIC J2000 · ICRF',
    };
  }

  async fetchState(entry, epochMs) {
    if (!entry.def.horizonsId) return;
    const jd = julianDay(epochMs).toFixed(8);
    const params = buildVectorParams(entry.def.horizonsId, { tlist: jd });
    const response = await fetch(`${HORIZONS_ENDPOINT}?${params.toString()}`, { headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error(`Horizons HTTP ${response.status}`);
    const states = parseHorizonsStates(await response.json());
    const state = states[0];
    entry.basePositionAu.copy(state.positionAu);
    entry.currentPositionAu.copy(state.positionAu);
    entry.velocityAuPerDay.copy(state.velocityAuPerDay);
    entry.stateTimeMs = (state.jd - 2440587.5) * DAY_MS;
    entry.available = true;
    entry.error = '';
  }

  async refreshStates(force = false) {
    if (this.refreshPromise) return this.refreshPromise;
    const now = Date.now();
    if (!force && now - this.lastRefreshAt < STATE_REFRESH_MS * 0.8) return;
    const epochMs = roundedEpochMs(now);
    const entries = [...this.entries.values()]
      .filter((entry) => entry.def.horizonsId)
      .sort((a, b) => Number(a.def.kind !== 'body') - Number(b.def.kind !== 'body'));
    this.onStatus({ phase: 'loading', loaded: 0, total: entries.length });

    this.refreshPromise = (async () => {
      let cursor = 0;
      let loaded = 0;
      let failed = 0;
      const worker = async () => {
        while (cursor < entries.length) {
          const index = cursor++;
          const entry = entries[index];
          try {
            await this.fetchState(entry, epochMs);
            loaded += 1;
          } catch (error) {
            failed += 1;
            entry.error = error?.message || String(error);
          }
          this.onStatus({ phase: 'loading', loaded, failed, total: entries.length });
        }
      };
      await Promise.all([worker(), worker(), worker(), worker()]);
      this.lastRefreshAt = Date.now();
      this.updateScenePositions();
      this.onStatus({ phase: 'ready', loaded, failed, total: entries.length });
      if (this.frameId === 'earth') this.ensureEarthMoonGuide().catch(() => {});
      if (this.pendingFocusId) {
        const pending = this.pendingFocusId;
        this.pendingFocusId = null;
        this.focusBody(pending, true);
      } else if (this.selectedId) {
        this.selectObject(this.selectedId, true);
      }
    })().finally(() => { this.refreshPromise = null; });

    return this.refreshPromise;
  }

  updateCurrentPositions(nowMs) {
    for (const entry of this.entries.values()) {
      if (!entry.available || entry.def.id === 'sun') continue;
      const dtDays = (nowMs - entry.stateTimeMs) / DAY_MS;
      entry.currentPositionAu.copy(entry.basePositionAu).addScaledVector(entry.velocityAuPerDay, dtDays);
    }
    const oldOrigin = this.frameOriginAu.clone();
    this.updateScenePositions();

    if (this.followId) {
      const follow = this.entries.get(this.followId);
      if (follow?.available) {
        const next = follow.scenePosition;
        const delta = next.clone().sub(this.lookTarget);
        this.lookTarget.copy(next);
        this.camera.position.add(delta);
      }
    } else if (this.frameId !== 'solar' && oldOrigin.distanceToSquared(this.frameOriginAu) > 0) {
      // Local coordinates are re-centered every frame, so the origin body stays at scene zero.
      // No camera translation is required; this is the floating-origin behavior.
    }
  }

  markerScaleFor(entry) {
    const distance = Math.max(0.1, this.camera.position.distanceTo(entry.scenePosition));
    let scale = 1;
    if (entry.def.kind === 'body') {
      if (entry.def.id === this.frameId && this.frameId !== 'solar') scale = Math.min(3.2, Math.max(1.7, 115 / distance));
      else if (this.frameId === 'solar') scale = Math.min(1.45, Math.max(.78, 120 / Math.max(120, distance)));
      else scale = Math.min(1.25, Math.max(.84, 70 / Math.max(70, distance)));
    } else if (entry.def.id === this.selectedId) {
      scale = 1.25;
    }
    return scale;
  }

  projectMarkers() {
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;
    const temp = new THREE.Vector3();
    for (const entry of this.entries.values()) {
      const marker = entry.marker;
      if (!this.isRelevantInFrame(entry)) { marker.hidden = true; continue; }
      temp.copy(entry.scenePosition).project(this.camera);
      const visible = temp.z > -1 && temp.z < 1 && Math.abs(temp.x) < 1.18 && Math.abs(temp.y) < 1.18;
      marker.hidden = !visible;
      if (!visible) continue;
      marker.style.transform = `translate3d(${(temp.x * .5 + .5) * width}px,${(-temp.y * .5 + .5) * height}px,0) translate(-50%,-50%) scale(${this.markerScaleFor(entry).toFixed(3)})`;
      marker.style.zIndex = String(Math.round(1000 - temp.z * 400));
      marker.classList.toggle('selected', entry.def.id === this.selectedId);
      marker.classList.toggle('following', entry.def.id === this.followId);
      marker.classList.toggle('frame-origin', entry.def.id === this.frameId && this.frameId !== 'solar');
    }
  }

  updateSky() {
    const dir = new THREE.Vector3();
    this.camera.getWorldDirection(dir);
    const lon = Math.atan2(dir.z, dir.x);
    const lat = Math.asin(Math.max(-1, Math.min(1, dir.y)));
    const x = 50 - (lon / (Math.PI * 2)) * 100;
    const y = 50 + (lat / Math.PI) * 70;
    this.sky.style.backgroundPosition = `${x}% ${y}%`;
  }

  updateFrameHud() {
    const strong = this.frameHud.querySelector('strong');
    const span = this.frameHud.querySelector('span');
    strong.textContent = this.framePreset.label;
    span.textContent = `${this.framePreset.detail} · positions JPL Horizons`;
  }

  setFrame(frameId, options = {}) {
    const next = frameId === 'solar' ? 'solar' : (this.entries.has(frameId) ? frameId : 'solar');
    this.frameId = next;
    this.framePreset = this.getFramePreset(next);
    this.frameSwitchLockUntil = performance.now() + 650;
    this.container.classList.add('frame-transition');
    clearTimeout(this._frameTransitionTimer);
    this._frameTransitionTimer = setTimeout(() => this.container.classList.remove('frame-transition'), 220);
    this.updateScenePositions();
    this.updateFrameHud();

    const direction = this.camera.position.clone().sub(this.lookTarget).normalize();
    if (!Number.isFinite(direction.x) || direction.lengthSq() < .5) direction.set(1, .35, 1).normalize();

    if (options.resetCamera !== false) {
      let target = new THREE.Vector3(0, 0, 0);
      if (next === 'solar' && options.anchorId) {
        const anchor = this.entries.get(options.anchorId);
        if (anchor?.available) target.copy(anchor.scenePosition);
      }
      this.lookTarget.copy(target);
      const distance = Number(options.distance) || this.framePreset.defaultDistance;
      this.camera.position.copy(target).addScaledVector(direction, distance);
      this.camera.lookAt(this.lookTarget);
    }

    for (const item of this.trajectoryLines.values()) {
      item.line.visible = item.visible && item.frameId === this.frameId;
    }
    for (const [key, guide] of this.localGuides) guide.line.visible = key.startsWith(`${this.frameId}:`);

    if (this.frameId === 'earth') this.ensureEarthMoonGuide().catch(() => {});
    if (!options.silent) {
      this.onFrameChange({ id: this.frameId, label: this.framePreset.label, detail: this.framePreset.detail });
      this.onStatus({ phase: 'frame', message: this.framePreset.label });
    }
  }

  maybeChangeSemanticFrame() {
    if (performance.now() < this.frameSwitchLockUntil) return;
    if (this.frameId !== 'solar') {
      const distance = this.camera.position.distanceTo(this.lookTarget);
      if (distance > this.framePreset.exitDistance) {
        const leaving = this.frameId;
        this.setFrame('solar', { anchorId: leaving, distance: 150 });
      }
      return;
    }

    if (!this.selectedId) return;
    const selected = this.entries.get(this.selectedId);
    if (!selected?.available || selected.def.kind !== 'body' || selected.def.id === 'sun') return;
    const distance = this.camera.position.distanceTo(selected.scenePosition);
    if (distance < 8) this.setFrame(selected.def.id, { distance: this.getFramePreset(selected.def.id).defaultDistance });
  }

  installControls() {
    const canvas = this.renderer.domElement;
    canvas.tabIndex = 0;
    canvas.addEventListener('contextmenu', (event) => event.preventDefault());
    canvas.addEventListener('pointerdown', (event) => {
      canvas.focus();
      this.pointer.down = true;
      this.pointer.button = event.button;
      this.pointer.moved = false;
      this.pointer.x = event.clientX;
      this.pointer.y = event.clientY;
      canvas.setPointerCapture?.(event.pointerId);
    });
    canvas.addEventListener('pointermove', (event) => {
      if (!this.pointer.down) return;
      const dx = event.clientX - this.pointer.x;
      const dy = event.clientY - this.pointer.y;
      this.pointer.x = event.clientX;
      this.pointer.y = event.clientY;
      if (Math.abs(dx) + Math.abs(dy) > 2) this.pointer.moved = true;
      if (this.pointer.moved) this.followId = null;
      if (this.pointer.button === 2 || event.shiftKey) this.panCamera(dx, dy);
      else this.orbitCamera(dx, dy);
    });
    canvas.addEventListener('pointerup', () => { this.pointer.down = false; });
    canvas.addEventListener('wheel', (event) => {
      event.preventDefault();
      this.followId = null;
      const forward = new THREE.Vector3();
      this.camera.getWorldDirection(forward).normalize();
      const reference = Math.max(0.4, this.camera.position.distanceTo(this.lookTarget));
      const amount = Math.max(0.08, reference * 0.16) * Math.sign(event.deltaY);
      const delta = forward.multiplyScalar(amount);
      this.camera.position.addScaledVector(delta, -1);
      this.lookTarget.addScaledVector(delta, -1);
      this.camera.lookAt(this.lookTarget);
      this.maybeChangeSemanticFrame();
    }, { passive: false });
    canvas.addEventListener('dblclick', () => {
      if (this.selectedId === 'earth') this.onRequestEarth();
      else if (this.selectedId) this.focusBody(this.selectedId, true);
    });
    window.addEventListener('keydown', (event) => {
      if (!this.visible) return;
      const key = event.key.toLowerCase();
      if (['w','a','s','d','q','e'].includes(key)) {
        this.keys.add(key);
        this.followId = null;
        event.preventDefault();
      } else if (key === 'escape') {
        this.followId = null;
      } else if (key === 'f' && this.selectedId) {
        this.focusBody(this.selectedId, false);
      } else if (key === '0') {
        this.setFrame('solar');
      }
    });
    window.addEventListener('keyup', (event) => this.keys.delete(event.key.toLowerCase()));
  }

  orbitCamera(dx, dy) {
    const direction = this.lookTarget.clone().sub(this.camera.position);
    const distance = Math.max(0.1, direction.length());
    const spherical = new THREE.Spherical().setFromVector3(direction);
    spherical.theta -= dx * 0.0045;
    spherical.phi = Math.max(0.025, Math.min(Math.PI - 0.025, spherical.phi + dy * 0.0045));
    direction.setFromSpherical(spherical).setLength(distance);
    this.lookTarget.copy(this.camera.position).add(direction);
    this.camera.lookAt(this.lookTarget);
  }

  panCamera(dx, dy) {
    const distance = Math.max(0.1, this.camera.position.distanceTo(this.lookTarget));
    const scale = distance * 0.0014;
    const forward = new THREE.Vector3();
    this.camera.getWorldDirection(forward);
    const right = new THREE.Vector3().crossVectors(forward, this.camera.up).normalize();
    const up = new THREE.Vector3().crossVectors(right, forward).normalize();
    const delta = right.multiplyScalar(-dx * scale).add(up.multiplyScalar(dy * scale));
    this.camera.position.add(delta);
    this.lookTarget.add(delta);
    this.camera.lookAt(this.lookTarget);
  }

  updateKeyboard(dt) {
    if (!this.keys.size) return;
    const distance = Math.max(1, this.camera.position.distanceTo(this.lookTarget));
    const speed = Math.max(0.8, distance * 0.9) * dt;
    const forward = new THREE.Vector3();
    this.camera.getWorldDirection(forward).normalize();
    const right = new THREE.Vector3().crossVectors(forward, this.camera.up).normalize();
    const up = this.camera.up.clone().normalize();
    const delta = new THREE.Vector3();
    if (this.keys.has('w')) delta.add(forward);
    if (this.keys.has('s')) delta.sub(forward);
    if (this.keys.has('d')) delta.add(right);
    if (this.keys.has('a')) delta.sub(right);
    if (this.keys.has('e')) delta.add(up);
    if (this.keys.has('q')) delta.sub(up);
    if (delta.lengthSq()) {
      delta.normalize().multiplyScalar(speed);
      this.camera.position.add(delta);
      this.lookTarget.add(delta);
      this.camera.lookAt(this.lookTarget);
      this.maybeChangeSemanticFrame();
    }
  }

  selectObject(id, notify = true) {
    const entry = this.entries.get(id);
    if (!entry) return null;
    this.selectedId = id;
    const snapshot = this.objectSnapshot(entry);
    if (notify) this.onSelectBody(snapshot);
    return snapshot;
  }

  focusBody(id, notify = true) {
    const entry = this.entries.get(id);
    if (!entry) return false;
    if (!entry.available && id !== 'sun') {
      this.selectedId = id;
      this.pendingFocusId = id;
      this.onSelectBody(this.objectSnapshot(entry));
      this.onStatus({ phase: 'loading', message: `${entry.def.name}: waiting for current JPL Horizons state…` });
      this.refreshStates(false);
      return false;
    }

    this.selectedId = id;
    this.followId = null;

    if (entry.def.kind === 'body' && id !== 'sun') {
      this.setFrame(id, { distance: this.getFramePreset(id).defaultDistance });
      this.lookTarget.set(0, 0, 0);
      this.camera.lookAt(this.lookTarget);
    } else {
      const targetFrame = entry.def.parentId && this.entries.has(entry.def.parentId) ? entry.def.parentId : 'solar';
      this.setFrame(targetFrame, { resetCamera: false, silent: false });
      this.updateScenePositions();
      const target = entry.scenePosition.clone();
      const currentDir = this.camera.position.clone().sub(this.lookTarget).normalize();
      if (!Number.isFinite(currentDir.x) || currentDir.lengthSq() < .1) currentDir.set(1, .4, 1).normalize();
      const distance = entry.def.kind === 'spacecraft' ? 26 : 18;
      this.lookTarget.copy(target);
      this.camera.position.copy(target).addScaledVector(currentDir, distance);
      this.camera.lookAt(this.lookTarget);
    }

    if (notify) this.onSelectBody(this.objectSnapshot(entry));
    return true;
  }

  toggleFollow(id = this.selectedId) {
    if (!id || !this.entries.get(id)?.available) return false;
    if (this.followId === id) {
      this.followId = null;
      return false;
    }
    this.focusBody(id, false);
    this.followId = id;
    return true;
  }

  trajectoryQueryContext(entry) {
    if (this.frameId === 'solar') return { frameId: 'solar', center: '500@10' };
    const centerEntry = this.entries.get(this.frameId);
    if (!centerEntry?.def.horizonsId) return { frameId: 'solar', center: '500@10' };

    // If the selected object is the current frame origin, its meaningful orbit belongs
    // to the parent frame: Moon around Earth, planets around the Sun.
    if (entry.def.id === this.frameId) {
      if (entry.def.parentId && this.entries.has(entry.def.parentId)) {
        return { frameId: entry.def.parentId, center: bodyCenterCode(entry.def.parentId) };
      }
      return { frameId: 'solar', center: '500@10' };
    }

    if (entry.def.parentId === this.frameId || (this.frameId === 'earth' && entry.def.id === 'moon')) {
      return { frameId: this.frameId, center: bodyCenterCode(this.frameId) };
    }
    return { frameId: 'solar', center: '500@10' };
  }

  async toggleTrajectory(id = this.selectedId) {
    if (!id) return { visible: false };
    const existing = this.trajectoryLines.get(id);
    if (existing && existing.frameId === this.frameId) {
      existing.visible = !existing.visible;
      existing.line.visible = existing.visible;
      return { visible: existing.visible };
    }
    if (existing) {
      existing.line.removeFromParent();
      existing.line.geometry?.dispose?.();
      existing.line.material?.dispose?.();
      this.trajectoryLines.delete(id);
    }

    const entry = this.entries.get(id);
    if (!entry?.def.horizonsId) return { visible: false };
    const context = this.trajectoryQueryContext(entry);
    const now = new Date();
    const span = entry.def.kind === 'spacecraft' ? 30 : Math.min(365, Math.max(35, Math.round((entry.def.periodDays || 180) * .35)));
    const start = new Date(now.getTime() - span * DAY_MS);
    const stop = new Date(now.getTime() + span * DAY_MS);
    const stepHours = entry.def.kind === 'spacecraft' && context.frameId !== 'solar' ? 3 : Math.max(12, Math.ceil((span * 48) / 180) * 12);
    const params = buildVectorParams(entry.def.horizonsId, {
      center: context.center,
      start: formatDateUTC(start),
      stop: formatDateUTC(stop),
      step: `${stepHours} h`,
    });
    this.onStatus({ phase: 'trajectory', message: `Loading JPL trajectory for ${entry.def.name}…` });
    const response = await fetch(`${HORIZONS_ENDPOINT}?${params.toString()}`, { headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error(`Horizons trajectory HTTP ${response.status}`);
    const states = parseHorizonsStates(await response.json());
    const scale = context.frameId === 'solar' ? SOLAR_AU_TO_SCENE : this.getFramePreset(context.frameId).scale;
    const points = states.map((state) => state.positionAu.clone().multiplyScalar(scale));
    const geometry = new THREE.BufferGeometry().setFromPoints(points);
    const material = new THREE.LineBasicMaterial({ color: entry.def.kind === 'spacecraft' ? 0x75d5ff : 0x6c8798, transparent: true, opacity: .72 });
    const line = new THREE.Line(geometry, material);
    line.userData.liveworldTrajectory = id;
    this.scene.add(line);
    const item = { line, states, frameId: context.frameId, visible: true };
    this.trajectoryLines.set(id, item);
    if (context.frameId !== this.frameId) {
      const framePreset = this.getFramePreset(context.frameId);
      this.setFrame(context.frameId, {
        anchorId: context.frameId === 'solar' ? entry.def.id : undefined,
        distance: context.frameId === 'solar' ? 150 : framePreset.defaultDistance,
      });
    }
    line.visible = true;
    this.onStatus({ phase: 'trajectory-ready', message: `${entry.def.name} trajectory · JPL Horizons · ${context.frameId.toUpperCase()} frame` });
    return { visible: true };
  }

  async ensureEarthMoonGuide() {
    const key = 'earth:moon';
    if (this.localGuides.has(key)) {
      this.localGuides.get(key).line.visible = this.frameId === 'earth';
      return;
    }
    const moon = this.entries.get('moon');
    if (!moon?.def.horizonsId) return;
    const now = new Date();
    const start = new Date(now.getTime() - 4 * DAY_MS);
    const stop = new Date(now.getTime() + 32 * DAY_MS);
    const params = buildVectorParams(moon.def.horizonsId, {
      center: bodyCenterCode('earth'),
      start: formatDateUTC(start),
      stop: formatDateUTC(stop),
      step: '6 h',
    });
    try {
      const response = await fetch(`${HORIZONS_ENDPOINT}?${params.toString()}`, { headers: { Accept: 'application/json' } });
      if (!response.ok) throw new Error(`Moon guide HTTP ${response.status}`);
      const states = parseHorizonsStates(await response.json());
      const points = states.map((state) => state.positionAu.clone().multiplyScalar(FRAME_PRESETS.earth.scale));
      const geometry = new THREE.BufferGeometry().setFromPoints(points);
      const material = new THREE.LineBasicMaterial({ color: 0x9eb6c9, transparent: true, opacity: .26 });
      const line = new THREE.Line(geometry, material);
      line.userData.liveworldGuide = key;
      line.visible = this.frameId === 'earth';
      this.scene.add(line);
      this.localGuides.set(key, { line, states, source: 'JPL Horizons Earth-centered Moon trajectory' });
    } catch (error) {
      console.warn('Earth–Moon JPL guide unavailable.', error);
    }
  }

  findBody(query) {
    const q = String(query || '').trim().toLowerCase();
    if (!q) return null;
    const aliases = {
      terra: 'earth', luna: 'moon', sol: 'sun', 'voyager1': 'voyager-1', 'voyager2': 'voyager-2',
      psp: 'parker-solar-probe', jwst: 'jwst', 'mặt trăng': 'moon', 'mat trang': 'moon',
      'trái đất': 'earth', 'trai dat': 'earth', 'sao hỏa': 'mars', 'sao hoa': 'mars',
    };
    const direct = this.entries.get(aliases[q] || q);
    if (direct) return this.objectSnapshot(direct);
    for (const entry of this.entries.values()) {
      if (entry.def.name.toLowerCase().includes(q) || String(entry.def.mission || '').toLowerCase().includes(q)) return this.objectSnapshot(entry);
    }
    return null;
  }

  getBody(id) {
    const entry = this.entries.get(id);
    return entry ? this.objectSnapshot(entry) : OBJECT_BY_ID.get(id) || null;
  }

  getBodyPosition(id) {
    const entry = this.entries.get(id);
    return entry?.available ? entry.scenePosition.clone() : null;
  }

  enterFromEarth() {
    this.setFrame('earth', { resetCamera: true, distance: FRAME_PRESETS.earth.defaultDistance, silent: false });
    this.selectedId = 'earth';
    const earth = this.entries.get('earth');
    if (earth) this.onSelectBody(this.objectSnapshot(earth));
  }

  setVisible(visible, options = {}) {
    this.visible = Boolean(visible);
    this.container.hidden = !this.visible;
    if (this.visible) {
      this.resize();
      this.renderer.domElement.focus();
      if (options.enterFromEarth) this.enterFromEarth();
      this.refreshStates(false);
    }
  }

  resize() {
    const width = Math.max(1, this.container.clientWidth || window.innerWidth);
    const height = Math.max(1, this.container.clientHeight || window.innerHeight);
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
  }

  animate() {
    requestAnimationFrame(() => this.animate());
    const now = performance.now();
    const dt = Math.min(.05, (now - (this._lastFrame || now)) / 1000);
    this._lastFrame = now;
    if (!this.visible) return;
    if (Date.now() - this.lastRefreshAt > STATE_REFRESH_MS) this.refreshStates(false);
    this.updateCurrentPositions(Date.now());
    this.updateKeyboard(dt);
    this.projectMarkers();
    this.updateSky();
    this.renderer.render(this.scene, this.camera);
  }
}
