# LIVEWORLD v0.8.2 — Browser First

This build keeps the v0.8 Solar System Core and restores the intended deployment model: one normal web site opened directly in Chrome, Edge, Safari or Firefox on phone, tablet, laptop or desktop.

## Browser-first startup

- Cesium gets a normal browser-managed WebGL context. LIVEWORLD no longer probes WebGL with temporary canvases, forces WebGL1, assumes SwiftShader, or tells visitors to launch Chrome with command-line flags.
- `showRenderLoopErrors` is disabled so a low-level Cesium modal does not cover the whole experience.
- If a browser session truly exposes no usable 3D context, LIVEWORLD falls back to a lightweight animated NASA Blue Marble Earth instead of a fatal startup screen.
- A later WebGL context-loss also downgrades to the lightweight Earth instead of leaving a broken page.
- Earth starts from a 2048×1024 NASA Blue Marble derivative for conservative mobile texture limits. The preserved 3600×1800 and 5400×2700 assets are unchanged.
- High-resolution Earth detail still streams as tiled ArcGIS World Imagery after the globe is ready.
- The large Black Marble night texture is enabled only when the active graphics context reports a texture limit of at least 4096 px.

## Adaptive graphics

LIVEWORLD uses one codebase and adjusts only rendering cost:

- Mobile / low-resource browser: lower resolution scale, lighter HDR load, looser globe screen-space error.
- Standard browser: balanced quality.
- Higher-resource browser: full standard resolution and tighter globe LOD.

Positions and source data are not degraded by the graphics profile.

## Solar System Core retained

- Three.js Solar remains lazy-loaded only when SPACE is requested.
- Semantic frames remain: Earth–Moon neighborhood, Moon, Mars, Jupiter and Solar System.
- JPL Horizons state vectors remain positional truth; only render scale changes by semantic frame.
- Earth–Moon trajectory guidance remains JPL-derived.
- Spacecraft parent frames and provenance labels remain intact.

## Deploy

```bash
chmod +x deploy.sh
./deploy.sh
```

If the JPL/NASA proxy locations were never installed:

```bash
sudo bash nginx/install-space-api.sh
```

The CelesTrak warm snapshot service remains unchanged:

```bash
sudo bash server/install-live-data.sh
```

Then refresh the browser once.

## Quick verification

```bash
curl -s https://liveword.longh.org/ | grep 'v0.8.2-browser'
curl -s https://liveword.longh.org/app.js | grep 'compatibility Earth'
curl -s https://liveword.longh.org/live-data/space-active.meta.json | python3 -m json.tool
```

Expected behavior:

1. A normal browser with 3D support opens directly into the Cesium Earth.
2. Phone/laptop/desktop use the same URL and same codebase.
3. SPACE is created only when requested.
4. If 3D is unavailable in one particular browser session, the page still opens with the NASA lightweight Earth and no fatal WebGL panel.
5. Network failure of the orbital catalog does not take the Earth globe down.

## Next v0.8 step

Attach real Moon imagery/terrain and mission sites to the semantic Moon frame, followed by Mars imagery/DEM and cached official spacecraft ephemerides.
