# LIVEWORLD asset preservation policy

This build never replaces a higher-resolution source asset with a lower-resolution derivative.

Earth assets:
- `public/assets/earth-blue-marble-master-5400x2700.jpg` — preserved NASA Blue Marble master.
- `public/assets/earth-blue-marble-web-3600x1800.jpg` — preserved higher web derivative.
- `public/assets/earth-blue-marble-web-2048x1024.jpg` — conservative startup derivative for mobile/browser compatibility.
- `public/assets/earth-blue-marble.jpg` — canonical preserved master copy for compatibility/archive.

v0.8.2 does not create a temporary WebGL probe context. Cesium starts with a normal browser-managed context and the 2048 px startup image. Detailed Earth imagery streams as tiles after startup. Higher-resolution masters remain intact for future Earth tile pyramids.

Solar/planet imagery is additive. Missing remote imagery must fall back visually rather than modifying preserved Earth assets.

Future Earth/Moon/Mars detail must be non-destructive layers/tiles: imagery pyramids, DEM/terrain, buildings, geology, landing sites and mission products. Never upscale a reduced derivative and never discard the source master.
