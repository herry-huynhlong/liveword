# LIVEWORLD v0.7.2 — Live Tracking Recovery

This release is rebuilt directly from the user's preserved `v0.7.1-preserved` baseline.
Its purpose is recovery and stability: Earth and live orbital tracking remain the primary
experience, while Solar System rendering is isolated so it cannot break Earth startup.

## Product goal

LIVEWORLD is a browser-first 3D living map. Objects are represented by readable icons at
their best-known current position. Dense telemetry stays hidden until the user selects an
object.

Current working layer:
- Earth / CesiumJS WGS84 globe.
- CelesTrak `GROUP=ACTIVE` OMM catalog.
- satellite.js / SGP4 propagation in a Web Worker.
- Cesium `BillboardCollection` for satellites, stations and spacecraft.
- Search by name, NORAD and COSPAR/Object ID.
- Click, follow, orbit line and mission metadata.
- Warm orbital snapshot + IndexedDB cache.

Planned adapters (not faked in this release):
- aircraft / ADS-B,
- ships / AIS,
- launch / spacecraft telemetry,
- lunar orbiters / landers / future lunar bases.

## What changed from v0.7.1

Only two runtime changes were made to the primary Earth path:

1. **Solar System is lazy-loaded.** Three.js and the second WebGL renderer are not created
   during Earth startup. They are created only after the user presses `SPACE`. If SPACE
   fails, Earth and orbital tracking stay running.
2. **No pre-Cesium WebGL probe.** Startup uses the bundled 3600x1800 NASA Blue Marble
   derivative directly. The 5400x2700 master remains preserved. Close Earth detail still
   comes from the tiled imagery layer after Cesium has started.

No compatibility/fallback Earth mode from the experimental v0.8 branch is included.
There is no 2D replacement globe and no browser command-line requirement.

## Data semantics

`LIVE` in the status bar means the page is continuously updating object positions from the
latest locally available orbital elements. Satellite positions are **derived current states**:
CelesTrak OMM elements + SGP4 propagation at the current browser time. They are not direct
on-board telemetry.

Future feeds should preserve that distinction:
- `LIVE` — live telemetry/feed where available,
- `PROPAGATED` — current state computed from orbital elements,
- `EPHEMERIS` — current state interpolated from an official trajectory,
- `PREDICTED` — future/planned state,
- `FIXED` — a known fixed surface location such as a base or landing site.

## Deploy

```bash
chmod +x deploy.sh
./deploy.sh
sudo bash server/install-live-data.sh   # one time only if not already installed
```

Verify the deployed build and orbital snapshot:

```bash
curl -s https://liveword.longh.org/ | grep -E 'v0.7.2-recovery|app.js\?v=7.2-recovery'
curl -s https://liveword.longh.org/live-data/space-active.meta.json | python3 -m json.tool
```

Then open `https://liveword.longh.org` normally in Chrome/Edge/Safari/Firefox.
No special browser flags are part of the production design.
