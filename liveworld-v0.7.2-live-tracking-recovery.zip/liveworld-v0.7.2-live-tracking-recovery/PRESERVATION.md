# LIVEWORLD asset preservation policy

This build never replaces a higher-resolution source asset with a lower-resolution derivative.

Earth assets:
- `public/assets/earth-blue-marble-master-5400x2700.jpg` — preserved original master from v0.7.0.
- `public/assets/earth-blue-marble-web-3600x1800.jpg` — renderer fallback for GPUs limited to 4096px textures.
- `public/assets/earth-blue-marble.jpg` — canonical copy of the preserved 5400x2700 master for compatibility/archive.

The browser selects a render derivative according to GPU texture capability. This is rendering LOD only; source data remains intact.

Future Earth detail must be added as non-destructive layers/tiles (imagery pyramid, DEM/terrain, buildings, bathymetry, geology and subsurface datasets). Never upscale a reduced derivative and never discard the source master.
