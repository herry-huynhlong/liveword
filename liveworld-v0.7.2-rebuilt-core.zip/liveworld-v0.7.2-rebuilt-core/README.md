# LIVEWORLD v0.7.2-rebuilt — Tracking Core

Rebuilt directly from the user-provided `v0.7.1-preserved` baseline.

## What changed

- Same root page: `/` — no separate tracking page.
- Same LIVEWORLD UI, search, object panel, layer rail and live orbital catalog workflow.
- Cesium/WebGL is removed from the Earth startup path.
- Earth is rendered as a browser-safe Canvas 2D orthographic globe using the bundled NASA Blue Marble image.
- Day/night lighting is calculated in the renderer.
- CelesTrak ACTIVE OMM + satellite.js/SGP4 Web Worker remains the position engine.
- 10k+ orbital objects are drawn as lightweight markers; stations/spacecraft and the selected object use their icons.
- Click/select, search, Follow, Show orbit, IndexedDB warm cache and SATCAT metadata remain available.
- Close surface zoom automatically reduces orbital clutter.
- AIR / SEA / RAIL / LAUNCH are intentionally not populated with fake data. They are adapters for future live feeds.
- SPACE is intentionally not initialized in this recovery build. It will be rebuilt after the Earth tracking core is confirmed stable.

## Deploy

```bash
chmod +x deploy.sh
./deploy.sh
```

The deploy script backs up the current `/var/www/liveword/public` before replacing it.

## Data provenance

- Earth texture: bundled NASA Blue Marble asset from the preserved build.
- Orbital elements: CelesTrak ACTIVE OMM JSON.
- Position propagation: satellite.js / SGP4 in a Web Worker.
- Object metadata: CelesTrak SATCAT plus local object profiles.
