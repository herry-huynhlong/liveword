# Preservation note — v0.7.2-rebuilt

This package was rebuilt from the user-provided `liveworld-v0.7.1-preserved.zip` baseline.
The main route remains `/`. No alternate `live-map.html` page is introduced.

The Cesium startup path was replaced because the target browser repeatedly failed during Cesium WebGL context initialization. The tracking/data model is preserved: CelesTrak ACTIVE OMM, satellite.js/SGP4 worker, search, selection, follow, orbit path, warm cache, SATCAT metadata and the original LIVEWORLD interface.

The Earth renderer in this recovery build is Canvas 2D with an orthographic globe projection and the bundled NASA Blue Marble imagery. It is intended as a stable tracking core on which AIR/AIS/spacecraft/Moon layers can be added without making the entire site depend on one 3D rendering engine.
