# LIVEWORLD v0.8.1 — Solar System Core · WebGL resilience

This build starts the Solar System architecture without weakening the existing Earth/CelesTrak globe.


## WebGL resilience in v0.8.1

This build keeps the v0.8 Solar System work and adds a safer Cesium startup path:

- First try the normal WebGL2-capable Cesium context.
- If context construction fails, retry in Cesium WebGL1 compatibility mode.
- Disable startup MSAA/antialias pressure and set `failIfMajorPerformanceCaveat=false`.
- If both attempts fail, remove Cesium's generic error panel and show a LIVEWORLD diagnostic message.
- Runtime diagnostics are exposed as `window.LIVEWORLD_GPU_DIAGNOSTICS`.
- `?webgl1=1` forces WebGL1 for troubleshooting.

Chrome 138+ removed automatic SwiftShader fallback for WebGL on machines without a usable GPU. If the browser itself is running inside a CPU-only EC2/VM/remote-desktop session, production testing should be done from a normal client browser with GPU acceleration. For a trusted local development session only, Chrome can be started with `--enable-unsafe-swiftshader`.


## What changed

### 1. Solar WebGL is lazy-loaded

Cesium starts first and owns the first GPU/WebGL context. Three.js Solar mode is created only when the user first presses **SPACE** or searches for a Solar System object.

The old pre-Cesium `MAX_TEXTURE_SIZE` probe was removed because it created a temporary WebGL context during boot. Earth now starts with the safe 3600×1800 NASA Blue Marble derivative while the preserved 5400×2700 master remains on disk for future tiled LOD.

### 2. Semantic Solar System frames

JPL Horizons state vectors remain the positional truth, but LIVEWORLD now changes **render scale** depending on what the user is viewing:

- `EARTH · MOON NEIGHBORHOOD` — Earth-centered, Moon clearly visible.
- `MOON NEIGHBORHOOD` — Moon-centered, prepared for LRO/Danuri and future lunar surface layers.
- `MARS NEIGHBORHOOD` — Mars-centered, prepared for Mars orbiters/surface missions.
- `JUPITER NEIGHBORHOOD` — Jupiter-centered for Juno and future Jovian layers.
- `SOLAR SYSTEM` — heliocentric linear AU scale for planets and deep-space spacecraft.

The underlying state vectors are not compressed or fabricated. Only their screen/world rendering transform changes by frame.

### 3. Earth → Moon → Solar System navigation

SPACE opens in the Earth–Moon neighborhood. Zooming far enough out switches to the heliocentric Solar System. Double-clicking/focusing a body enters its local neighborhood. Press `0` to return to the Solar System frame.

The Earth–Moon guide line is fetched from **JPL Horizons in an Earth-centered frame**, not drawn as a decorative circle.

### 4. Spacecraft parent frames

Known orbiters are assigned to semantic parent frames, including:

- Moon: LRO, Danuri
- Mars: Mars Express, Odyssey, MRO, MAVEN, Hope
- Jupiter: Juno
- Earth neighborhood: JWST, SOHO, Aditya-L1

Deep-space probes remain in the Solar System frame.

### 5. Visual provenance

Planet/Moon markers display lightweight provenance labels such as `OBSERVED`, `DERIVED`, and spacecraft `EPHEMERIS`. Mission images remain sourced from NASA/JPL assets already installed by `deploy.sh`.

## Deploy

```bash
chmod +x deploy.sh
./deploy.sh
```

If the JPL/NASA proxy locations were never installed:

```bash
sudo bash nginx/install-space-api.sh
```

The existing CelesTrak warm snapshot service remains unchanged:

```bash
sudo bash server/install-live-data.sh
```

Then hard-refresh once:

```text
Ctrl+Shift+R
```

## Quick verification

```bash
curl -s https://liveword.longh.org/ | grep 'v0.8.1-webgl'
curl -s https://liveword.longh.org/solar-system.js | grep 'FRAME_PRESETS'
curl -s https://liveword.longh.org/live-data/space-active.meta.json | python3 -m json.tool
```

In the browser:

1. Earth should boot without creating Solar Three.js first.
2. Press SPACE: Earth and Moon should appear in a readable neighborhood view.
3. Scroll outward until the view changes to `SOLAR SYSTEM`.
4. Search `Mars`, `Moon`, `Juno`, `LRO`, or `Voyager 1`.
5. Double-click a body to enter its neighborhood.
6. Select Moon and show Trajectory; JPL-derived trajectory lines should appear.

## Next v0.8 step

The next build should attach real surface layers/terrain to Moon and Mars, then add state-vector trajectory caches so Earth→Moon spacecraft can be animated from official/operator ephemerides without querying Horizons individually from every browser.
