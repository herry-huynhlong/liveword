# LIVEWORLD asset preservation policy

This build never replaces a higher-resolution source asset with a lower-resolution derivative.

Earth assets:
- `public/assets/earth-blue-marble-master-5400x2700.jpg` — preserved NASA Blue Marble master from v0.7.x.
- `public/assets/earth-blue-marble-web-3600x1800.jpg` — boot-safe renderer derivative for common GPUs.
- `public/assets/earth-blue-marble.jpg` — canonical preserved master copy for compatibility/archive.

v0.8 no longer creates a temporary WebGL context to detect `MAX_TEXTURE_SIZE` before Cesium starts. The web-safe Earth derivative is used during boot. The master remains intact for the future Earth tile pyramid.

Solar/planet imagery is additive. `deploy.sh` downloads mission imagery into `public/assets/space/`; missing remote imagery must fall back visually rather than replacing or modifying preserved Earth assets.

Future Earth/Moon/Mars detail must be non-destructive layers/tiles (imagery pyramid, DEM/terrain, buildings, geology, landing sites and mission products). Never upscale a reduced derivative and never discard the source master.


## v0.8.1 WebGL resilience
Cesium now retries WebGL1 compatibility mode after a primary context failure and exposes GPU diagnostics without changing preserved imagery masters.
