#!/usr/bin/env bash
set -euo pipefail
DEST=/var/www/liveword/public
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/var/www/liveword/backups/public-$STAMP"

echo "==> Deploy LIVEWORLD v0.8.1-space"
if [[ -d "$DEST" ]] && [[ -n "$(find "$DEST" -mindepth 1 -maxdepth 1 -print -quit 2>/dev/null)" ]]; then
  echo "==> Backup current public -> $BACKUP"
  sudo mkdir -p "$(dirname "$BACKUP")"
  sudo cp -a "$DEST" "$BACKUP"
fi

sudo mkdir -p "$DEST"
sudo rsync -a --delete "$SCRIPT_DIR/public/" "$DEST/"
sudo chown -R www-data:www-data /var/www/liveword
sudo find /var/www/liveword -type d -exec chmod 755 {} \;
sudo find /var/www/liveword -type f -exec chmod 644 {} \;

echo "==> Local checks"
grep -q 'v0.8.1-space' "$DEST/index.html"
grep -q 'app.js?v=8.1-space' "$DEST/index.html"
grep -q 'styles.css?v=8.1-space' "$DEST/index.html"
! grep -q 'cdn.jsdelivr.net/npm/cesium' "$DEST/index.html"
test -s "$DEST/assets/earth-blue-marble-web-3600x1800.jpg"
test -f "$DEST/workers/orbit-worker.js"

echo "OK: LIVEWORLD v0.8.1-space copied to $DEST"
echo "Backup: $BACKUP"
echo "Verify:"
echo "  curl -s https://liveword.longh.org/ | grep -E 'v0.8.1-space|app.js\\?v=8.1-space'"
echo "  curl -s https://liveword.longh.org/live-data/space-active.meta.json | python3 -m json.tool"
