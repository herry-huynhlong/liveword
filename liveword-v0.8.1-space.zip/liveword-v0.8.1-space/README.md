# LIVEWORLD v0.8.1-space — Live feeds + Solar System bridge

## v0.8.1-space update

This local update re-enables the preserved SPACE explorer and connects it to the main UI:

- `SPACE` now opens the Three.js/JPL Horizons Solar System scene instead of showing the rebuild toast.
- Search can find Solar System bodies and configured spacecraft such as Mars Reconnaissance Orbiter, MAVEN, Hope, JWST, Voyager, Juno and Europa Clipper.
- The body detail panel is wired for focus, follow, trajectory and return-to-Earth actions.
- Planet imagery now uses the existing NASA/JPL proxy routes from `nginx/install-space-api.sh` rather than empty bundled asset folders.
- ISS and Hubble profiles now include a `mediaSources` contract for official web/YouTube-live discovery.

The next major step is a hierarchical frame model (`Sun -> planet -> moon/spacecraft`) so zooming into Mars, the Moon or Jupiter can switch from heliocentric Solar System scale into local orbit layers.

This build keeps the v0.7.3 Earth/orbit tracker and connects the existing external-layer architecture to real upstream feeds. Aircraft and ship markers use reported latitude/longitude and rotate from reported heading/course. Launch markers use the published launch-pad coordinates; they are not fake in-flight rocket telemetry.

## Connected sources

### AIR — ADSB.lol (default)

The default aircraft provider is the ADSB.lol public API. Its API/data are published under ODbL 1.0 and the point endpoint is available without an API key.

Because the public point endpoint is geographic (up to 250 nm per center), configure the areas you actually want LIVEWORLD to monitor. This is intentional: it keeps data fresh without pretending a free regional endpoint is a global firehose.

Edit `/etc/liveworld/live-data.env`:

```bash
AIRCRAFT_PROVIDER=adsblol
AIRCRAFT_AREAS_JSON='[{"lat":10.78,"lon":106.70,"radius_nm":250}]'
AIRCRAFT_REFRESH_SECONDS=15
```

Multiple areas are supported:

```bash
AIRCRAFT_AREAS_JSON='[{"lat":10.78,"lon":106.70,"radius_nm":250},{"lat":21.03,"lon":105.85,"radius_nm":250}]'
```

The synchronizer merges/de-duplicates aircraft by ICAO24 and writes `/var/lib/liveworld/data/aircraft.json`. Normalized fields include callsign, registration, aircraft type/operator when supplied, WGS-84 lat/lon, altitude, ground speed, heading/track, vertical rate, squawk, emitter category, source type and source timestamp.

#### Optional OpenSky provider

An OpenSky adapter is retained for deployments that have explicit authorization to use it operationally:

```bash
AIRCRAFT_PROVIDER=opensky
OPENSKY_CLIENT_ID=...
OPENSKY_CLIENT_SECRET=...
```

Do not silently switch a public/production deployment to OpenSky just because anonymous access technically works. OpenSky's current Terms of Use state that operational REST API use in a live product/service requires a prior written agreement; commercial use also requires a license. The code therefore defaults to ADSB.lol instead.

### SEA — AISStream

A server-side WebSocket bridge receives AIS position reports and writes `/var/lib/liveworld/data/ships.json`. AISStream requires an API key and geographic bounding boxes. The key stays in `/etc/liveworld/live-data.env`; it is never sent to the browser.

```bash
AISSTREAM_API_KEY=your_key_here
AISSTREAM_BBOXES_JSON='[[[8.0,102.0],[24.0,115.0]]]'
```

The bridge handles Class A/B position reports, vessel name/static details when available, reconnects with backoff and periodically writes the latest known vessel state. Ship markers use the AIS reported position and rotate from TrueHeading, with COG as fallback.

### LAUNCH — The Space Devs / Launch Library 2

The synchronizer reads Launch Library 2 upcoming launches and writes `/var/lib/liveworld/data/launch.json`.

Each launch record includes mission, launch service provider, vehicle, pad/location, NET, launch window, status, probability when provided, image metadata, and the pad's published latitude/longitude.

**Important:** the rocket icon is located at the launch pad. Launch Library 2 is schedule/pad metadata; LIVEWORLD does not fabricate a moving rocket after liftoff when no public flight telemetry is available.

## Frontend behavior

- AIR / SEA / LAUNCH consume normalized `/live-data/*.json` snapshots.
- Layer buttons show object count and stale/setup state.
- Aircraft and ships rotate by reported heading/course both on the Canvas globe and the Leaflet surface map.
- Globe orientation uses a projected local bearing rather than naïvely rotating by raw heading.
- External-object tooltips no longer show NORAD labels.
- Details panel is type-aware:
  - aircraft: state, callsign/registration/ICAO24, altitude, speed, heading, vertical rate, squawk, source and aircraft class;
  - ships: MMSI, destination, speed in knots, course/heading, ship type, IMO and call sign;
  - launch: countdown, NET, provider, pad/location, rocket, probability, status and launch window.
- A temporary upstream failure keeps the last valid snapshot instead of immediately clearing the map.
- AIR shows `SETUP` until `AIRCRAFT_AREAS_JSON` is configured when ADSB.lol is selected.

## Install / deploy

Deploy the frontend:

```bash
cd liveword-v0.8.0-live-feeds
chmod +x deploy.sh
./deploy.sh
```

The existing Nginx site needs this location (the preserved v0.7.x setup already uses it):

```nginx
location ^~ /live-data/ {
    alias /var/lib/liveworld/data/;
    default_type application/json;
    add_header Cache-Control "no-cache, must-revalidate" always;
}
```

Install the external feed services:

```bash
sudo bash server/install-external-feeds.sh
```

Then edit the environment file:

```bash
sudo nano /etc/liveworld/live-data.env
```

At minimum configure aircraft areas. For ships, also add an AISStream key + bounding boxes.

Restart after configuration:

```bash
sudo systemctl restart liveworld-feed-sync
sudo systemctl enable --now liveworld-ship-feed
```

If you are not using SEA yet, leave the AIS values blank and keep `liveworld-ship-feed` disabled.

## Verify on the server

```bash
sudo systemctl status liveworld-feed-sync --no-pager
sudo journalctl -u liveworld-feed-sync -n 80 --no-pager

curl -s http://127.0.0.1/live-data/aircraft.json -H 'Host: liveword.longh.org' | python3 -m json.tool | head -80
curl -s http://127.0.0.1/live-data/launch.json   -H 'Host: liveword.longh.org' | python3 -m json.tool | head -80
```

After AIS is configured:

```bash
sudo systemctl status liveworld-ship-feed --no-pager
sudo journalctl -u liveworld-ship-feed -n 80 --no-pager
curl -s http://127.0.0.1/live-data/ships.json -H 'Host: liveword.longh.org' | python3 -m json.tool | head -80
```

If your production hostname is `livemap.longh.org` rather than `liveword.longh.org`, change the Nginx `server_name`/certificate configuration accordingly; the source package currently preserves the original `liveword.longh.org` deployment name.

## Services

- `liveworld-feed-sync.service` — aircraft provider + Launch Library 2 sync daemon.
- `liveworld-ship-feed.service` — AISStream WebSocket bridge; installed but left disabled until its key and bounding boxes exist.
- `liveworld-orbit-sync.timer` — unchanged CelesTrak orbital snapshot updater from the existing build.

## Security / operations

- Credentials live only in `/etc/liveworld/live-data.env` with mode `0600`.
- No AIS/OpenSky secret is embedded in frontend JavaScript or exposed through `/live-data/`.
- Snapshot files are written atomically.
- Services run as `www-data` with `NoNewPrivileges` and restricted filesystem writes.
- Do not use enormous AIS bounding boxes casually; AISStream recommends focused filters to reduce bandwidth.
- ADSB.lol is attributed in object source metadata and uses ODbL 1.0; preserve required attribution/share-alike obligations for database derivatives.

## Still intentionally not connected

RAIL remains an adapter only. A real implementation needs a jurisdiction/operator-specific source such as GTFS-RT rather than a fake worldwide train feed.
