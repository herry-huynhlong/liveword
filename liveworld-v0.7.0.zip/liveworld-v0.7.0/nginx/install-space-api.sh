#!/usr/bin/env bash
set -euo pipefail

TARGET="/etc/nginx/sites-available/liveword"
DOMAIN="liveword.longh.org"

if [[ ! -f "$TARGET" ]]; then
  echo "ERROR: $TARGET not found"
  exit 1
fi

BACKUP="${TARGET}.bak-space-$(date +%Y%m%d-%H%M%S)"
echo "==> Backup: $BACKUP"
cp "$TARGET" "$BACKUP"

TARGET="$TARGET" python3 - <<'PY'
from pathlib import Path
import os, re, sys

path = Path(os.environ['TARGET'])
text = path.read_text()

blocks = r'''
    # LIVEWORLD v0.7.0 — JPL Horizons current heliocentric state vectors.
    # Query string is passed through unchanged to /api/horizons.api.
    location = /api/jpl/horizons {
        rewrite ^ /api/horizons.api break;
        proxy_pass https://ssd.jpl.nasa.gov;
        proxy_ssl_server_name on;
        proxy_ssl_name ssd.jpl.nasa.gov;
        proxy_set_header Host ssd.jpl.nasa.gov;
        proxy_set_header User-Agent "LIVEWORLD/0.7.0 (+https://liveword.longh.org)";
        proxy_set_header Accept "application/json,text/plain;q=0.9,*/*;q=0.8";
        proxy_http_version 1.1;
        proxy_connect_timeout 15s;
        proxy_read_timeout 45s;

        # Re-use the existing LIVEWORLD cache zone; no new cache zone is required.
        proxy_cache celestrak_cache;
        proxy_cache_key "jpl|$request_uri";
        proxy_cache_valid 200 10m;
        proxy_cache_lock on;
        proxy_cache_use_stale updating error timeout http_500 http_502 http_503 http_504;

        add_header X-Liveworld-Cache $upstream_cache_status always;
        add_header Cache-Control "no-store" always;
    }

    # NASA SDO near-real-time Sun image (171 A), source cadence about 15 minutes.
    location = /api/nasa/sdo/latest.jpg {
        rewrite ^ /assets/img/latest/latest_1024_0171.jpg break;
        proxy_pass https://sdo.gsfc.nasa.gov;
        proxy_ssl_server_name on;
        proxy_ssl_name sdo.gsfc.nasa.gov;
        proxy_set_header Host sdo.gsfc.nasa.gov;
        proxy_set_header User-Agent "LIVEWORLD/0.7.0 (+https://liveword.longh.org)";
        proxy_http_version 1.1;
        proxy_connect_timeout 15s;
        proxy_read_timeout 30s;
        proxy_cache celestrak_cache;
        proxy_cache_key "sdo|$uri";
        proxy_cache_valid 200 15m;
        proxy_cache_lock on;
        proxy_cache_use_stale updating error timeout http_500 http_502 http_503 http_504;
        add_header X-Liveworld-Cache $upstream_cache_status always;
    }

    # Real WISE all-sky observed mosaic used as the Space background.
    location = /api/nasa/wise/allsky.jpg {
        rewrite ^ /jpeg/PIA15482.jpg break;
        proxy_pass https://photojournal.jpl.nasa.gov;
        proxy_ssl_server_name on;
        proxy_ssl_name photojournal.jpl.nasa.gov;
        proxy_set_header Host photojournal.jpl.nasa.gov;
        proxy_set_header User-Agent "LIVEWORLD/0.7.0 (+https://liveword.longh.org)";
        proxy_http_version 1.1;
        proxy_connect_timeout 15s;
        proxy_read_timeout 45s;
        proxy_cache celestrak_cache;
        proxy_cache_key "photojournal|PIA15482";
        proxy_cache_valid 200 30d;
        proxy_cache_lock on;
        proxy_cache_use_stale updating error timeout http_500 http_502 http_503 http_504;
        add_header X-Liveworld-Cache $upstream_cache_status always;
    }

    # Official NASA/JPL Photojournal images used for planet/Moon markers and profiles.
    location ^~ /api/nasa/photojournal/ {
        rewrite ^/api/nasa/photojournal/(PIA[0-9]+\.jpg)$ /jpeg/$1 break;
        proxy_pass https://photojournal.jpl.nasa.gov;
        proxy_ssl_server_name on;
        proxy_ssl_name photojournal.jpl.nasa.gov;
        proxy_set_header Host photojournal.jpl.nasa.gov;
        proxy_set_header User-Agent "LIVEWORLD/0.7.0 (+https://liveword.longh.org)";
        proxy_http_version 1.1;
        proxy_connect_timeout 15s;
        proxy_read_timeout 45s;
        proxy_cache celestrak_cache;
        proxy_cache_key "photojournal|$uri";
        proxy_cache_valid 200 30d;
        proxy_cache_lock on;
        proxy_cache_use_stale updating error timeout http_500 http_502 http_503 http_504;
        add_header X-Liveworld-Cache $upstream_cache_status always;
    }
'''

if 'location = /api/jpl/horizons' in text:
    print('Space API locations already exist; no duplicate insertion.')
    sys.exit(0)

found = False
for match in re.finditer(r'(?m)^[ \t]*server\s*\{', text):
    open_brace = text.find('{', match.start())
    depth = 0
    end = None
    for i in range(open_brace, len(text)):
        if text[i] == '{': depth += 1
        elif text[i] == '}':
            depth -= 1
            if depth == 0:
                end = i + 1
                break
    if end is None:
        continue
    block = text[match.start():end]
    if re.search(r'server_name\s+[^;]*liveword\.longh\.org[^;]*;', block) and re.search(r'listen\s+[^;]*443[^;]*;', block):
        closing = end - 1
        text = text[:closing] + blocks + text[closing:]
        found = True
        break

if not found:
    raise SystemExit('ERROR: HTTPS server block for liveword.longh.org was not found')

path.write_text(text)
print('OK: inserted JPL Horizons + NASA image proxy locations.')
PY

echo "==> nginx -t"
if nginx -t; then
  systemctl reload nginx
  echo "OK: Nginx reloaded"
else
  echo "ERROR: Nginx test failed; restoring $BACKUP"
  cp "$BACKUP" "$TARGET"
  nginx -t || true
  exit 1
fi

echo "==> Test JPL Horizons through LIVEWORLD"
TMP_JSON="$(mktemp)"
if curl -fsS -G "https://${DOMAIN}/api/jpl/horizons" \
    --data-urlencode "format=json" \
    --data-urlencode "COMMAND='499'" \
    --data-urlencode "OBJ_DATA='NO'" \
    --data-urlencode "MAKE_EPHEM='YES'" \
    --data-urlencode "EPHEM_TYPE='VECTORS'" \
    --data-urlencode "CENTER='500@10'" \
    --data-urlencode "TLIST='2461306.5'" \
    --data-urlencode "TLIST_TYPE='JD'" \
    --data-urlencode "OUT_UNITS='AU-D'" \
    --data-urlencode "REF_PLANE='ECLIPTIC'" \
    --data-urlencode "REF_SYSTEM='ICRF'" \
    --data-urlencode "VEC_TABLE='2'" \
    --data-urlencode "CSV_FORMAT='YES'" \
    -o "$TMP_JSON"; then
  python3 - "$TMP_JSON" <<'PY'
import json, sys
p=sys.argv[1]
try:
    data=json.load(open(p))
    result=str(data.get('result',''))
    ok='$$SOE' in result and '$$EOE' in result
    print('JPL Horizons:', 'OK' if ok else 'FAILED: no ephemeris table')
    if not ok:
        print(data.get('error') or result[:500])
        raise SystemExit(1)
except Exception as e:
    print('JPL Horizons test failed:', e)
    raise
PY
else
  echo "WARNING: JPL proxy request failed. Nginx is installed, but upstream/network should be checked."
fi
rm -f "$TMP_JSON"

echo "==> Test NASA image proxies"
for url in \
  "https://${DOMAIN}/api/nasa/sdo/latest.jpg" \
  "https://${DOMAIN}/api/nasa/wise/allsky.jpg" \
  "https://${DOMAIN}/api/nasa/photojournal/PIA05389.jpg"
do
  code="$(curl -sS -o /dev/null -w '%{http_code}' "$url" || true)"
  echo "$code  $url"
done

echo "Done. Deploy the v0.7.0 frontend next: ./deploy.sh"
