# LIVEWORLD v0.7.0 — Real-data Space Explorer

v0.7.0 replaces the v0.6.2 hand-built Solar preview with a data-first Space mode while preserving the existing Earth/Cesium + CelesTrak ACTIVE engine.

## What changed

### Earth mode (kept)

- CesiumJS WGS84 globe.
- CelesTrak `ACTIVE` OMM JSON.
- satellite.js / SGP4 inside a Web Worker.
- BillboardCollection for the ~16k+ active orbital catalog.
- Search, click profile, Follow, Show orbit.
- SATCAT mission metadata and Object Intelligence panel from v0.6.1.

### Space mode (new)

- No hard-coded circular planet orbits.
- No logarithmic/compressed orbital distance geometry.
- Planet, Moon and spacecraft positions come from **JPL Horizons `VECTORS`** in a heliocentric, ecliptic J2000 / ICRF frame.
- Heliocentric distances are **linear** in the Three.js scene (`1 AU = 40 scene units`).
- Planet/spacecraft marker size is deliberately screen-space UI, not physical radius scale.
- Space background uses the real **WISE all-sky observed mosaic** (JPL Photojournal PIA15482), not random generated stars.
- Sun marker uses NASA SDO near-real-time 171 Å imagery through the LIVEWORLD proxy.
- Planet/Moon markers use NASA/JPL mission imagery through the LIVEWORLD Photojournal proxy.
- Free camera: left-drag orbit, right-drag or Shift+drag pan, wheel dolly, WASD translation, Q/E vertical translation, Esc releases follow, F re-focuses the selected object.
- Selecting an object **does not permanently lock the camera**. Follow is now an explicit button.
- JPL trajectory button requests a real Horizons time series and draws only that returned path.
- Search includes planets plus selected active/deep-space missions.

Current spacecraft catalog in Space mode:

```text
Voyager 1
Voyager 2
New Horizons
Parker Solar Probe
Solar Orbiter
Juno
Lucy
JUICE
Europa Clipper
Psyche
James Webb Space Telescope
SOHO
OSIRIS-APEX
Hayabusa2
BepiColombo MPO
Mars Express
2001 Mars Odyssey
Mars Reconnaissance Orbiter
MAVEN
Emirates Mars Mission (Hope)
Lunar Reconnaissance Orbiter
Danuri (KPLO)
Aditya-L1
```

Objects are displayed only when JPL Horizons returns a state at the requested current epoch; LIVEWORLD does not invent a fallback position.

## Important terminology

This build is a **real-data Solar System / interplanetary explorer**, not yet a complete 3D model of the entire cosmological universe. The observed WISE sky supplies real sky context, while Solar System positions and listed spacecraft states come from JPL Horizons. A later galactic/deep-sky layer can add Gaia/ESA star catalogs and extragalactic catalogs without corrupting the Solar System reference frame.

## Required Nginx additions

Your existing `celestrak_cache` zone can be reused. **Do not create another cache zone.**

Run once:

```bash
cd ~/liveword/liveworld-v0.7.0
sudo bash nginx/install-space-api.sh
```

The installer:

1. backs up `/etc/nginx/sites-available/liveword`,
2. finds the HTTPS `server {}` for `liveword.longh.org`,
3. adds `/api/jpl/horizons`,
4. adds NASA SDO/WISE/Photojournal image proxies,
5. runs `nginx -t`,
6. restores the backup automatically if the config test fails,
7. reloads Nginx and runs basic upstream tests.

It does **not** alter `/etc/nginx/conf.d/liveworld-cache.conf`.

### Endpoints added

```text
/api/jpl/horizons
  -> https://ssd.jpl.nasa.gov/api/horizons.api

/api/nasa/sdo/latest.jpg
  -> https://sdo.gsfc.nasa.gov/assets/img/latest/latest_1024_0171.jpg

/api/nasa/wise/allsky.jpg
  -> https://photojournal.jpl.nasa.gov/jpeg/PIA15482.jpg

/api/nasa/photojournal/PIAxxxxx.jpg
  -> https://photojournal.jpl.nasa.gov/jpeg/PIAxxxxx.jpg
```

The existing CelesTrak proxy remains separate.

## Deploy

After the Nginx installer succeeds:

```bash
chmod +x deploy.sh
./deploy.sh
```

Verify the public build:

```bash
curl -s https://liveword.longh.org/ \
| grep -E 'v0.7.0|app.js\?v=7.0|styles.css\?v=7.0'
```

Then hard-refresh Chrome with `Ctrl + Shift + R`.

## Verify JPL Space data manually

Mars current-vector test through LIVEWORLD:

```bash
curl -sS -G 'https://liveword.longh.org/api/jpl/horizons' \
  --data-urlencode 'format=json' \
  --data-urlencode "COMMAND='499'" \
  --data-urlencode "OBJ_DATA='NO'" \
  --data-urlencode "MAKE_EPHEM='YES'" \
  --data-urlencode "EPHEM_TYPE='VECTORS'" \
  --data-urlencode "CENTER='500@10'" \
  --data-urlencode "START_TIME='2026-09-22'" \
  --data-urlencode "STOP_TIME='2026-09-23'" \
  --data-urlencode "STEP_SIZE='1 d'" \
  --data-urlencode "OUT_UNITS='AU-D'" \
  --data-urlencode "REF_PLANE='ECLIPTIC'" \
  --data-urlencode "REF_SYSTEM='ICRF'" \
  --data-urlencode "VEC_TABLE='2'" \
  --data-urlencode "CSV_FORMAT='YES'" \
| jq -r '.result' | grep -A3 '\$\$SOE'
```

## Space-mode visual/data rules

- **Position:** JPL Horizons current state vector.
- **Trajectory:** JPL Horizons vector time series, loaded only when requested.
- **Background:** observed WISE all-sky mosaic.
- **Sun image:** NASA SDO near-real-time image.
- **Planet image:** mission/observational image with credit shown in the panel.
- **Marker size:** UI-only; never presented as physical scale.
- **No state from JPL:** object is hidden / marked unavailable rather than drawn at an invented position.

## Next architecture steps

1. Add SPICE kernel ingestion for missions where operator/NAIF kernels provide higher-fidelity or more mission-specific states.
2. Add a source-priority layer: operator telemetry / SPICE > JPL Horizons > propagated orbital source.
3. Add Moon and Mars body modes with body-fixed frames (`IAU_MOON`, `IAU_MARS`) and surface imagery/DEM.
4. Add published rover/lander positions and traverses in Mars/Moon body-fixed coordinates.
5. Add launch-to-interplanetary mission timeline playback and historical/future ephemeris scrubbing.
6. Add Gaia-based stellar catalog rendering as a separate deep-space layer; do not conflate stars/galaxies with the Solar System ephemeris frame.
