import * as satellite from 'https://cdn.jsdelivr.net/npm/satellite.js@7.1.0/+esm';

const { Cesium } = window;
if (!Cesium) throw new Error('CesiumJS CDN did not load.');

const ORBIT_GROUP = 'ACTIVE';
const ORBIT_ENDPOINT = `/api/celestrak/gp.php?GROUP=${ORBIT_GROUP}&FORMAT=JSON`;
const ORBIT_SNAPSHOT_META = '/live-data/space-active.meta.json';
const ORBIT_SNAPSHOT_DATA = '/live-data/space-active.json';
const ORBIT_CACHE_DB = 'liveworld-cache-v1';
const ORBIT_CACHE_STORE = 'orbit';
const ORBIT_CACHE_KEY = 'active';
const SATCAT_ENDPOINT = (norad) => `/api/celestrak/satcat?CATNR=${encodeURIComponent(norad)}`;
const PROFILE_ENDPOINT = '/data/object-profiles.json?v=8.0-solar-core';
const SURFACE_ORBIT_HIDE_M = 1_500_000;
const POSITION_APPLY_BATCH = 900;

const ICONS = {
  satellite: '/assets/icons/satellite.svg',
  station: '/assets/icons/station.svg',
  spacecraft: '/assets/icons/spacecraft.svg',
  debris: '/assets/icons/debris.svg',
};

const TYPE_LABEL = {
  satellite: 'SATELLITE',
  station: 'SPACE STATION',
  spacecraft: 'SPACECRAFT',
  debris: 'ORBITAL OBJECT',
};

const OWNER_LABELS = {
  ISS: 'ISS Partners',
  US: 'United States',
  CIS: 'Russia / CIS',
  PRC: 'China',
  ESA: 'European Space Agency',
  JPN: 'Japan',
  IND: 'India',
  FR: 'France',
  CA: 'Canada',
  UK: 'United Kingdom',
  IT: 'Italy',
  GER: 'Germany',
};

const LAUNCH_SITE_LABELS = {
  TYMSC: 'Baikonur Cosmodrome · Kazakhstan',
  AFETR: 'Cape Canaveral SFS · USA',
  AFWTR: 'Vandenberg SFB · USA',
  KSCUT: 'Kennedy Space Center · USA',
  FRGUI: 'Guiana Space Centre · Kourou',
  PLMSC: 'Plesetsk Cosmodrome · Russia',
  VOSTO: 'Vostochny Cosmodrome · Russia',
  XICLF: 'Xichang Satellite Launch Center · China',
  WSC: 'Wenchang Space Launch Site · China',
  TAISC: 'Taiyuan Satellite Launch Center · China',
  JSC: 'Jiuquan Satellite Launch Center · China',
  TANSC: 'Tanegashima Space Center · Japan',
  SRILR: 'Satish Dhawan Space Centre · India',
};

const state = {
  viewer: null,
  orbitObjects: [],
  orbitBillboards: null,
  selected: null,
  focusEntity: null,
  orbitLine: null,
  orbitLayerVisible: true,
  following: false,
  cameraHeight: Infinity,
  worker: null,
  firstPositionFrame: false,
  pendingFrame: null,
  sourceLoadedAt: null,
  catalogCounts: {},
  satcatCache: new Map(),
  profiles: {},
  metadataRequestId: 0,
  worldMode: 'earth',
  solar: null,
  solarInitPromise: null,
  lastOrbitStatus: '',
  selectedBody: null,
  orbitCatalogVersion: '',
  orbitCatalogGeneratedAt: null,
  orbitCatalogSource: 'network',
};

const $ = (id) => document.getElementById(id);
const panel = $('panel');
const statusText = $('statusText');
const tooltip = $('tooltip');

function classifyOrbitObject(row) {
  const name = String(row.OBJECT_NAME || '').toUpperCase();
  if (/^(ISS\b|CSS\b|TIANGONG\b)/.test(name) || name.includes('SPACE STATION')) return 'station';
  if (/(CREW DRAGON|DRAGON|CYGNUS|SOYUZ|PROGRESS|TIANZHOU|SHENZHOU|STARLINER|HTV-X|HTV\b)/.test(name)) return 'spacecraft';
  if (/(\bDEB\b|DEBRIS|\bR\/B\b|ROCKET BODY)/.test(name)) return 'debris';
  return 'satellite';
}

function constellationOf(nameRaw) {
  const name = String(nameRaw || '').toUpperCase();
  if (name.startsWith('STARLINK')) return 'Starlink';
  if (name.startsWith('ONEWEB')) return 'OneWeb';
  if (/\bGPS\b|NAVSTAR/.test(name)) return 'GPS';
  if (/GALILEO/.test(name)) return 'Galileo';
  if (/GLONASS/.test(name)) return 'GLONASS';
  if (/BEIDOU|COMPASS/.test(name)) return 'BeiDou';
  if (/QZS|QZSS/.test(name)) return 'QZSS';
  if (/IRNSS|NAVIC/.test(name)) return 'NavIC';
  if (/KUIPER/.test(name)) return 'Kuiper';
  if (/QIANFAN|G60/.test(name)) return 'Qianfan';
  return 'Other';
}

function iconSize(category) {
  if (category === 'station') return 31;
  if (category === 'spacecraft') return 24;
  if (category === 'debris') return 12;
  return 14;
}


function safeText(value, fallback = '—') {
  const text = String(value ?? '').trim();
  return text || fallback;
}

function formatDate(value) {
  if (!value) return '—';
  const date = new Date(`${value}T00:00:00Z`);
  if (Number.isNaN(date.getTime())) return value;
  return new Intl.DateTimeFormat('en', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    timeZone: 'UTC',
  }).format(date);
}

function ageBetween(startValue, endValue = new Date()) {
  if (!startValue) return null;
  const start = new Date(`${startValue}T00:00:00Z`);
  const end = endValue instanceof Date ? new Date(endValue) : new Date(`${endValue}T00:00:00Z`);
  if (Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end < start) return null;

  let years = end.getUTCFullYear() - start.getUTCFullYear();
  let months = end.getUTCMonth() - start.getUTCMonth();
  let days = end.getUTCDate() - start.getUTCDate();

  if (days < 0) {
    months -= 1;
    const previousMonthDays = new Date(Date.UTC(end.getUTCFullYear(), end.getUTCMonth(), 0)).getUTCDate();
    days += previousMonthDays;
  }
  if (months < 0) {
    years -= 1;
    months += 12;
  }

  const totalDays = Math.floor((Date.UTC(end.getUTCFullYear(), end.getUTCMonth(), end.getUTCDate()) - start.getTime()) / 86400000);
  return { years, months, days, totalDays };
}

function formatAge(age) {
  if (!age) return '—';
  if (age.years > 0) return `${age.years} yr ${age.months} mo`;
  if (age.months > 0) return `${age.months} mo ${age.days} d`;
  return `${Math.max(0, age.days)} d`;
}

function ownerLabel(code) {
  const raw = safeText(code, '');
  return OWNER_LABELS[raw] || raw || '—';
}

function launchSiteLabel(code) {
  const raw = safeText(code, '');
  return LAUNCH_SITE_LABELS[raw] || raw || '—';
}

function orbitSummary(meta) {
  if (!meta) return '—';
  const center = meta.ORBIT_CENTER === 'EA' ? 'Earth' : safeText(meta.ORBIT_CENTER, '');
  const type = meta.ORBIT_TYPE === 'ORB' ? 'Orbit' : safeText(meta.ORBIT_TYPE, '');
  return [center, type].filter(Boolean).join(' · ') || '—';
}


const BODY_DESCRIPTIONS = {
  sun: 'The central star and reference body for LIVEWORLD Solar mode.',
  mercury: 'Innermost planet of the Solar System.',
  venus: 'Second planet from the Sun, wrapped in a dense atmosphere.',
  earth: 'LIVEWORLD home body. Open Earth to return to the live orbital catalog.',
  moon: 'Earth’s natural satellite. Surface tracking will be added in the Moon body mode.',
  mars: 'Target body for future interplanetary spacecraft and rover tracking.',
  jupiter: 'Largest planet in the Solar System.',
  saturn: 'Gas giant with the Solar System’s most prominent ring system.',
  uranus: 'Ice giant in the outer Solar System.',
  neptune: 'Outermost major planet in the LIVEWORLD Solar view.',
};

function formatOrbitalPeriod(days) {
  const value = Number(days);
  if (!Number.isFinite(value)) return '—';
  if (value >= 730) return `${(value / 365.256).toFixed(value > 10_000 ? 1 : 2)} yr`;
  return `${value.toLocaleString(undefined, { maximumFractionDigits: value < 100 ? 2 : 1 })} d`;
}

function formatDistanceAu(value) {
  const n = Number(value);
  if (!Number.isFinite(n)) return '—';
  if (n < 0.01) return `${(n * 149_597_870.7).toLocaleString(undefined, { maximumFractionDigits: 0 })} km`;
  if (n < 1) return `${n.toFixed(4)} AU`;
  if (n < 10) return `${n.toFixed(3)} AU`;
  return `${n.toFixed(2)} AU`;
}

function formatSpaceTime(value) {
  if (!value) return '—';
  const date = new Date(value);
  if (!Number.isFinite(date.getTime())) return safeText(value);
  return `${date.toISOString().slice(0, 19).replace('T', ' ')} UTC`;
}

function setBodyHero(body) {
  const image = $('bodyHeroImg');
  const placeholder = $('bodyVisualPlaceholder');
  const credit = $('bodyHeroCredit');
  const source = $('bodyHeroSource');
  const imageUrl = body.kind === 'spacecraft' ? '' : safeText(body.image, '');

  image.hidden = true;
  image.removeAttribute('src');
  placeholder.hidden = false;
  placeholder.textContent = body.kind === 'spacecraft' ? '◇' : '·';
  credit.textContent = body.kind === 'spacecraft'
    ? `${safeText(body.operator, 'Mission spacecraft')} · position from JPL Horizons`
    : safeText(body.imageCredit, 'NASA/JPL mission imagery');

  if (body.sourcePage) {
    source.href = body.sourcePage;
    source.hidden = false;
  } else {
    source.hidden = true;
  }

  if (imageUrl) {
    image.onload = () => { image.hidden = false; placeholder.hidden = true; };
    image.onerror = () => { image.hidden = true; placeholder.hidden = false; };
    image.src = imageUrl;
    image.alt = `${body.name || 'Space object'} · ${safeText(body.imageCredit, 'mission image')}`;
  }
}

function updateBodyPanel(body) {
  if (!body) return;
  const spacecraft = body.kind === 'spacecraft';
  const available = body.available !== false;

  $('bodyType').textContent = String(body.type || (spacecraft ? 'SPACECRAFT' : 'SOLAR SYSTEM BODY')).toUpperCase();
  $('bodyName').textContent = body.name || body.id || 'Space object';
  $('bodyVisualName').textContent = String(body.name || body.id || '').toUpperCase();
  $('bodyDescription').textContent = spacecraft
    ? `${safeText(body.mission, 'Space mission')}${body.operator ? ` · ${body.operator}` : ''}`
    : body.description || BODY_DESCRIPTIONS[body.id] || 'Solar System body';
  $('bodyFrame').textContent = safeText(body.frame, 'HELIOCENTRIC · ECLIPTIC J2000 · ICRF');

  $('bodyStatusBadge').textContent = available ? (spacecraft ? 'SPACECRAFT' : 'JPL') : 'LOADING';
  $('bodyStatusBadge').classList.toggle('inactive', !available);

  $('bodyMetric1Label').textContent = spacecraft ? 'Mission' : 'Diameter';
  $('bodyMetric2Label').textContent = 'Sun distance';
  $('bodyMetric3Label').textContent = spacecraft ? 'Heliocentric speed' : 'Orbital period';
  $('bodyMetric4Label').textContent = spacecraft ? 'State epoch' : 'Rotation';

  $('bodyDiameter').textContent = spacecraft
    ? safeText(body.mission, 'Spacecraft')
    : Number.isFinite(Number(body.diameterKm))
      ? `${Number(body.diameterKm).toLocaleString(undefined, { maximumFractionDigits: 1 })} km`
      : '—';
  $('bodySolarDistance').textContent = body.id === 'sun' ? '0 AU' : formatDistanceAu(body.distanceAu);
  $('bodyPeriod').textContent = spacecraft
    ? (Number.isFinite(Number(body.speedKmS)) ? `${Number(body.speedKmS).toFixed(2)} km/s` : '—')
    : formatOrbitalPeriod(body.periodDays);
  $('bodyRotation').textContent = spacecraft ? formatSpaceTime(body.stateTime) : safeText(body.rotation);

  const dataState = $('bodyDataState');
  const visualState = safeText(body.visualState, body.kind === 'spacecraft' ? 'EPHEMERIS' : 'OBSERVED');
  if (body.id === 'sun') {
    dataState.dataset.state = 'ready';
    dataState.textContent = `${visualState} · ${safeText(body.imageObserved, 'NASA SDO near-real-time')} · heliocentric origin`;
  } else if (available) {
    dataState.dataset.state = 'ready';
    const observed = body.imageObserved ? ` · image: ${body.imageObserved}` : '';
    dataState.textContent = `${visualState} · JPL Horizons VECTORS · ${formatSpaceTime(body.stateTime)}${observed}`;
  } else {
    dataState.dataset.state = 'loading';
    dataState.textContent = body.error ? `Waiting for current JPL state · ${body.error}` : 'Waiting for current JPL Horizons state…';
  }

  setBodyHero(body);
  $('bodyFollowBtn').textContent = state.solar?.followId === body.id ? 'Release follow' : 'Follow';
  $('bodyTrajectoryBtn').textContent = state.solar?.trajectoryLines?.get(body.id)?.visible ? 'Hide trajectory' : 'Trajectory';
  $('bodyFollowBtn').disabled = !available || body.id === 'sun';
  $('bodyTrajectoryBtn').disabled = !body.horizonsId;
  $('openEarthBtn').hidden = body.id !== 'earth';
  $('bodyPanel').classList.add('open');
}

function selectSolarBody(body) {
  if (!body || !state.solar) return;
  state.selectedBody = body;
  updateBodyPanel(body);
}

function handleSpaceStatus(info = {}) {
  if (state.worldMode !== 'solar') return;
  if (info.message) {
    statusText.textContent = `SPACE · ${info.message}`;
    return;
  }
  if (info.phase === 'loading') {
    statusText.textContent = `SPACE · JPL Horizons · ${Number(info.loaded || 0)}/${Number(info.total || 0)} current state vectors${info.failed ? ` · ${info.failed} unavailable` : ''}`;
  } else if (info.phase === 'ready') {
    statusText.textContent = `SPACE · JPL Horizons · ${Number(info.loaded || 0)}/${Number(info.total || 0)} states · WISE observed sky${info.failed ? ` · ${info.failed} unavailable` : ''}`;
  }
}

function handleSpaceFrame(info = {}) {
  if (state.worldMode !== 'solar') return;
  $('viewModeName').textContent = info.id === 'solar' ? 'SOLAR SYSTEM' : 'LOCAL SPACE';
  $('viewModeHint').textContent = `${safeText(info.label, 'SPACE')} · ${safeText(info.detail, 'JPL Horizons')}`;
}

function setWorldMode(mode, options = {}) {
  const next = mode === 'solar' ? 'solar' : 'earth';
  if (!state.solar && next === 'solar') return;
  const previous = state.worldMode;
  state.worldMode = next;
  $('app').classList.toggle('solar-mode', next === 'solar');
  $('earthModeBtn').classList.toggle('active', next === 'earth');
  $('solarModeBtn').classList.toggle('active', next === 'solar');
  $('spaceControls').hidden = next !== 'solar';

  if (next === 'solar') {
    panel.classList.remove('open');
    tooltip.hidden = true;
    $('viewModeName').textContent = 'LOCAL SPACE';
    $('viewModeHint').textContent = 'Earth–Moon neighborhood · zoom out to Solar System';
    statusText.textContent = 'SPACE · loading current JPL Horizons state vectors…';
    document.querySelector('.hint').textContent = 'Scroll ra xa: Earth–Moon → Solar System · Double-click một thiên thể để tiến vào neighborhood';
    state.solar?.setVisible(true, { enterFromEarth: previous !== 'solar' && options.enterFromEarth !== false && !options.focus });
    if (options.focus) state.solar.focusBody(options.focus, options.notify !== false);
  } else {
    state.solar?.setVisible(false);
    $('bodyPanel').classList.remove('open');
    $('spaceControls').hidden = true;
    document.querySelector('.hint').textContent = 'Drag để xoay · Scroll để tiến gần Trái Đất · Click icon để xem dữ liệu';
    if (previous === 'solar' && state.viewer) {
      state.viewer.camera.setView({
        destination: Cesium.Cartesian3.fromDegrees(105, 18, 20_500_000),
        orientation: { heading: 0, pitch: Cesium.Math.toRadians(-90), roll: 0 },
      });
    }
    if (state.lastOrbitStatus) statusText.textContent = state.lastOrbitStatus;
    updateCameraMode();
    updateOrbitVisibility();
  }
}

async function setupSolarSystem() {
  const { SolarSystemEngine } = await import('/solar-system.js?v=8.0-solar-core');
  state.solar = new SolarSystemEngine($('solarContainer'), {
    onSelectBody: selectSolarBody,
    onRequestEarth: () => setWorldMode('earth'),
    onStatus: handleSpaceStatus,
    onFrameChange: handleSpaceFrame,
  });
  state.solar.setVisible(false);
  return state.solar;
}

async function ensureSolarSystem() {
  if (state.solar) return state.solar;
  if (state.solarInitPromise) return state.solarInitPromise;
  const button = $('solarModeBtn');
  state.solarInitPromise = (async () => {
    button.disabled = true;
    button.textContent = 'LOADING';
    try {
      return await setupSolarSystem();
    } finally {
      button.disabled = false;
      button.textContent = 'SPACE';
      state.solarInitPromise = null;
    }
  })();
  return state.solarInitPromise;
}

async function openSolarMode(options = {}) {
  try {
    await ensureSolarSystem();
    setWorldMode('solar', options);
  } catch (error) {
    console.warn('Solar System engine unavailable.', error);
    showToast(`Space engine unavailable: ${error?.message || error}`);
  }
}

async function loadProfiles() {
  try {
    const response = await fetch(PROFILE_ENDPOINT, { cache: 'no-cache' });
    if (!response.ok) throw new Error(`profile registry HTTP ${response.status}`);
    const data = await response.json();
    state.profiles = data && typeof data === 'object' ? data : {};
  } catch (error) {
    console.warn('Object profile registry unavailable.', error);
    state.profiles = {};
  }
}

async function fetchSatcatMetadata(norad) {
  const id = String(norad || '').trim();
  if (!id) return null;
  if (state.satcatCache.has(id)) return state.satcatCache.get(id);

  const response = await fetch(SATCAT_ENDPOINT(id), {
    headers: { Accept: 'application/json' },
  });
  if (!response.ok) throw new Error(`SATCAT: HTTP ${response.status}`);
  const rows = await response.json();
  const metadata = Array.isArray(rows) ? (rows[0] || null) : null;
  state.satcatCache.set(id, metadata);
  return metadata;
}

function setMetadataState(obj, status, error = '') {
  obj.metadataStatus = status;
  obj.metadataError = error;
  if (state.selected === obj) updateSelectedPanel(obj);
}

async function enrichSelectedObject(obj) {
  if (!obj) return;
  obj.profile = state.profiles[obj.norad] || null;
  updateSelectedPanel(obj);

  if (obj.metadataStatus === 'ready' || obj.metadataStatus === 'loading') return;
  setMetadataState(obj, 'loading');

  try {
    obj.metadata = await fetchSatcatMetadata(obj.norad);
    setMetadataState(obj, obj.metadata ? 'ready' : 'empty');
  } catch (error) {
    console.warn(`SATCAT metadata failed for ${obj.norad}`, error);
    setMetadataState(obj, 'error', error?.message || String(error));
  }
}

function updateHero(obj) {
  const profile = obj.profile || {};
  const wrap = $('entityHero');
  const photo = $('entityHeroImg');
  const fallback = $('entityHeroFallback');
  const credit = $('entityHeroCredit');
  const source = $('entityHeroSource');

  if (profile.heroImage) {
    wrap.classList.add('has-photo');
    photo.hidden = false;
    fallback.hidden = true;
    if (photo.dataset.src !== profile.heroImage) {
      photo.dataset.src = profile.heroImage;
      photo.src = profile.heroImage;
    }
    credit.textContent = profile.imageCredit ? `Photo: ${profile.imageCredit}` : 'Mission image';
    if (profile.imageSourceUrl) {
      source.href = profile.imageSourceUrl;
      source.hidden = false;
    } else {
      source.hidden = true;
    }
  } else {
    wrap.classList.remove('has-photo');
    photo.hidden = true;
    photo.removeAttribute('src');
    photo.dataset.src = '';
    fallback.hidden = false;
    fallback.src = ICONS[obj.category] || ICONS.satellite;
    credit.textContent = 'LIVEWORLD object profile';
    source.hidden = true;
  }
}

function preferredEarthTextureUrl() {
  // v0.8 deliberately avoids creating a temporary WebGL context before Cesium.
  // The 3600px derivative is safe on common 4096px GPUs; the 5400px NASA master remains
  // preserved on disk for future tiled imagery LOD and is never destroyed or overwritten.
  return '/assets/earth-blue-marble-web-3600x1800.jpg?v=8.0-solar-core';
}


async function createViewer() {
  const earthTextureUrl = preferredEarthTextureUrl();
  const [localBlueMarble, localNightLights] = await Promise.all([
    Cesium.SingleTileImageryProvider.fromUrl(earthTextureUrl, {
      rectangle: Cesium.Rectangle.MAX_VALUE,
      credit: 'NASA Blue Marble',
    }),
    Cesium.SingleTileImageryProvider.fromUrl('/assets/earth-night-lights.jpg?v=8.0-solar-core', {
      rectangle: Cesium.Rectangle.MAX_VALUE,
      credit: 'NASA Black Marble 2016 · Suomi NPP/VIIRS',
    }).catch((error) => {
      console.warn('Night-lights texture unavailable; Earth will use day imagery only.', error);
      return null;
    }),
  ]);

  const dayBaseLayer = new Cesium.ImageryLayer(localBlueMarble, {
    dayAlpha: 1.0,
    nightAlpha: 0.16,
  });
  dayBaseLayer.brightness = 1.0;
  dayBaseLayer.contrast = 1.03;
  dayBaseLayer.saturation = 1.02;

  const viewer = new Cesium.Viewer('cesiumContainer', {
    animation: false,
    baseLayerPicker: false,
    baseLayer: dayBaseLayer,
    fullscreenButton: false,
    geocoder: false,
    homeButton: false,
    infoBox: false,
    navigationHelpButton: false,
    sceneModePicker: false,
    selectionIndicator: false,
    timeline: false,
    scene3DOnly: true,
    shouldAnimate: true,
    terrainProvider: new Cesium.EllipsoidTerrainProvider(),
  });

  const scene = viewer.scene;
  scene.backgroundColor = Cesium.Color.fromCssColorString('#02060b');
  scene.globe.enableLighting = true;
  // Cesium normally fades globe lighting out around ~10–20 Mm camera height.
  // LIVEWORLD keeps the solar terminator active throughout Earth mode so the
  // Black Marble night layer remains visible even from far orbit.
  scene.globe.lightingFadeOutDistance = 150_000_000;
  scene.globe.lightingFadeInDistance = 180_000_000;
  scene.globe.showGroundAtmosphere = true;
  scene.globe.dynamicAtmosphereLighting = true;
  scene.globe.dynamicAtmosphereLightingFromSun = true;
  scene.globe.depthTestAgainstTerrain = true;
  scene.skyAtmosphere.show = true;
  scene.sun.show = true;
  scene.moon.show = true;
  scene.fog.enabled = true;
  scene.highDynamicRange = true;
  scene.globe.lambertDiffuseMultiplier = 0.92;

  // Cesium supports different alpha values on the day/night hemispheres when
  // globe lighting is enabled. Keep the daytime map faintly visible at night,
  // then place NASA Black Marble above it only on the night side. This gives a
  // real terminator plus human settlement lights instead of a black disk.
  if (localNightLights) {
    const nightLayer = viewer.imageryLayers.addImageryProvider(localNightLights);
    nightLayer.dayAlpha = 0.0;
    nightLayer.nightAlpha = 1.0;
    nightLayer.brightness = 1.18;
    nightLayer.contrast = 1.12;
    nightLayer.saturation = 1.05;
    nightLayer.gamma = 1.04;
  }

  const controller = scene.screenSpaceCameraController;
  controller.enableCollisionDetection = true;
  controller.minimumZoomDistance = 2200;
  controller.maximumZoomDistance = 100000000;
  controller.inertiaZoom = 0.72;
  controller.inertiaSpin = 0.82;

  viewer.camera.setView({
    destination: Cesium.Cartesian3.fromDegrees(105, 18, 20500000),
    orientation: { heading: 0, pitch: Cesium.Math.toRadians(-90), roll: 0 },
  });

  // Detailed surface imagery is an enhancement, not a startup dependency.
  // Load it in the background so Earth + cached satellites can paint immediately.
  Cesium.ArcGisMapServerImageryProvider.fromUrl(
    'https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer',
    { enablePickFeatures: false }
  ).then((detailProvider) => {
    // Keep Black Marble above the detail layer, so city lights remain crisp at night.
    const layer = viewer.imageryLayers.addImageryProvider(detailProvider, 1);
    layer.dayAlpha = 1.0;
    layer.nightAlpha = 0.06;
    layer.brightness = 0.93;
    layer.contrast = 1.04;
    layer.saturation = 1.03;
  }).catch((error) => {
    console.warn('Detailed imagery unavailable; using bundled Blue Marble.', error);
  });

  state.orbitBillboards = scene.primitives.add(new Cesium.BillboardCollection({ scene }));
  state.focusEntity = viewer.entities.add({
    id: 'liveworld:selected-orbital-object',
    show: false,
    position: Cesium.Cartesian3.fromDegrees(0, 0, 500000),
    billboard: {
      image: ICONS.satellite,
      width: 36,
      height: 36,
      verticalOrigin: Cesium.VerticalOrigin.CENTER,
      horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
      disableDepthTestDistance: Number.POSITIVE_INFINITY,
      scaleByDistance: new Cesium.NearFarScalar(2.0e5, 1.2, 6.0e7, 0.75),
    },
  });

  state.viewer = viewer;
  installInteraction(viewer);
  updateCameraMode();
  viewer.camera.changed.addEventListener(updateCameraMode);
  return viewer;
}

function openOrbitCacheDb() {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) return resolve(null);
    const request = indexedDB.open(ORBIT_CACHE_DB, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(ORBIT_CACHE_STORE)) db.createObjectStore(ORBIT_CACHE_STORE);
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('IndexedDB open failed'));
  });
}

async function readOrbitCache() {
  try {
    const db = await openOrbitCacheDb();
    if (!db) return null;
    const value = await new Promise((resolve, reject) => {
      const tx = db.transaction(ORBIT_CACHE_STORE, 'readonly');
      const req = tx.objectStore(ORBIT_CACHE_STORE).get(ORBIT_CACHE_KEY);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error);
    });
    db.close();
    if (!value || !Array.isArray(value.rows) || value.rows.length < 10000) return null;
    return value;
  } catch (error) {
    console.warn('Orbit IndexedDB cache unavailable.', error);
    return null;
  }
}

async function writeOrbitCache(record) {
  try {
    const db = await openOrbitCacheDb();
    if (!db) return false;
    await new Promise((resolve, reject) => {
      const tx = db.transaction(ORBIT_CACHE_STORE, 'readwrite');
      tx.objectStore(ORBIT_CACHE_STORE).put(record, ORBIT_CACHE_KEY);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error || new Error('IndexedDB write aborted'));
    });
    db.close();
    return true;
  } catch (error) {
    console.warn('Unable to persist orbit catalog in IndexedDB.', error);
    return false;
  }
}

async function fetchOrbitSnapshotMeta() {
  const response = await fetch(`${ORBIT_SNAPSHOT_META}?t=${Date.now()}`, {
    cache: 'no-store',
    headers: { Accept: 'application/json' },
  });
  if (!response.ok) throw new Error(`orbit snapshot meta HTTP ${response.status}`);
  const meta = await response.json();
  if (!meta || !meta.version || Number(meta.count || 0) < 10000) throw new Error('invalid orbit snapshot meta');
  return meta;
}

async function fetchOrbitSnapshot(meta = null) {
  statusText.textContent = 'Loading LIVEWORLD orbital snapshot…';
  const response = await fetch(ORBIT_SNAPSHOT_DATA, {
    cache: 'no-cache',
    headers: { Accept: 'application/json' },
  });
  if (!response.ok) throw new Error(`orbit snapshot HTTP ${response.status}`);
  const contentType = response.headers.get('content-type') || '';
  if (!contentType.includes('json')) throw new Error(`orbit snapshot returned ${contentType || 'non-JSON content'}`);
  const rows = await response.json();
  if (!Array.isArray(rows) || rows.length < 10000) throw new Error(`orbit snapshot invalid (${Array.isArray(rows) ? rows.length : 'not-array'} rows)`);
  state.sourceLoadedAt = new Date();
  return {
    rows,
    version: meta?.version || `network-${Date.now()}`,
    generatedAt: meta?.generatedAt || new Date().toISOString(),
    source: meta?.source || 'LIVEWORLD snapshot',
  };
}

async function fetchActiveCatalog() {
  statusText.textContent = 'Downloading CelesTrak ACTIVE catalog fallback…';
  const response = await fetch(ORBIT_ENDPOINT, {
    cache: 'no-cache',
    headers: { Accept: 'application/json' },
  });
  if (!response.ok) throw new Error(`CelesTrak ACTIVE: HTTP ${response.status}`);
  const contentType = response.headers.get('content-type') || '';
  if (!contentType.includes('json')) throw new Error(`CelesTrak proxy returned ${contentType || 'non-JSON content'}`);
  const rows = await response.json();
  if (!Array.isArray(rows) || rows.length < 10000) throw new Error('CelesTrak ACTIVE returned invalid JSON.');
  state.sourceLoadedAt = new Date();
  return rows;
}

function uniqueRows(rows) {
  const seen = new Set();
  const clean = [];
  for (const row of rows) {
    const norad = String(row.NORAD_CAT_ID || '').trim();
    if (!norad || seen.has(norad)) continue;
    seen.add(norad);
    clean.push(row);
  }
  return clean;
}

async function buildCatalog(rows) {
  statusText.textContent = `Preparing ${rows.length.toLocaleString()} orbital objects…`;
  const counts = { satellite: 0, station: 0, spacecraft: 0, debris: 0, constellations: {} };

  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const category = classifyOrbitObject(row);
    const name = row.OBJECT_NAME || `NORAD ${row.NORAD_CAT_ID || ''}`;
    const constellation = constellationOf(name);
    const obj = {
      kind: 'orbit',
      index: i,
      category,
      constellation,
      row,
      name,
      norad: String(row.NORAD_CAT_ID || ''),
      objectId: row.OBJECT_ID || '',
      epoch: row.EPOCH || '',
      lat: NaN,
      lon: NaN,
      altitudeKm: NaN,
      speedKmS: NaN,
      updatedAt: null,
      hasPosition: false,
      satrec: null,
      billboard: null,
      metadata: null,
      metadataStatus: 'idle',
      metadataError: '',
      profile: null,
    };

    const size = iconSize(category);
    obj.billboard = state.orbitBillboards.add({
      id: obj,
      show: false,
      image: ICONS[category] || ICONS.satellite,
      width: size,
      height: size,
      position: Cesium.Cartesian3.ZERO,
      verticalOrigin: Cesium.VerticalOrigin.CENTER,
      horizontalOrigin: Cesium.HorizontalOrigin.CENTER,
      disableDepthTestDistance: 0,
      scaleByDistance: category === 'station'
        ? new Cesium.NearFarScalar(2.0e5, 1.2, 6.0e7, 0.65)
        : new Cesium.NearFarScalar(2.0e5, 1.0, 6.0e7, 0.38),
      translucencyByDistance: new Cesium.NearFarScalar(2.0e5, 1.0, 8.0e7, 0.58),
    });

    state.orbitObjects.push(obj);
    counts[category] = (counts[category] || 0) + 1;
    counts.constellations[constellation] = (counts.constellations[constellation] || 0) + 1;

    if (i && i % 700 === 0) {
      statusText.textContent = `Preparing catalog… ${i.toLocaleString()} / ${rows.length.toLocaleString()}`;
      await new Promise((resolve) => requestAnimationFrame(resolve));
    }
  }

  state.catalogCounts = counts;
}

function startOrbitWorker(rows) {
  if (state.worker) state.worker.terminate();
  const worker = new Worker('/workers/orbit-worker.js?v=8.0-solar-core', { type: 'module' });
  state.worker = worker;

  worker.addEventListener('message', (event) => {
    const message = event.data || {};
    if (message.type === 'ready') {
      statusText.textContent = `Orbit engine ready · propagating ${message.parsed.toLocaleString()} objects…`;
      return;
    }
    if (message.type === 'positions' && message.buffer) {
      const positions = new Float32Array(message.buffer);
      queuePositionFrame(positions, new Date(message.timestamp), message.valid || 0);
    }
  });

  worker.addEventListener('error', (event) => {
    console.error('Orbit worker failed', event);
    statusText.textContent = 'Catalog loaded · orbit propagation worker failed';
    showToast('Không khởi động được SGP4 worker. Reload trang để thử lại.');
  });

  worker.postMessage({ type: 'init', rows });
}

function queuePositionFrame(positions, timestamp, valid) {
  state.pendingFrame = { positions, timestamp, valid };
  applyPendingFrame();
}

function applyPendingFrame() {
  if (!state.pendingFrame || applyPendingFrame.running) return;
  applyPendingFrame.running = true;
  const frame = state.pendingFrame;
  state.pendingFrame = null;
  let index = 0;

  const step = () => {
    const end = Math.min(index + POSITION_APPLY_BATCH, state.orbitObjects.length);
    for (; index < end; index++) {
      const obj = state.orbitObjects[index];
      const offset = index * 4;
      const lon = frame.positions[offset];
      const lat = frame.positions[offset + 1];
      const altitudeKm = frame.positions[offset + 2];
      const speedKmS = frame.positions[offset + 3];

      if (![lon, lat, altitudeKm, speedKmS].every(Number.isFinite)) {
        obj.hasPosition = false;
        obj.billboard.show = false;
        continue;
      }

      obj.lon = lon;
      obj.lat = lat;
      obj.altitudeKm = altitudeKm;
      obj.speedKmS = speedKmS;
      obj.updatedAt = frame.timestamp;
      obj.hasPosition = true;
      obj.billboard.position = Cesium.Cartesian3.fromDegrees(lon, lat, altitudeKm * 1000);
      obj.billboard.show = true;
    }

    if (index < state.orbitObjects.length) {
      requestAnimationFrame(step);
      return;
    }

    applyPendingFrame.running = false;
    if (!state.firstPositionFrame) {
      state.firstPositionFrame = true;
      updateLiveStatus(frame.valid);
    }
    if (state.selected) syncSelectedFocus();
    updateOrbitVisibility();
    if (state.pendingFrame) applyPendingFrame();
  };

  requestAnimationFrame(step);
}

function updateLiveStatus(validCount) {
  const counts = state.catalogCounts;
  const top = Object.entries(counts.constellations || {})
    .filter(([name]) => name !== 'Other')
    .sort((a, b) => b[1] - a[1])
    .slice(0, 2)
    .map(([name, count]) => `${name} ${count.toLocaleString()}`)
    .join(' · ');
  const sourceLabel = state.orbitCatalogSource === 'IndexedDB' ? 'LOCAL CACHE' : 'LIVEWORLD SNAPSHOT';
  state.lastOrbitStatus = `LIVE · ${validCount.toLocaleString()} / ${state.orbitObjects.length.toLocaleString()} active orbital objects · ${sourceLabel} · SGP4${top ? ` · ${top}` : ''}`;
  if (state.worldMode === 'earth') statusText.textContent = state.lastOrbitStatus;
}

function propagateSelected(obj, date) {
  try {
    if (!obj.satrec) obj.satrec = satellite.json2satrec(obj.row);
    const pv = satellite.propagate(obj.satrec, date);
    if (!pv?.position || !pv?.velocity) return null;
    const gmst = satellite.gstime(date);
    const geo = satellite.eciToGeodetic(pv.position, gmst);
    const lat = satellite.degreesLat(geo.latitude);
    const lon = satellite.degreesLong(geo.longitude);
    const altitudeKm = geo.height;
    const speedKmS = Math.hypot(pv.velocity.x, pv.velocity.y, pv.velocity.z);
    if (![lat, lon, altitudeKm, speedKmS].every(Number.isFinite)) return null;
    return { lat, lon, altitudeKm, speedKmS };
  } catch {
    return null;
  }
}

function syncSelectedFocus() {
  const obj = state.selected;
  if (!obj?.hasPosition) return;
  state.focusEntity.position = Cesium.Cartesian3.fromDegrees(obj.lon, obj.lat, obj.altitudeKm * 1000);
  state.focusEntity.billboard.image = ICONS[obj.category] || ICONS.satellite;
  const size = Math.max(32, iconSize(obj.category) + 10);
  state.focusEntity.billboard.width = size;
  state.focusEntity.billboard.height = size;
  state.focusEntity.show = true;
  updateSelectedPanel(obj);
}

function updateCameraMode() {
  if (!state.viewer) return;
  const carto = Cesium.Cartographic.fromCartesian(state.viewer.camera.positionWC);
  const h = Math.max(0, carto.height);
  state.cameraHeight = h;

  // Earth stays physically lit at every zoom. The night hemisphere is provided by
  // NASA Black Marble using ImageryLayer.dayAlpha/nightAlpha, so it never becomes
  // an empty black disk and it does not auto-switch away from Earth while exploring.
  state.viewer.scene.globe.enableLighting = true;
  if (state.worldMode !== 'earth') return;

  const name = $('viewModeName');
  const hint = $('viewModeHint');
  if (h > 3_500_000) {
    name.textContent = 'ORBIT VIEW';
    hint.textContent = state.firstPositionFrame ? `${state.orbitObjects.length.toLocaleString()} active catalog objects` : 'Loading global orbit catalog';
  } else if (h > 300_000) {
    name.textContent = 'EARTH VIEW';
    hint.textContent = 'Orbital objects fade as you approach the surface';
  } else {
    name.textContent = 'SURFACE VIEW';
    hint.textContent = 'Air · sea · rail · launch layers live here';
  }
  updateOrbitVisibility();
}

function updateOrbitVisibility() {
  if (!state.orbitBillboards) return;
  const surfaceMode = state.cameraHeight < SURFACE_ORBIT_HIDE_M;
  state.orbitBillboards.show = state.orbitLayerVisible && !surfaceMode;
  state.focusEntity.show = Boolean(state.selected?.hasPosition) && (state.orbitLayerVisible || state.following);
}

function pickedOrbitObject(picked) {
  if (!picked) return null;
  if (picked.id?.kind === 'orbit') return picked.id;
  if (picked.id === state.focusEntity && state.selected) return state.selected;
  return null;
}

function installInteraction(viewer) {
  const handler = viewer.screenSpaceEventHandler;

  handler.setInputAction((movement) => {
    const obj = pickedOrbitObject(viewer.scene.pick(movement.position));
    if (obj) selectObject(obj, false);
  }, Cesium.ScreenSpaceEventType.LEFT_CLICK);

  handler.setInputAction((movement) => {
    const obj = pickedOrbitObject(viewer.scene.pick(movement.endPosition));
    if (!obj) {
      tooltip.hidden = true;
      viewer.canvas.style.cursor = '';
      return;
    }
    tooltip.textContent = obj.name;
    tooltip.style.left = `${movement.endPosition.x}px`;
    tooltip.style.top = `${movement.endPosition.y}px`;
    tooltip.hidden = false;
    viewer.canvas.style.cursor = 'pointer';
  }, Cesium.ScreenSpaceEventType.MOUSE_MOVE);
}

function selectObject(obj, fly = true) {
  if (state.worldMode !== 'earth') setWorldMode('earth');
  if (!obj.hasPosition) {
    showToast(`${obj.name}: đang chờ vị trí SGP4 đầu tiên.`);
    return;
  }
  if (state.orbitLine) {
    state.viewer.entities.remove(state.orbitLine);
    state.orbitLine = null;
  }
  state.selected = obj;
  state.following = false;
  state.viewer.trackedEntity = undefined;
  panel.classList.add('open');
  syncSelectedFocus();
  enrichSelectedObject(obj);

  if (!fly) return;
  const range = Math.max(650000, Math.min(8_000_000, obj.altitudeKm * 1000 * 1.1));
  state.viewer.flyTo(state.focusEntity, {
    duration: 1.45,
    offset: new Cesium.HeadingPitchRange(0, Cesium.Math.toRadians(-25), range),
  });
}

function updateSelectedPanel(obj) {
  if (!obj) return;
  const meta = obj.metadata;
  const profile = obj.profile || {};
  const activeEnd = meta?.DECAY_DATE || new Date();
  const age = meta?.LAUNCH_DATE ? ageBetween(meta.LAUNCH_DATE, activeEnd) : null;

  $('entityType').textContent = TYPE_LABEL[obj.category] || 'ORBITAL OBJECT';
  $('entityStatus').textContent = profile.status || (meta?.DECAY_DATE ? 'DECAYED' : 'ACTIVE');
  $('entityStatus').classList.toggle('inactive', Boolean(meta?.DECAY_DATE));
  $('entityName').textContent = obj.name;
  $('entityDisplayName').textContent = profile.displayName || profile.description || '';
  $('entityDisplayName').hidden = !$('entityDisplayName').textContent;
  $('entityId').textContent = `NORAD ${obj.norad || '—'}${obj.objectId ? ` · COSPAR ${obj.objectId}` : ''}${obj.constellation !== 'Other' ? ` · ${obj.constellation}` : ''}`;

  updateHero(obj);

  $('mAgeLabel').textContent = profile.ageLabel || (meta?.DECAY_DATE ? 'MISSION LIFETIME' : 'AGE SINCE LAUNCH');
  $('mAge').textContent = age ? formatAge(age) : (obj.metadataStatus === 'loading' ? 'Loading…' : '—');
  $('mAgeSince').textContent = meta?.LAUNCH_DATE
    ? `${profile.launchLabel || 'LAUNCHED'} · ${formatDate(meta.LAUNCH_DATE)}${meta?.DECAY_DATE ? ` → ${formatDate(meta.DECAY_DATE)}` : ' → PRESENT'}`
    : 'Waiting for mission metadata';

  const crewBlock = $('crewAgeBlock');
  if (profile.continuousCrewedSince) {
    const crewAge = ageBetween(profile.continuousCrewedSince, new Date());
    crewBlock.hidden = false;
    $('mCrewAgeLabel').textContent = profile.continuousCrewedLabel || 'CONTINUOUSLY CREWED';
    $('mCrewAge').textContent = formatAge(crewAge);
    $('mCrewSince').textContent = `Since ${formatDate(profile.continuousCrewedSince)}`;
  } else {
    crewBlock.hidden = true;
  }

  $('mAltitude').textContent = Number.isFinite(obj.altitudeKm) ? `${obj.altitudeKm.toLocaleString(undefined, { maximumFractionDigits: 0 })} km` : '—';
  $('mVelocity').textContent = Number.isFinite(obj.speedKmS) ? `${obj.speedKmS.toFixed(2)} km/s` : '—';
  $('mLat').textContent = Number.isFinite(obj.lat) ? `${Math.abs(obj.lat).toFixed(3)}° ${obj.lat >= 0 ? 'N' : 'S'}` : '—';
  $('mLon').textContent = Number.isFinite(obj.lon) ? `${Math.abs(obj.lon).toFixed(3)}° ${obj.lon >= 0 ? 'E' : 'W'}` : '—';
  $('mTime').textContent = obj.updatedAt ? obj.updatedAt.toLocaleTimeString([], { hour12: false }) : '—';
  $('mSource').textContent = `CelesTrak ${ORBIT_GROUP} · OMM/SGP4`;

  $('mLaunchDate').textContent = meta?.LAUNCH_DATE ? formatDate(meta.LAUNCH_DATE) : '—';
  $('mOperator').textContent = profile.operator || ownerLabel(meta?.OWNER);
  $('mLaunchSite').textContent = profile.launchSiteDisplay || launchSiteLabel(meta?.LAUNCH_SITE);
  $('mOrbitClass').textContent = orbitSummary(meta);
  $('mApogee').textContent = meta?.APOGEE != null && Number.isFinite(Number(meta.APOGEE)) ? `${Number(meta.APOGEE).toLocaleString()} km` : '—';
  $('mPerigee').textContent = meta?.PERIGEE != null && Number.isFinite(Number(meta.PERIGEE)) ? `${Number(meta.PERIGEE).toLocaleString()} km` : '—';
  $('mInclination').textContent = meta?.INCLINATION != null && Number.isFinite(Number(meta.INCLINATION)) ? `${Number(meta.INCLINATION).toFixed(2)}°` : '—';
  $('mPeriod').textContent = meta?.PERIOD != null && Number.isFinite(Number(meta.PERIOD)) ? `${Number(meta.PERIOD).toFixed(2)} min` : '—';

  const metaState = $('metadataState');
  if (obj.metadataStatus === 'loading') {
    metaState.textContent = 'Loading mission history from CelesTrak SATCAT…';
    metaState.dataset.state = 'loading';
  } else if (obj.metadataStatus === 'error') {
    metaState.textContent = 'Mission metadata unavailable · live orbit data still active';
    metaState.dataset.state = 'error';
  } else if (obj.metadataStatus === 'empty') {
    metaState.textContent = 'No SATCAT mission metadata returned for this object';
    metaState.dataset.state = 'empty';
  } else {
    metaState.textContent = meta ? 'Mission metadata · CelesTrak SATCAT' : 'Mission metadata loads when selected';
    metaState.dataset.state = meta ? 'ready' : 'idle';
  }

  const note = $('missionNote');
  note.textContent = profile.missionNote || '';
  note.hidden = !note.textContent;

  $('followBtn').textContent = state.following ? 'Stop follow' : 'Follow';
  $('trackBtn').textContent = state.orbitLine ? 'Hide orbit' : 'Show orbit';
}

function toggleFollow() {
  if (!state.selected?.hasPosition) return;
  state.following = !state.following;
  if (state.following) {
    const d = Math.max(200000, Math.min(3_000_000, state.selected.altitudeKm * 1000 * 0.42));
    state.focusEntity.viewFrom = new Cesium.Cartesian3(0, -d, d * 0.28);
    state.viewer.trackedEntity = state.focusEntity;
  } else {
    state.viewer.trackedEntity = undefined;
  }
  updateSelectedPanel(state.selected);
  updateOrbitVisibility();
}

function toggleOrbitLine() {
  if (!state.selected) return;
  if (state.orbitLine) {
    state.viewer.entities.remove(state.orbitLine);
    state.orbitLine = null;
    updateSelectedPanel(state.selected);
    return;
  }

  const positions = [];
  const center = Date.now();
  for (let min = -100; min <= 100; min += 2) {
    const p = propagateSelected(state.selected, new Date(center + min * 60000));
    if (p) positions.push(Cesium.Cartesian3.fromDegrees(p.lon, p.lat, p.altitudeKm * 1000));
  }

  state.orbitLine = state.viewer.entities.add({
    polyline: {
      positions,
      width: 1.4,
      material: Cesium.Color.fromCssColorString('#75d5ff').withAlpha(0.55),
      arcType: Cesium.ArcType.NONE,
    },
  });
  updateSelectedPanel(state.selected);
}

function showToast(message) {
  const el = $('toast');
  el.textContent = message;
  el.hidden = false;
  clearTimeout(showToast._timer);
  showToast._timer = setTimeout(() => { el.hidden = true; }, 3000);
}

function installUI() {
  $('panelClose').addEventListener('click', () => { state.metadataRequestId += 1; panel.classList.remove('open'); });
  $('followBtn').addEventListener('click', toggleFollow);
  $('trackBtn').addEventListener('click', toggleOrbitLine);
  $('entityHeroImg').addEventListener('error', () => {
    const obj = state.selected;
    const photo = $('entityHeroImg');
    const fallback = $('entityHeroFallback');
    const wrap = $('entityHero');
    photo.hidden = true;
    fallback.hidden = false;
    fallback.src = ICONS[obj?.category] || ICONS.satellite;
    wrap.classList.remove('has-photo');
    $('entityHeroCredit').textContent = 'Mission image unavailable';
  });

  $('earthModeBtn').addEventListener('click', () => setWorldMode('earth'));
  $('solarModeBtn').addEventListener('click', () => openSolarMode({ enterFromEarth: true }));
  $('bodyPanelClose').addEventListener('click', () => $('bodyPanel').classList.remove('open'));
  $('bodyFocusBtn').addEventListener('click', () => {
    if (state.selectedBody?.id) state.solar?.focusBody(state.selectedBody.id, false);
  });
  $('bodyFollowBtn').addEventListener('click', () => {
    if (!state.selectedBody?.id || !state.solar) return;
    const following = state.solar.toggleFollow(state.selectedBody.id);
    $('bodyFollowBtn').textContent = following ? 'Release follow' : 'Follow';
    showToast(following ? `Following ${state.selectedBody.name}` : 'Free camera released');
  });
  $('bodyTrajectoryBtn').addEventListener('click', async () => {
    if (!state.selectedBody?.id || !state.solar) return;
    const button = $('bodyTrajectoryBtn');
    button.disabled = true;
    const oldText = button.textContent;
    button.textContent = 'Loading…';
    try {
      const result = await state.solar.toggleTrajectory(state.selectedBody.id);
      button.textContent = result.visible ? 'Hide trajectory' : 'Trajectory';
    } catch (error) {
      console.warn('Trajectory load failed.', error);
      button.textContent = oldText;
      showToast(`Trajectory unavailable: ${error?.message || error}`);
    } finally {
      button.disabled = false;
    }
  });
  $('openEarthBtn').addEventListener('click', () => setWorldMode('earth'));

  $('searchForm').addEventListener('submit', async (event) => {
    event.preventDefault();
    const raw = $('searchInput').value.trim();
    const q = raw.toLowerCase().replace(/^norad\s*/, '');
    if (!q) return;

    const exact = state.orbitObjects.find((x) => x.norad === q || x.objectId.toLowerCase() === q || x.name.toLowerCase() === q);
    const partial = state.orbitObjects.find((x) => x.name.toLowerCase().includes(q) || x.norad.includes(q));
    const match = exact || partial;
    if (match) {
      if (state.worldMode !== 'earth') setWorldMode('earth');
      selectObject(match, true);
      return;
    }

    try {
      const solar = await ensureSolarSystem();
      const body = solar.findBody(raw);
      if (body) {
        setWorldMode('solar', { enterFromEarth: false, focus: body.id });
        return;
      }
    } catch (error) {
      console.warn('Space search unavailable.', error);
    }
    showToast(`Không tìm thấy “${raw}” trong ACTIVE catalog hoặc Space/JPL catalog.`);
  });

  document.querySelectorAll('.layer').forEach((button) => {
    button.addEventListener('click', () => {
      const layer = button.dataset.layer;
      if (layer === 'orbit') {
        state.orbitLayerVisible = !state.orbitLayerVisible;
        button.classList.toggle('active', state.orbitLayerVisible);
        updateOrbitVisibility();
        return;
      }
      document.querySelectorAll('.layer').forEach((x) => { if (x.dataset.layer !== 'orbit') x.classList.remove('active'); });
      button.classList.add('active');
      const names = { air: 'Aircraft / ADS-B', sea: 'Ships / AIS', rail: 'High-speed rail', launch: 'Rocket / launch telemetry' };
      showToast(`${names[layer]}: adapter live sẽ được nối sau Space Catalog Engine.`);
    });
  });

  const clock = () => { $('clock').textContent = `${new Date().toISOString().slice(11, 19)} UTC`; };
  clock();
  setInterval(clock, 1000);
}

async function replaceOrbitCatalog(rawRows, info = {}) {
  const rows = uniqueRows(rawRows);
  if (rows.length < 10000) throw new Error(`Refusing orbital catalog with only ${rows.length} unique objects.`);

  if (state.worker) {
    state.worker.terminate();
    state.worker = null;
  }
  if (state.orbitBillboards) state.orbitBillboards.removeAll();
  state.orbitObjects.length = 0;
  state.firstPositionFrame = false;
  state.pendingFrame = null;
  state.catalogCounts = {};
  state.selected = null;
  state.following = false;
  if (state.focusEntity) state.focusEntity.show = false;
  panel.classList.remove('open');

  state.orbitCatalogVersion = info.version || '';
  state.orbitCatalogGeneratedAt = info.generatedAt || null;
  state.orbitCatalogSource = info.source || 'network';

  await buildCatalog(rows);
  statusText.textContent = `Catalog ready · ${rows.length.toLocaleString()} active objects · starting SGP4 worker…`;
  startOrbitWorker(rows);
  return rows;
}

async function getFreshOrbitSnapshot() {
  try {
    const meta = await fetchOrbitSnapshotMeta();
    return await fetchOrbitSnapshot(meta);
  } catch (snapshotError) {
    console.warn('LIVEWORLD server snapshot unavailable; using CelesTrak proxy fallback.', snapshotError);
    const rows = await fetchActiveCatalog();
    return {
      rows,
      version: `fallback-${Date.now()}`,
      generatedAt: new Date().toISOString(),
      source: 'CelesTrak ACTIVE fallback',
    };
  }
}

async function refreshOrbitCatalogInBackground(currentVersion) {
  try {
    const meta = await fetchOrbitSnapshotMeta();
    if (meta.version === currentVersion) {
      state.orbitCatalogGeneratedAt = meta.generatedAt || state.orbitCatalogGeneratedAt;
      return;
    }
    const fresh = await fetchOrbitSnapshot(meta);
    const rows = uniqueRows(fresh.rows);
    if (rows.length < 10000) throw new Error('fresh snapshot failed validation');
    await writeOrbitCache({ ...fresh, rows, cachedAt: new Date().toISOString() });
    showToast(`Orbital catalog updated in background · ${rows.length.toLocaleString()} objects`);
    await replaceOrbitCatalog(rows, fresh);
  } catch (error) {
    console.warn('Background orbit refresh skipped.', error);
    // Cached orbital elements remain usable by SGP4 even when the network is unavailable.
  }
}

async function loadSpaceCatalog() {
  const cached = await readOrbitCache();
  if (cached) {
    const rows = uniqueRows(cached.rows);
    const ageMin = cached.cachedAt ? Math.max(0, Math.round((Date.now() - Date.parse(cached.cachedAt)) / 60000)) : null;
    statusText.textContent = `LOCAL CACHE · ${rows.length.toLocaleString()} orbital objects${ageMin != null ? ` · saved ${ageMin} min ago` : ''}`;
    await replaceOrbitCatalog(rows, { ...cached, source: 'IndexedDB' });
    // Never block first paint on a network refresh.
    refreshOrbitCatalogInBackground(cached.version);
    return;
  }

  const fresh = await getFreshOrbitSnapshot();
  const rows = uniqueRows(fresh.rows);
  await writeOrbitCache({ ...fresh, rows, cachedAt: new Date().toISOString() });
  await replaceOrbitCatalog(rows, fresh);
}

async function boot() {
  try {
    installUI();
    await Promise.all([createViewer(), loadProfiles()]);
    // Solar WebGL is lazy-initialized on first SPACE/search request so Cesium gets the
    // primary GPU context first. This avoids the v0.7 early multi-context failure mode.
    await loadSpaceCatalog();
  } catch (error) {
    console.error(error);
    $('fatal').hidden = false;
    $('fatalText').textContent = error?.message || String(error);
    statusText.textContent = 'Startup failed';
  }
}

boot();
